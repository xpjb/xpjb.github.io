# LLVM → Ghidra → C experiment

Run October 8, 2026. This is an empirical case study, not a proof of equivalence
or a general Ghidra-to-C compiler. The three workloads are real upstream library
implementations: jsmn (strict JSON tokenization), QOI (memory encoder/decoder),
and Brad Conte's educational SHA-256 implementation. The benchmark driver and
tests are experiment-specific. No claim is made about production cryptography.

## Tools

- Clang / LLVM / LLD 22.1.8; x86-64 Linux, AMD Ryzen 5 5600X.
- Ghidra 12.1.4 PUBLIC (September 21, 2026 build), OpenJDK 21.
- Python 3 standard library only; bash, readelf, taskset.
- Ghidra is NOT bundled. Download the exact release from
  https://github.com/NationalSecurityAgency/ghidra/releases/tag/Ghidra_12.1.4_build
  and set `GHIDRA_HOME` to its installation directory.
- Tool versions, pinned upstream commit IDs, all compile commands, raw results,
  compiler diagnostics, and sanitizer output are in `results/` and `build/`.

## Reproduce

```sh
export GHIDRA_HOME=/path/to/ghidra_12.1.4_PUBLIC
export JAVA_HOME=/path/to/jdk-21
# BENCH_CPU defaults to logical CPU 2; select an available CPU if needed.
export BENCH_CPU=2
bash scripts/reproduce.sh
```

`-march=native` deliberately targets the measured machine. A different CPU,
compiler, or Ghidra version may change both the optimized instructions and
Ghidra's output; no cross-machine performance reproducibility is promised.

The full run takes several minutes and needs approximately 1 GB for Ghidra plus
build space. The source archive contains the original observed outputs too.
Use the source archive's pinned inputs rather than moving upstream branches.

## What is being measured?

`src/libraries.c` includes upstream implementations without algorithm changes.
JSMN_STRICT and QOI_NO_STDIO are the only library configuration switches.
Shared libraries retain public API symbols, so LTO can inline private helpers
but cannot specialize for the benchmark inputs. The benchmark is a separate C
executable that calls the library via dlsym function pointers.

Common flags: `-std=c11 -shared -fPIC -fuse-ld=lld -flto -march=native -g0
-Wl,-Bsymbolic -fno-stack-protector -fwrapv -fno-strict-aliasing`.
Use O0, O2, O3, or Oz on top. Supplementary cases: O3 plus explicit unrolling;
O3 generic x86-64; and O3/Oz with full DWARF to assist Ghidra (same .text bytes).

These choices are deliberate:

- No fast-math or PGO, no claim that an optimizer has a universal "maximum".
- `-fwrapv` gives defined Clang wrapping behavior to signed arithmetic. The
  unmodified upstream SHA source shifts a promoted signed int into its sign bit;
  the included UBSan probe records this issue without the flag and its absence
  with the flag. It is not a decompiler regression.
- `-fno-strict-aliasing` is common to original and recompiled libraries so that
  the low-level aliasing in the emitted code is not silently assumed away.
- Stack-protector instrumentation is excluded from this compiler experiment,
  not recommended to be disabled in deployed software.

## Source metrics

`scripts/metrics.py` counts C lexical tokens only inside function definitions.
It excludes comments, whitespace, declarations of types, standalone prototypes,
constant tables, and compatibility helpers on BOTH sides. This is not a count
of all source needed to build the output. Excluding Ghidra's support code favors
the decompiler. Inactive preprocessor branches are removed; both the original
macro-preserving and fully expanded definitions are archived in `src/`.

Machine bytes are the sum of LLVM nm symbol sizes for library functions,
including private helpers. They exclude alignment padding, rodata, the ELF
container, runtime startup and libc. Section sizes are separately archived.

## Round trips

- `decompiled/` is untouched Ghidra function output, grouped by library and
  also available per function. ELF/runtime scaffolding is intentionally omitted.
- `scripts/roundtrip.py` does bounded mechanical normalization: explicit-width
  Ghidra typedefs, prototypes, constant-table recovery, and the two 128-bit lane
  interleaves needed by the native jsmn output. It is NOT a general converter.
  Unaligned machine-width typedefs are explicit Clang extensions.
- `raw_with_declarations.c` is a syntax probe with declarations/support only;
  `normalized.c` adds the vector spelling changes. Both are archived along with
  actual compile diagnostics. Compiler success alone is NOT correctness.
- `scripts/repair_jsmn.py` is a separately labeled, human-directed SEMANTIC
  repair. It inserts four unsigned casts into each O3/Oz parser to restore
  machine range-check behavior. The exact diffs are archived. This is not part
  of the automatic result and is not a generally safe regex rewrite.
- Correctness checks run before performance comparisons. Failing automatic
  round trips are not benchmarked as useful optimizations.

## Testing and timing

Each original build: 12,000 seeded JSON cases / 17,354 parse calls (including
malformed/truncated input, incremental parsing, capacity limits and count-only
mode), 500 QOI images / 1,500 decodes checked against pixels and an independent
Python decoder, and 1,200 SHA digests with padding boundaries and random update
chunks checked against hashlib. Compare JSON return values AND parser/token
memory with the O0 implementation. No formal equivalence claim is made.

Each repaired parser: the same tests, then 100,000 held-out cases with another
seed. Separate small ASan/UBSan probes are diagnostic checks, not full fuzzing.

Benchmarks: C clock_gettime(CLOCK_MONOTONIC) inside the operation loop; 11
randomized-order samples per combination, about 180 ms target per sample, pinned
to CPU 2. JSON parses the archived actual GitHub release response. SHA hashes a
1 MiB source-code corpus. QOI processes a 512x512 synthetic RGBA image combining
flat, gradient, palette and noise regions. Timings include QOI allocation/free,
exclude file I/O and process startup, and exclude encoder setup for decode.
Turbo/governor and the shared host are unmodified. Medians and IQRs are supplied;
small differences are not a general performance guarantee.

## Licensing

The upstream jsmn and QOI sources are MIT-licensed; their license files are
included. Brad Conte's SHA source is public domain according to the pinned
upstream README, included in `upstream/sha256/README.md`. Decompiler outputs are
derivatives of these sources and should retain their original attribution.
Experiment scripts, harnesses and article data may be reused under the MIT
license in `LICENSE` (upstream licenses remain in force).
