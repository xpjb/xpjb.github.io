static void qoi_write_32(unsigned char *bytes, int *p, unsigned int v) {
 bytes[(*p)++] = (0xff000000 & v) >> 24;
 bytes[(*p)++] = (0x00ff0000 & v) >> 16;
 bytes[(*p)++] = (0x0000ff00 & v) >> 8;
 bytes[(*p)++] = (0x000000ff & v);
}

static unsigned int qoi_read_32(const unsigned char *bytes, int *p) {
 unsigned int a = bytes[(*p)++];
 unsigned int b = bytes[(*p)++];
 unsigned int c = bytes[(*p)++];
 unsigned int d = bytes[(*p)++];
 return a << 24 | b << 16 | c << 8 | d;
}

void *qoi_encode(const void *data, const qoi_desc *desc, int *out_len) {
 int i, max_size, p, run;
 int px_len, px_end, px_pos, channels;
 unsigned char *bytes;
 const unsigned char *pixels;
 qoi_rgba_t index[64];
 qoi_rgba_t px, px_prev;

 if (
  data == ((void*)0) || out_len == ((void*)0) || desc == ((void*)0) ||
  desc->width == 0 || desc->height == 0 ||
  desc->channels < 3 || desc->channels > 4 ||
  desc->colorspace > 1 ||
  desc->height >= ((unsigned int)400000000) / desc->width
 ) {
  return ((void*)0);
 }

 max_size =
  desc->width * desc->height * (desc->channels + 1) +
  14 + sizeof(qoi_padding);

 p = 0;
 bytes = (unsigned char *) malloc(max_size);
 if (!bytes) {
  return ((void*)0);
 }

 qoi_write_32(bytes, &p, (((unsigned int)'q') << 24 | ((unsigned int)'o') << 16 | ((unsigned int)'i') << 8 | ((unsigned int)'f')));
 qoi_write_32(bytes, &p, desc->width);
 qoi_write_32(bytes, &p, desc->height);
 bytes[p++] = desc->channels;
 bytes[p++] = desc->colorspace;


 pixels = (const unsigned char *)data;

 memset((index),0,sizeof(index));

 run = 0;
 px_prev.rgba.r = 0;
 px_prev.rgba.g = 0;
 px_prev.rgba.b = 0;
 px_prev.rgba.a = 255;
 px = px_prev;

 px_len = desc->width * desc->height * desc->channels;
 px_end = px_len - desc->channels;
 channels = desc->channels;

 for (px_pos = 0; px_pos < px_len; px_pos += channels) {
  px.rgba.r = pixels[px_pos + 0];
  px.rgba.g = pixels[px_pos + 1];
  px.rgba.b = pixels[px_pos + 2];

  if (channels == 4) {
   px.rgba.a = pixels[px_pos + 3];
  }

  if (px.v == px_prev.v) {
   run++;
   if (run == 62 || px_pos == px_end) {
    bytes[p++] = 0xc0 | (run - 1);
    run = 0;
   }
  }
  else {
   int index_pos;

   if (run > 0) {
    bytes[p++] = 0xc0 | (run - 1);
    run = 0;
   }

   index_pos = (px.rgba.r*3 + px.rgba.g*5 + px.rgba.b*7 + px.rgba.a*11) & (64 - 1);

   if (index[index_pos].v == px.v) {
    bytes[p++] = 0x00 | index_pos;
   }
   else {
    index[index_pos] = px;

    if (px.rgba.a == px_prev.rgba.a) {
     signed char vr = px.rgba.r - px_prev.rgba.r;
     signed char vg = px.rgba.g - px_prev.rgba.g;
     signed char vb = px.rgba.b - px_prev.rgba.b;

     signed char vg_r = vr - vg;
     signed char vg_b = vb - vg;

     if (
      vr > -3 && vr < 2 &&
      vg > -3 && vg < 2 &&
      vb > -3 && vb < 2
     ) {
      bytes[p++] = 0x40 | (vr + 2) << 4 | (vg + 2) << 2 | (vb + 2);
     }
     else if (
      vg_r > -9 && vg_r < 8 &&
      vg > -33 && vg < 32 &&
      vg_b > -9 && vg_b < 8
     ) {
      bytes[p++] = 0x80 | (vg + 32);
      bytes[p++] = (vg_r + 8) << 4 | (vg_b + 8);
     }
     else {
      bytes[p++] = 0xfe;
      bytes[p++] = px.rgba.r;
      bytes[p++] = px.rgba.g;
      bytes[p++] = px.rgba.b;
     }
    }
    else {
     bytes[p++] = 0xff;
     bytes[p++] = px.rgba.r;
     bytes[p++] = px.rgba.g;
     bytes[p++] = px.rgba.b;
     bytes[p++] = px.rgba.a;
    }
   }
  }
  px_prev = px;
 }

 for (i = 0; i < (int)sizeof(qoi_padding); i++) {
  bytes[p++] = qoi_padding[i];
 }

 *out_len = p;
 return bytes;
}

void *qoi_decode(const void *data, int size, qoi_desc *desc, int channels) {
 const unsigned char *bytes;
 unsigned int header_magic;
 unsigned char *pixels;
 qoi_rgba_t index[64];
 qoi_rgba_t px;
 int px_len, chunks_len, px_pos;
 int p = 0, run = 0;

 if (
  data == ((void*)0) || desc == ((void*)0) ||
  (channels != 0 && channels != 3 && channels != 4) ||
  size < 14 + (int)sizeof(qoi_padding)
 ) {
  return ((void*)0);
 }

 bytes = (const unsigned char *)data;

 header_magic = qoi_read_32(bytes, &p);
 desc->width = qoi_read_32(bytes, &p);
 desc->height = qoi_read_32(bytes, &p);
 desc->channels = bytes[p++];
 desc->colorspace = bytes[p++];

 if (
  desc->width == 0 || desc->height == 0 ||
  desc->channels < 3 || desc->channels > 4 ||
  desc->colorspace > 1 ||
  header_magic != (((unsigned int)'q') << 24 | ((unsigned int)'o') << 16 | ((unsigned int)'i') << 8 | ((unsigned int)'f')) ||
  desc->height >= ((unsigned int)400000000) / desc->width
 ) {
  return ((void*)0);
 }

 if (channels == 0) {
  channels = desc->channels;
 }

 px_len = desc->width * desc->height * channels;
 pixels = (unsigned char *) malloc(px_len);
 if (!pixels) {
  return ((void*)0);
 }

 memset((index),0,sizeof(index));
 px.rgba.r = 0;
 px.rgba.g = 0;
 px.rgba.b = 0;
 px.rgba.a = 255;

 chunks_len = size - (int)sizeof(qoi_padding);
 for (px_pos = 0; px_pos < px_len; px_pos += channels) {
  if (run > 0) {
   run--;
  }
  else if (p < chunks_len) {
   int b1 = bytes[p++];

   if (b1 == 0xfe) {
    px.rgba.r = bytes[p++];
    px.rgba.g = bytes[p++];
    px.rgba.b = bytes[p++];
   }
   else if (b1 == 0xff) {
    px.rgba.r = bytes[p++];
    px.rgba.g = bytes[p++];
    px.rgba.b = bytes[p++];
    px.rgba.a = bytes[p++];
   }
   else if ((b1 & 0xc0) == 0x00) {
    px = index[b1];
   }
   else if ((b1 & 0xc0) == 0x40) {
    px.rgba.r += ((b1 >> 4) & 0x03) - 2;
    px.rgba.g += ((b1 >> 2) & 0x03) - 2;
    px.rgba.b += ( b1 & 0x03) - 2;
   }
   else if ((b1 & 0xc0) == 0x80) {
    int b2 = bytes[p++];
    int vg = (b1 & 0x3f) - 32;
    px.rgba.r += vg - 8 + ((b2 >> 4) & 0x0f);
    px.rgba.g += vg;
    px.rgba.b += vg - 8 + (b2 & 0x0f);
   }
   else if ((b1 & 0xc0) == 0xc0) {
    run = (b1 & 0x3f);
   }

   index[(px.rgba.r*3 + px.rgba.g*5 + px.rgba.b*7 + px.rgba.a*11) & (64 - 1)] = px;
  }

  pixels[px_pos + 0] = px.rgba.r;
  pixels[px_pos + 1] = px.rgba.g;
  pixels[px_pos + 2] = px.rgba.b;

  if (channels == 4) {
   pixels[px_pos + 3] = px.rgba.a;
  }
 }

 return pixels;
}
