#include "../upstream/sha256/sha256.c"
int main(void) { unsigned char d[64]={255}, out[32]; SHA256_CTX ctx; sha256_init(&ctx); sha256_update(&ctx,d,64); sha256_final(&ctx,out); return 0; }
