/* Library implementations are unmodified upstream sources. Only file I/O wrappers
 * for QOI are disabled. These are the same APIs in every build. */
#define JSMN_STRICT
#include "../upstream/jsmn/jsmn.h"
#define QOI_IMPLEMENTATION
#define QOI_NO_STDIO
#include "../upstream/qoi/qoi.h"
#include "../upstream/sha256/sha256.c"
