#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <dlfcn.h>
#define JSMN_HEADER
#include "../upstream/jsmn/jsmn.h"
#define QOI_NO_STDIO
#include "../upstream/qoi/qoi.h"
#include "../upstream/sha256/sha256.h"
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+t.tv_nsec*1e-9; }
static unsigned char *readall(const char *name,size_t *n) {
  FILE *f=fopen(name,"rb"); if(!f){perror(name);exit(2);} fseek(f,0,SEEK_END);*n=ftell(f);rewind(f);
  unsigned char *p=malloc(*n+1);if(!p || fread(p,1,*n,f)!=*n)exit(2);p[*n]=0;fclose(f);return p;
}
#define LOAD(name) __typeof__(&name) f_##name=(__typeof__(&name))dlsym(lib,#name);if(!f_##name){fprintf(stderr,"missing %s\n",#name);return 2;}
int main(int argc,char **argv) {
  if(argc!=5){fprintf(stderr,"usage: bench LIB WORKLOAD INPUT ITERATIONS\n");return 2;}
  void *lib=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);if(!lib){fprintf(stderr,"%s\n",dlerror());return 2;}
  size_t n;unsigned char *input=readall(argv[3],&n);uint64_t iters=strtoull(argv[4],0,10),sum=0;double start,elapsed;
  if(!strcmp(argv[2],"jsmn")) {
    LOAD(jsmn_init);LOAD(jsmn_parse);jsmntok_t *tokens=calloc(n+1,sizeof(*tokens));jsmn_parser parser;
    f_jsmn_init(&parser);int check=f_jsmn_parse(&parser,(char*)input,n,tokens,n+1);if(check<0)return 3;
    start=now();
    for(uint64_t i=0;i<iters;i++){f_jsmn_init(&parser);int r=f_jsmn_parse(&parser,(char*)input,n,tokens,n+1);sum+=(unsigned)r;sum+=tokens[(unsigned)i%(unsigned)check].end;}
    elapsed=now()-start;free(tokens);
  } else if(!strcmp(argv[2],"sha256")) {
    LOAD(sha256_init);LOAD(sha256_update);LOAD(sha256_final);SHA256_CTX ctx;unsigned char out[32];
    start=now();
    for(uint64_t i=0;i<iters;i++){f_sha256_init(&ctx);f_sha256_update(&ctx,input,n);f_sha256_final(&ctx,out);sum+=out[i%32];}
    elapsed=now()-start;
  } else {
    LOAD(qoi_encode);LOAD(qoi_decode);qoi_desc desc={512,512,4,0};if(n!=512*512*4)return 4;
    int encoded_size;void *encoded=f_qoi_encode(input,&desc,&encoded_size);if(!encoded)return 5;
    if(!strcmp(argv[2],"qoi_encode")){
      start=now();
      for(uint64_t i=0;i<iters;i++){int len;unsigned char *out=f_qoi_encode(input,&desc,&len);if(!out)return 6;sum+=len;sum+=out[i%(unsigned)len];free(out);}
      elapsed=now()-start;
    }else if(!strcmp(argv[2],"qoi_decode")){
      start=now();
      for(uint64_t i=0;i<iters;i++){qoi_desc d;unsigned char *out=f_qoi_decode(encoded,encoded_size,&d,4);if(!out)return 7;sum+=out[i%n];free(out);}
      elapsed=now()-start;
    }else return 8;
    free(encoded);
  }
  printf("{\"seconds\":%.9f,\"iterations\":%llu,\"bytes_per_iteration\":%zu,\"checksum\":%llu,\"ns_per_op\":%.3f,\"MiB_per_s\":%.3f}\n",elapsed,(unsigned long long)iters,n,(unsigned long long)sum,elapsed*1e9/iters,(double)n*iters/1048576.0/elapsed);
  free(input);dlclose(lib);return 0;
}
