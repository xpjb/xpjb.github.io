#include <stdio.h>
#include <string.h>
#define JSMN_HEADER
#include "../upstream/jsmn/jsmn.h"
#include "../upstream/sha256/sha256.h"
int main(void) {
#ifdef CHECK_JSON
  jsmn_parser p; jsmntok_t t[32];
  const char *cases[]={"{\"x\":[1,true,null,\"ok\"]}","\"\\u!000\"","\"\\u0000\"",";123 ","\007} "};
  for(unsigned i=0;i<sizeof(cases)/sizeof(*cases);i++){
    jsmn_init(&p);int n=jsmn_parse(&p,cases[i],strlen(cases[i]),t,32);printf("json %u -> %d\n",i,n);
  }
#else
  SHA256_CTX ctx;unsigned char out[32];sha256_init(&ctx);sha256_update(&ctx,(const unsigned char*)"",0);sha256_final(&ctx,out);
  for(int i=0;i<32;i++)printf("%02x",out[i]);puts("");
#endif
  return 0;
}
