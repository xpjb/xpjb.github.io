/* Narrow x86-64 LP64 compatibility layer, not a general Ghidra-to-C converter.
 * The two vector operations below are exactly the lane interleaves used by
 * these jsmn outputs. Other Ghidra p-code intrinsics remain unsupported. */
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
typedef uint8_t byte;
typedef uint8_t undefined;
typedef uint8_t undefined1;
/* Wide machine loads/stores need not be naturally aligned on x86-64. */
typedef uint16_t undefined2 __attribute__((aligned(1)));
typedef uint32_t undefined4 __attribute__((aligned(1)));
typedef uint64_t undefined8 __attribute__((aligned(1)));
typedef uint16_t ushort;
typedef uint32_t uint;
typedef uint64_t ulong;
typedef uint64_t ulonglong;
typedef int64_t longlong;
typedef void code(void);
#define CONCAT11(a,b) (((uint32_t)(uint8_t)(a)<<8)|(uint8_t)(b))
#define CONCAT12(a,b) (((uint32_t)(uint8_t)(a)<<16)|((uint32_t)(b)&0xffffu))
#define CONCAT13(a,b) (((uint32_t)(uint8_t)(a)<<24)|((uint32_t)(b)&0xffffffu))
#define CONCAT14(a,b) (((uint64_t)(uint8_t)(a)<<32)|(uint32_t)(b))
#define CONCAT44(a,b) (((uint64_t)(uint32_t)(a)<<32)|(uint32_t)(b))
typedef uint32_t vec16 __attribute__((vector_size(16),aligned(1)));
static inline vec16 ZEXT416(uint32_t x) { return (vec16){x,0,0,0}; }
static inline vec16 vpunpckldq_avx(vec16 a,vec16 b) { return (vec16){a[0],b[0],a[1],b[1]}; }
static inline vec16 vpunpcklqdq_avx(vec16 a,vec16 b) { return (vec16){a[0],a[1],b[0],b[1]}; }
