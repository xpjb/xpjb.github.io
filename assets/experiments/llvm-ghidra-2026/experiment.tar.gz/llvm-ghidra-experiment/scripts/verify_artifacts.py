#!/usr/bin/env python3
import json,pathlib,hashlib,subprocess,csv,io,importlib.util,re
ROOT=pathlib.Path(__file__).resolve().parents[1]
def read(name):return json.loads((ROOT/'results'/name).read_text())
checks={}
correct=read('correctness.json');original=[x for x in correct if not x['variant'].startswith('rt_')];rt=[x for x in correct if x['variant'].startswith('rt_')]
assert len(original)==18 and all(x['ok'] for x in original)
assert len(rt)==12 and not any(x['ok'] for x in rt)
checks['original_build_library_pairs_passed']=len(original)
checks['mechanically_normalized_recompiled_pairs_failed']=len(rt)
repairs=read('repaired_correctness.json');assert len(repairs)==4 and all(x['ok'] for x in repairs)
holdouts=[x for x in read('extra_checks.json') if x['kind']=='holdout'];assert len(holdouts)==4 and all(x['ok'] and x['cases']==100000 for x in holdouts)
checks['repaired_pairs_passed']=4;checks['held_out_cases_per_repaired_pair']=100000
hashes={}
for v in ['O3','O3_unroll','O3_debug','Oz','Oz_debug']:
    out=ROOT/'build'/v/'text.bin'
    subprocess.run(['llvm-objcopy','--dump-section','.text='+str(out),str(out.parent/'libraries.so')],check=True)
    hashes[v]=hashlib.sha256(out.read_bytes()).hexdigest()
assert hashes['O3']==hashes['O3_unroll']==hashes['O3_debug'];assert hashes['Oz']==hashes['Oz_debug']
checks['text_sha256']=hashes
for v in ['O0','O2','O3','Oz','O3_generic','O3_unroll','O3_debug','Oz_debug']:
    stats=list(csv.DictReader((ROOT/'decompiled'/v/'functions.tsv').read_text().splitlines(),delimiter='\t'))
    assert stats and all(row['completed']=='true' for row in stats)
checks['all_selected_functions_decompiled']=True
summary=read('benchmark_summary.json');raw=read('benchmark_raw.json')
assert len(summary)==28 and len(raw)==28*11
assert all(r['samples']==11 and r['min_ns']>0 for r in summary)
checks['timing_samples']=len(raw)
for name,info in json.loads((ROOT/'fixtures/manifest.json').read_text()).items():
    p=ROOT/'fixtures'/name;assert p.stat().st_size==info['bytes'];assert hashlib.sha256(p.read_bytes()).hexdigest()==info['sha256']
checks['fixture_hashes_verified']=True
(ROOT/'results/artifact_checks.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
