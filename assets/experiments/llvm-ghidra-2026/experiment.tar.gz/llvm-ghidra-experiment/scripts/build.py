#!/usr/bin/env python3
import subprocess, json, pathlib, platform
ROOT=pathlib.Path(__file__).resolve().parents[1]
variants={'O0':['-O0'], 'O2':['-O2'], 'O3':['-O3'], 'Oz':['-Oz'],
          'O3_generic':['-O3','-march=x86-64'],
          'O3_unroll':['-O3','-funroll-loops'],
          'O3_debug':['-O3','-g'], 'Oz_debug':['-Oz','-g']}
common=['clang','-std=c11','-shared','-fPIC','-fuse-ld=lld','-flto','-march=native','-g0','-Wl,-Bsymbolic','-fno-stack-protector','-fwrapv','-fno-strict-aliasing']
commands={}
for name, flags in variants.items():
    out=ROOT/'build'/name; out.mkdir(parents=True,exist_ok=True)
    cmd=common+flags+['src/libraries.c','-o',f'build/{name}/libraries.so']
    subprocess.run(cmd,cwd=ROOT,check=True); commands[name]=cmd
    for tool,args,filename in [('llvm-nm',['-S','--size-sort'],'symbols.txt'),('llvm-objdump',['-d'],'assembly.txt'),('llvm-size',['-A'],'sections.txt')]:
        (out/filename).write_text(subprocess.check_output([tool,*args,str(out/'libraries.so')],text=True))
    # Save the optimized IR as an inspectable control (not the final LTO IR).
    subprocess.run(['clang','-std=c11','-S','-emit-llvm','-march=native','-fno-stack-protector','-fwrapv','-fno-strict-aliasing',*flags,'src/libraries.c','-o',f'build/{name}/optimized.ll'],cwd=ROOT,check=True)
(ROOT/'results/build_commands.json').write_text(json.dumps(commands,indent=2))
(ROOT/'results/environment.txt').write_text(subprocess.check_output(['clang','--version'],text=True)+'\n'+subprocess.check_output(['lscpu'],text=True)+'\n'+platform.platform()+'\n')
print('Built:',', '.join(variants))
