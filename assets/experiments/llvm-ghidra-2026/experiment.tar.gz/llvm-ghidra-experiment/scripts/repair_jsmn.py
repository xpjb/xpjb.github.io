#!/usr/bin/env python3
"""Explicit HUMAN-DIRECTED semantic repair, separate from mechanical round-trip.
Ghidra's C byte-subtraction range checks need unsigned integer promotion to
match the original unsigned machine comparisons. NOT a general safe rewrite.
"""
import re,pathlib,subprocess,json,difflib
ROOT=pathlib.Path(__file__).resolve().parents[1]
records=[]
for v in ['O3','Oz']:
    p=ROOT/'build'/f'rt_{v}_jsmn'/'normalized.c'; before=p.read_text()
    pattern=r'((?:0x[0-9a-f]+|[0-9]+) < )((bVar[0-9]+) - (?:0x[0-9a-f]+|[0-9]+))'
    after,n=re.subn(pattern,r'\1(uint)(\2)',before)
    after,nleft=re.subn(r'(bVar[0-9]+ - (?:0x[0-9a-f]+|[0-9]+))( < (?:0x[0-9a-f]+|[0-9]+))',r'(uint)(\1)\2',after)
    n+=nleft
    dest=p.parent/'repaired.c';dest.write_text(after)
    (p.parent/'semantic-repair.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='normalized.c',tofile='repaired.c')))
    for opt in ['O3','Oz']:
        out=p.parent/f'repaired_{opt}.so'
        cmd=['clang','-std=c11','-shared','-fPIC','-flto','-fuse-ld=lld','-march=native','-fno-stack-protector','-fwrapv','-fno-strict-aliasing','-Wl,-Bsymbolic','-'+opt,str(dest),'-o',str(out)]
        subprocess.run(cmd,check=True)
        test=subprocess.run(['python3',str(ROOT/'scripts/test.py'),'--worker','jsmn',str(out)],capture_output=True,text=True)
        result=json.loads(test.stdout) if test.returncode==0 else {'ok':False,'error':test.stderr}
        records.append({'input':v,'opt':opt,'casts_added':n,'path':str(out.relative_to(ROOT)),'command':cmd,**result})
        print(v,opt,n,result.get('ok'),result.get('error','')[-500:])
(ROOT/'results/repaired_correctness.json').write_text(json.dumps(records,indent=2))
