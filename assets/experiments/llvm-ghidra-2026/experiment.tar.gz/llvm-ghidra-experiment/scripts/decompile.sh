#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-21-openjdk}"
GHIDRA_HOME="${GHIDRA_HOME:-$PWD/tools/ghidra_12.1.4_PUBLIC}"
mkdir -p build/ghidra-project
variants=("$@")
if [ ${#variants[@]} -eq 0 ]; then variants=(O0 O2 O3 Oz O3_generic O3_unroll O3_debug Oz_debug); fi
for variant in "${variants[@]}"; do
  "$GHIDRA_HOME/support/analyzeHeadless" "$PWD/build/ghidra-project" "experiment_$variant" \
    -import "$PWD/build/$variant/libraries.so" \
    -scriptPath "$PWD/scripts" -postScript ExportDecompiled.java "$PWD/decompiled/$variant" \
    -max-cpu 2 -deleteProject >"build/$variant/ghidra.log" 2>&1
  echo "Decompiled $variant"
done
