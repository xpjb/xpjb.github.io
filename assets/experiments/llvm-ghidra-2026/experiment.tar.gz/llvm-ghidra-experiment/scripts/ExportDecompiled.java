// Export only the experimental libraries, not the ELF runtime scaffolding.
// @category Experiment
import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ExportDecompiled extends GhidraScript {
    public void run() throws Exception {
        Path dest = Paths.get(getScriptArgs()[0]);
        Files.createDirectories(dest);
        DecompInterface decomp = new DecompInterface();
        DecompileOptions options = new DecompileOptions();
        options.grabFromProgram(currentProgram);
        decomp.setOptions(options);
        decomp.openProgram(currentProgram);
        StringBuilder stats = new StringBuilder("name\taddress\tbody_bytes\tcompleted\terror\n");
        for (String prefix : new String[]{"jsmn_", "qoi_", "sha256_"}) {
            StringBuilder joined = new StringBuilder();
            FunctionIterator functions = currentProgram.getFunctionManager().getFunctions(true);
            while (functions.hasNext()) {
                Function f = functions.next();
                if (f.isExternal() || f.isThunk() || !f.getName().startsWith(prefix)) continue;
                DecompileResults result = decomp.decompileFunction(f, 120, monitor);
                stats.append(f.getName()).append('\t').append(f.getEntryPoint()).append('\t')
                    .append(f.getBody().getNumAddresses()).append('\t').append(result.decompileCompleted()).append('\t')
                    .append(result.getErrorMessage().replace('\n',' ')).append('\n');
                if (result.decompileCompleted()) {
                    String code = result.getDecompiledFunction().getC();
                    Files.writeString(dest.resolve(f.getName()+".c"),code,StandardCharsets.UTF_8);
                    joined.append(code).append("\n\n");
                }
            }
            Files.writeString(dest.resolve(prefix.substring(0,prefix.length()-1)+".c"),joined.toString(),StandardCharsets.UTF_8);
        }
        Files.writeString(dest.resolve("functions.tsv"),stats.toString(),StandardCharsets.UTF_8);
        decomp.dispose();
    }
}
