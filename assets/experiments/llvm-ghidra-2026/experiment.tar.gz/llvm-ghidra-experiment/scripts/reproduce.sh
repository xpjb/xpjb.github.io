#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build results decompiled
python3 scripts/build.py
bash scripts/decompile.sh
python3 scripts/roundtrip.py
python3 scripts/test.py
python3 scripts/repair_jsmn.py
python3 scripts/extra_checks.py
python3 scripts/fixtures.py
python3 scripts/metrics.py
# Run timings only after test and analysis processes have completed.
python3 scripts/benchmark.py
python3 scripts/verify_artifacts.py
