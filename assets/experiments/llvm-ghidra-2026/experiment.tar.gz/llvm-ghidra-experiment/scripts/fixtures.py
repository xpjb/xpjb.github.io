#!/usr/bin/env python3
import pathlib,json,random,hashlib,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1];out=ROOT/'fixtures';out.mkdir(exist_ok=True)
# An actual GitHub release API response, fixed for this experiment.
source=ROOT/'tools/release.json'
if source.exists(): (out/'release.json').write_bytes(source.read_bytes())
# Hash a 1 MiB repeated source-code corpus. Hashing is content-insensitive here.
corpus=b'\n'.join(p.read_bytes() for p in sorted((ROOT/'upstream').glob('*/*')) if p.is_file() and p.name!='README.md')
(out/'hash-input.bin').write_bytes((corpus*(1048576//len(corpus)+1))[:1048576])
# Mixed-entropy 512x512 RGBA image: flat regions, gradients, palette, noise.
# Deliberately disclose synthetic data; the algorithms themselves are real upstream code.
r=random.Random(20261008); w=h=512; pixels=bytearray()
for y in range(h):
    for x in range(w):
        region=(x//128+4*(y//128))%4
        if region==0:p=(40,100,180,255)
        elif region==1:p=(x%256,y%256,(x+y)%256,255)
        elif region==2:p=r.choice([(0,0,0,0),(240,40,60,255),(30,200,100,255),(30,40,240,255)])
        else:p=(*r.randbytes(3),255)
        pixels.extend(p)
(out/'pixels.rgba').write_bytes(pixels)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.iterdir() if p.is_file() and p.name!='manifest.json'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
