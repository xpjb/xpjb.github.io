#!/usr/bin/env python3
"""Seeded differential tests, independently checked SHA256 and QOI decoding.
Each library/build runs in its own subprocess: a crash is a recorded failure.
"""
import ctypes as C, hashlib, json, random, pathlib, subprocess, sys, time, os
ROOT=pathlib.Path(__file__).resolve().parents[1]
class Parser(C.Structure): _fields_=[('pos',C.c_uint),('toknext',C.c_uint),('toksuper',C.c_int)]
class Token(C.Structure): _fields_=[('type',C.c_int),('start',C.c_int),('end',C.c_int),('size',C.c_int)]
class Sha(C.Structure): _fields_=[('data',C.c_ubyte*64),('datalen',C.c_uint),('bitlen',C.c_ulonglong),('state',C.c_uint*8)]
class Desc(C.Structure): _fields_=[('width',C.c_uint),('height',C.c_uint),('channels',C.c_ubyte),('colorspace',C.c_ubyte)]
libc=C.CDLL(None); libc.free.argtypes=[C.c_void_p]
def load(path):
    dll=C.CDLL(str(path))
    for name,args,ret in [('jsmn_init',[C.POINTER(Parser)],None),('jsmn_parse',[C.POINTER(Parser),C.c_void_p,C.c_size_t,C.POINTER(Token),C.c_uint],C.c_int),('sha256_init',[C.POINTER(Sha)],None),('sha256_update',[C.POINTER(Sha),C.c_void_p,C.c_size_t],None),('sha256_final',[C.POINTER(Sha),C.c_void_p],None),('qoi_encode',[C.c_void_p,C.POINTER(Desc),C.POINTER(C.c_int)],C.c_void_p),('qoi_decode',[C.c_void_p,C.c_int,C.POINTER(Desc),C.c_int],C.c_void_p)]:
        if hasattr(dll,name): f=getattr(dll,name); f.argtypes=args; f.restype=ret
    return dll

def json_tests(lib,ref):
    r=random.Random(int(os.environ.get('JSON_TEST_SEED','0x51a7'),0))
    def value(depth=0):
        k=r.randrange(5 if depth<4 else 3)
        if k==0:return r.choice([None,True,False])
        if k==1:return r.choice([r.randrange(-10**9,10**9),r.uniform(-1e5,1e5)])
        if k==2:return ''.join(r.choices('abcXYZ09 \\"\n\t/é漢',k=r.randrange(40)))
        if k==3:return [value(depth+1) for _ in range(r.randrange(8))]
        return {str(i)+'key':value(depth+1) for i in range(r.randrange(8))}
    def parse(dll,data,cap,steps):
        b=C.create_string_buffer(data); p=Parser(); dll.jsmn_init(C.byref(p))
        toks=(Token*max(1,cap))(); C.memset(toks,0xa5,C.sizeof(toks)); out=[]
        for n in steps:
            rc=dll.jsmn_parse(C.byref(p),b,n,toks if cap>=0 else None,max(0,cap))
            out.append((rc,bytes(p),bytes(toks)))
        return out
    fixed=[b'',b'{}',b'[]',b'{"a":[1,true,null,"x"]}',b'{',b'"abc',b'"\\u12xz"',b'"\\uabcd"',b'[{]}',b'{"a":1}\0xx',b'1 ',b'-1.234e+5 ',b'"\\"\\\\\\/\\b\\f\\n\\r\\t"']
    cases=0; calls=0
    for i in range(int(os.environ.get('JSON_TEST_CASES','12000'))):
        if i<len(fixed): data=fixed[i]
        else:
            data=json.dumps(value(),ensure_ascii=(i%2==0),separators=(',',':')).encode()+b' '
            if i%3==0:data=data[:r.randrange(len(data)+1)]
            elif i%5==0:
                b=bytearray(data)
                if b:b[r.randrange(len(b))]=r.randrange(1,128)
                data=bytes(b)
        cap=r.choice([-1,0,1,2,4,8,32,256,4096]); steps=[len(data)]
        if i%4==0:steps=sorted(set([0,r.randrange(len(data)+1),len(data)]))
        expected=parse(ref,data,cap,steps); actual=parse(lib,data,cap,steps)
        if actual!=expected: raise AssertionError(f'jsmn case {i} cap={cap} steps={steps} data={data[:160]!r}; returns {[x[0] for x in actual]} vs {[x[0] for x in expected]}')
        cases+=1; calls+=len(steps)
    return {'cases':cases,'parse_calls':calls,'oracle':'O0 return values, all parser fields and token bytes; valid/malformed/truncated JSON, token-count mode, capacity exhaustion, incremental parsing'}

def sha_tests(lib,ref):
    r=random.Random(0x5a256); cases=0; updates=0
    fixed=[b'',b'abc',b'abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq',b'a'*1000000]
    for i in range(1200):
        n=([0,1,2,55,56,57,63,64,65,119,120,127,128,129,255,256,257,4096][i%18] if i<180 else r.randrange(8193))
        data=fixed[i] if i<len(fixed) else r.randbytes(n)
        ctx=Sha(); lib.sha256_init(C.byref(ctx)); b=C.create_string_buffer(data)
        pos=0
        while pos<len(data):
            chunk=min(len(data)-pos,r.choice([1,7,55,64,65,255,4096,len(data)]))
            lib.sha256_update(C.byref(ctx),C.byref(b,pos),chunk); pos+=chunk; updates+=1
        out=(C.c_ubyte*32)(); lib.sha256_final(C.byref(ctx),out)
        expected=hashlib.sha256(data).digest()
        if bytes(out)!=expected:raise AssertionError(f'sha256 case {i} len={len(data)} got={bytes(out).hex()} expected={expected.hex()}')
        cases+=1
    return {'cases':cases,'update_calls':updates,'oracle':'Python hashlib / OpenSSL; standard vectors, padding boundaries, randomized streaming chunks'}

def decode_qoi_python(data):
    assert data[:4]==b'qoif'; w=int.from_bytes(data[4:8],'big'); h=int.from_bytes(data[8:12],'big'); ch=data[12]
    index=[(0,0,0,0)]*64; px=(0,0,0,255); p=14; out=bytearray(); run=0
    for _ in range(w*h):
        if run: run-=1
        else:
            b=data[p];p+=1
            if b==254:px=tuple(data[p:p+3])+(px[3],);p+=3
            elif b==255:px=tuple(data[p:p+4]);p+=4
            elif b>>6==0:px=index[b]
            elif b>>6==1:px=tuple((px[i]+((b>>(4-2*i))&3)-2)&255 for i in range(3))+(px[3],)
            elif b>>6==2:
                c=data[p];p+=1;g=(b&63)-32
                px=((px[0]+g+(c>>4)-8)&255,(px[1]+g)&255,(px[2]+g+(c&15)-8)&255,px[3])
            else:run=b&63
            index[(px[0]*3+px[1]*5+px[2]*7+px[3]*11)%64]=px
        out.extend(px[:ch])
    return bytes(out)

def qoi_tests(lib,ref):
    r=random.Random(0xc01); cases=0
    def encode(dll,raw,d):
        n=C.c_int(); p=dll.qoi_encode(raw,C.byref(d),C.byref(n)); assert p
        result=C.string_at(p,n.value);libc.free(p);return result
    for i in range(500):
        w=r.randrange(1,65);h=r.randrange(1,65); ch=r.choice([3,4]);d=Desc(w,h,ch,i%2)
        mode=i%5
        if mode==0:raw=bytes([77,110,200,255][:ch])*(w*h)
        elif mode==1:raw=r.randbytes(w*h*ch)
        elif mode==2:raw=bytes((x//32)%256 if x%ch!=3 else 255 for x in range(w*h*ch))
        elif mode==3:
            palette=[r.randbytes(ch) for _ in range(12)];raw=b''.join(r.choice(palette) for _ in range(w*h))
        else:
            px=list(r.randbytes(ch));pixels=[]
            for _ in range(w*h):
                px=[(x+r.randrange(-2,3))&255 if j<3 else 255 for j,x in enumerate(px)];pixels.extend(px)
            raw=bytes(pixels)
        expected=encode(ref,raw,d); encoded=encode(lib,raw,d)
        assert encoded==expected,f'QOI encoding differs case {i}'
        assert decode_qoi_python(encoded)==raw,f'QOI Python oracle case {i}'
        for out_ch in [0,3,4]:
            desc=Desc(); p=lib.qoi_decode(encoded,len(encoded),C.byref(desc),out_ch); assert p
            c=out_ch or ch;decoded=C.string_at(p,w*h*c);libc.free(p)
            converted=b''.join(raw[j:j+3]+(bytes([raw[j+3] if ch==4 else 255]) if c==4 else b'') for j in range(0,len(raw),ch))
            assert decoded==converted,f'QOI decoding differs case {i}, channels={c}'
            assert (desc.width,desc.height,desc.channels,desc.colorspace)==(w,h,ch,d.colorspace)
        cases+=1
    return {'cases':cases,'decode_calls':cases*3,'oracle':'Bit-identical encoder vs O0; independent Python QOI decoder; original RGB/RGBA pixels and forced-channel conversion'}

def worker(libname,path):
    lib=load(path);ref=load(ROOT/'build/O0/libraries.so')
    start=time.monotonic(); result={'jsmn':json_tests,'sha256':sha_tests,'qoi':qoi_tests}[libname](lib,ref)
    print(json.dumps({'ok':True,**result,'seconds':time.monotonic()-start}))

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--worker': worker(sys.argv[2],sys.argv[3]);sys.exit()
    records=[]
    jobs=[]
    for v in ['O0','O2','O3','Oz','O3_generic','O3_unroll']:
        for lib in ['jsmn','qoi','sha256']:jobs.append((v,lib,ROOT/'build'/v/'libraries.so'))
    for rec in json.loads((ROOT/'results/roundtrip_compile.json').read_text()):
        for opt,info in rec['normalized'].items():
            if info['ok']: jobs.append((f"rt_{rec['variant']}_{opt}",rec['library'],ROOT/'build'/f"rt_{rec['variant']}_{rec['library']}"/f'recompiled_{opt}.so'))
    for v,lib,path in jobs:
        p=subprocess.run([sys.executable,__file__,'--worker',lib,str(path)],capture_output=True,text=True,timeout=120)
        result=json.loads(p.stdout) if p.returncode==0 else {'ok':False,'returncode':p.returncode,'error':p.stderr[-5000:]}
        records.append({'variant':v,'library':lib,'path':str(path.relative_to(ROOT)),**result})
        print(v,lib,result.get('ok'),result.get('cases'),result.get('error','')[-250:],flush=True)
        (ROOT/'results/correctness.json').write_text(json.dumps(records,indent=2))
