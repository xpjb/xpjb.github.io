#!/usr/bin/env python3
"""Count C lexical tokens in FUNCTION DEFINITIONS only; ignore whitespace,
comments, preprocessor directives, data tables, type definitions and prototypes.
Both macro-preserving (inactive branches removed) and expanded input are saved.
"""
import pathlib,json,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
VARIANTS=['O0','O2','O3','Oz','O3_generic','O3_unroll','O3_debug','Oz_debug']
# A lexer, not an identifier/word counter; string/character literals count once.
lex=re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|(?:u8|[LuU])?"(?:\\.|[^"\\])*"|(?:[LuU])?\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|(?:0[xX][0-9a-fA-F]+|\d+(?:\.\d*)?)(?:[eEpP][+-]?\d+)?[uUlLfF]*|>>=|<<=|\.\.\.|->|\+\+|--|<<|>>|<=|>=|==|!=|&&|\|\||[+*/%&|^!-]=|[^\s]')
def tokens(s):
    s=re.sub(r'^\s*#.*$','',s,flags=re.M)
    return [m.group() for m in lex.finditer(s) if not m.group().startswith(('/*','//'))]
def measure(s):
    t=tokens(s)
    return dict(tokens=len(t),compact_chars=sum(map(len,t)),gotos=t.count('goto'),semicolons=t.count(';'),code_lines=len([l for l in re.sub(r'/\*[\s\S]*?\*/|//[^\n]*','',s).splitlines() if l.strip() and not l.lstrip().startswith('#')]))
def location(d): return d.get('expansionLoc',d)
rows=[]
per_function=[]
for label,opts in [('source',['-fdirectives-only']),('expanded',[])]:
    code=subprocess.check_output(['clang','-E',*opts,'src/libraries.c'],cwd=ROOT,text=True)
    path=ROOT/'build'/f'original_{label}.c';path.write_text(code)
    ast=json.loads(subprocess.check_output(['clang','-Xclang','-ast-dump=json','-fsyntax-only',str(path)],text=True))
    gathered={lib:[] for lib in ['jsmn','qoi','sha256']}
    for node in ast['inner']:
        if node.get('kind')!='FunctionDecl' or not any(x['kind']=='CompoundStmt' for x in node.get('inner',[])):continue
        name=node.get('name',''); lib=name.split('_')[0]
        if lib not in gathered:continue
        begin=location(node['range']['begin']);end=location(node['range']['end'])
        definition=code[begin['offset']:end['offset']+end['tokLen']]
        gathered[lib].append(definition)
        per_function.append({'variant':label,'library':lib,'function':name,**measure(definition)})
    for lib,defs in gathered.items():
        text='\n\n'.join(defs)+'\n';p=ROOT/'src'/f'{lib}_{label}_functions.c';p.write_text(text)
        rows.append({'variant':label,'library':lib,'functions':len(defs),**measure(text)})
for v in VARIANTS:
    syms=subprocess.check_output(['llvm-nm','-S',str(ROOT/'build'/v/'libraries.so')],text=True)
    for lib in ['jsmn','qoi','sha256']:
        text=(ROOT/'decompiled'/v/(lib+'.c')).read_text()
        for p in sorted((ROOT/'decompiled'/v).glob(lib+'_*.c')):
            per_function.append({'variant':v,'library':lib,'function':p.stem,**measure(p.read_text())})
        sizes=[int(m[1],16) for m in re.findall(r'^([\da-f]+)\s+([\da-f]+)\s+[tT]\s+('+lib+r'_\S+)$',syms,re.M)]
        rows.append({'variant':v,'library':lib,'functions':len(sizes),'function_machine_bytes':sum(sizes),**measure(text)})
(ROOT/'results/source_metrics.json').write_text(json.dumps(rows,indent=2))
(ROOT/'results/function_metrics.json').write_text(json.dumps(per_function,indent=2))
for lib in ['jsmn','qoi','sha256']:
    print('\n'+lib)
    for r in rows:
        if r['library']==lib: print(r['variant'],r['tokens'],r['code_lines'],r['gotos'],r.get('function_machine_bytes',''))
# Per-function and aggregate recompiled machine code sizes, excluding shims
# if they inline; report any remaining helpers too.
recompiled=[]
for p in (ROOT/'build').glob('rt_*/*.so'):
    syms=subprocess.check_output(['llvm-nm','-S',str(p)],text=True)
    sizes={name:int(size,16) for addr,size,name in re.findall(r'^([\da-f]+)\s+([\da-f]+)\s+[tT]\s+(\S+)$',syms,re.M)}
    recompiled.append({'path':str(p.relative_to(ROOT)),'function_sizes':sizes,'function_machine_bytes':sum(sizes.values())})
(ROOT/'results/roundtrip_sizes.json').write_text(json.dumps(recompiled,indent=2))
