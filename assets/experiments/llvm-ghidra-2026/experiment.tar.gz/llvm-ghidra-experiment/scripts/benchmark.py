#!/usr/bin/env python3
import pathlib,subprocess,json,random,statistics,time,os
ROOT=pathlib.Path(__file__).resolve().parents[1]
CPU=int(os.environ.get('BENCH_CPU','2')); ROUNDS=11; TARGET_SECONDS=.18
subprocess.run(['clang','-O3','-march=native','src/bench.c','-ldl','-o','build/bench'],cwd=ROOT,check=True)
variants=['O0','O2','O3','Oz','O3_generic','O3_unroll']
jobs=[]
for v in variants:
    for w in ['jsmn','sha256','qoi_encode','qoi_decode']:jobs.append((v,w,f'build/{v}/libraries.so'))
for r in json.loads((ROOT/'results/repaired_correctness.json').read_text()):
    if r['ok']:jobs.append((f"repaired_{r['input']}_{r['opt']}",'jsmn',r['path']))
inputs={'jsmn':'fixtures/release.json','sha256':'fixtures/hash-input.bin','qoi_encode':'fixtures/pixels.rgba','qoi_decode':'fixtures/pixels.rgba'}
def run(v,w,path,iters):
    p=subprocess.run(['taskset','-c',str(CPU),'build/bench',str(ROOT/path),w,inputs[w],str(iters)],cwd=ROOT,check=True,capture_output=True,text=True)
    return json.loads(p.stdout)
iterations={};checksums={}
for v,w,p in jobs:
    trial=run(v,w,p,20 if w=='jsmn' else 2)
    iterations[v,w]=max(1,round(TARGET_SECONDS/(trial['ns_per_op']*1e-9)))
raw=[];rng=random.Random(519)
for trial_round in range(ROUNDS):
    order=jobs[:];rng.shuffle(order)
    for v,w,p in order:
        res=run(v,w,p,iterations[v,w]);raw.append(dict(variant=v,workload=w,round=trial_round,**res))
    (ROOT/'results/benchmark_raw.json').write_text(json.dumps(raw,indent=2))
    print('round',trial_round+1,'of',ROUNDS,flush=True)
summary=[]
for v,w,p in jobs:
    samples=[r['ns_per_op'] for r in raw if r['variant']==v and r['workload']==w]
    mib=[r['MiB_per_s'] for r in raw if r['variant']==v and r['workload']==w]
    q=statistics.quantiles(samples,n=4,method='inclusive')
    summary.append({'variant':v,'workload':w,'samples':len(samples),'median_ns':statistics.median(samples),'q1_ns':q[0],'q3_ns':q[2],'min_ns':min(samples),'max_ns':max(samples),'median_MiB_s':statistics.median(mib)})
(ROOT/'results/benchmark_summary.json').write_text(json.dumps(summary,indent=2))
(ROOT/'results/benchmark_method.json').write_text(json.dumps({'cpu':CPU,'rounds':ROUNDS,'target_seconds_per_sample':TARGET_SECONDS,'order_seed':519,'timer':'CLOCK_MONOTONIC inside C loop','timed':'Library operations, including allocation/free for QOI; excludes file I/O, dynamic loading, process launch, QOI decoder input encoding','clock_policy':'Unmodified system governor/turbo; shared, not isolated host','iterations':{v+':'+w:n for (v,w),n in iterations.items()}},indent=2))
for r in summary:print(r['variant'],r['workload'],round(r['median_ns']),r['median_MiB_s'])
