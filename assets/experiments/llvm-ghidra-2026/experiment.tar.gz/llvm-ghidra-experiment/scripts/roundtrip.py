#!/usr/bin/env python3
"""Only mechanical normalization: typedefs, prototypes, 16-byte vector spelling,
ELF read-only data. No rewriting of control flow, algorithms, or stack layout.
Compilation success is NOT correctness; test.py must follow.
"""
import pathlib, re, subprocess, json
ROOT=pathlib.Path(__file__).resolve().parents[1]
VARIANTS=['O0','O2','O3','Oz','O3_generic','O3_unroll']
records=[]
for variant in VARIANTS:
    elf=ROOT/'build'/variant/'libraries.so'
    sections=subprocess.check_output(['readelf','-SW',str(elf)],text=True)
    m=re.search(r'\.rodata\s+\S+\s+([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)',sections)
    addr,off,size=map(lambda s:int(s,16),m.groups()); rodata=elf.read_bytes()[off:off+size]
    symbols=subprocess.check_output(['llvm-nm','-S',str(elf)],text=True)
    k_match=re.search(r'^([0-9a-f]+)\s+([0-9a-f]+)\s+r\s+k$',symbols,re.M)
    for lib in ['jsmn','qoi','sha256']:
        dest=ROOT/'build'/f'rt_{variant}_{lib}'; dest.mkdir(exist_ok=True)
        code=(ROOT/'decompiled'/variant/(lib+'.c')).read_text()
        # Recreate declarations from the decompiler's OWN signatures, not the source.
        prototypes=[]
        for fn in sorted((ROOT/'decompiled'/variant).glob(lib+'_*.c')):
            part=re.sub(r'/\*[\s\S]*?\*/','',fn.read_text())
            signature=part.split('{',1)[0].strip()
            if signature: prototypes.append(signature+';')
        preamble='#include "../../src/ghidra_compat.h"\n'+'\n'.join(prototypes)+'\n'
        if k_match and lib=='sha256':
            ka,ks=map(lambda s:int(s,16),k_match.groups()); kb=rodata[ka-addr:ka-addr+ks]
            values=[int.from_bytes(kb[i:i+4],'little') for i in range(0,len(kb),4)]
            preamble+='static const uint32_t k[] = {'+','.join(hex(x) for x in values)+'};\n'
        globals=sorted(set(re.findall(r'(?<!_)\bDAT_([0-9a-f]+)\b',code)))
        if globals:
            preamble+='static const unsigned char elf_rodata[] __attribute__((aligned(32))) = {'+','.join(str(b) for b in rodata)+'};\n'
        for symbol in globals:
            offset=int(symbol,16)-0x100000-addr
            assert 0 <= offset < len(rodata)
            preamble+=f'#define DAT_{symbol} (*(const uint32_t *)(elf_rodata + {offset}))\n'
        (dest/'raw_with_declarations.c').write_text(preamble+code)
        raw_cmd=['clang','-std=c11','-fsyntax-only','-Wno-int-conversion','-Wno-incompatible-pointer-types','-ferror-limit=0',str(dest/'raw_with_declarations.c')]
        p=subprocess.run(raw_cmd,capture_output=True,text=True)
        (dest/'raw-compile.log').write_text(p.stderr)
        # Arrays representing XMM values are expressions in Ghidra C, not C arrays.
        # This syntax-only lowering supports jsmn. More complicated cases fail.
        normalized=re.sub(r'undefined1 (au\w+) \[16\]',r'vec16 \1',code)
        normalized=re.sub(r'undefined1 \(\*\) \[16\]',r'vec16 *',normalized)
        (dest/'normalized.c').write_text(preamble+normalized)
        compile_results={}
        for opt in ['O3','Oz']:
            cmd=['clang','-std=c11','-shared','-fPIC','-flto','-fuse-ld=lld','-march=native','-fno-stack-protector','-fwrapv','-fno-strict-aliasing','-Wl,-Bsymbolic','-Wno-int-conversion','-Wno-incompatible-pointer-types','-ferror-limit=0','-'+opt,str(dest/'normalized.c'),'-o',str(dest/('recompiled_'+opt+'.so'))]
            result=subprocess.run(cmd,capture_output=True,text=True)
            (dest/('compile_'+opt+'.log')).write_text(result.stderr)
            compile_results[opt]={'ok':result.returncode==0,'command':cmd,'errors':len(re.findall(r' error:',result.stderr))}
        records.append({'variant':variant,'library':lib,'raw_with_declarations_ok':p.returncode==0,'raw_errors':len(re.findall(r' error:',p.stderr)),'normalized':compile_results})
        print(variant,lib,'raw',p.returncode==0,'normalized',compile_results['O3']['ok'])
(ROOT/'results/roundtrip_compile.json').write_text(json.dumps(records,indent=2))
