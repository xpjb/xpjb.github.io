#!/usr/bin/env python3
"""Create the public data bundle and chart. The Ghidra distribution is excluded."""
import pathlib,tarfile,json,hashlib,shutil,sys,html
ROOT=pathlib.Path(__file__).resolve().parents[1]
DEST=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'public'
DEST.mkdir(parents=True,exist_ok=True);(DEST/'raw').mkdir(exist_ok=True)
for p in (ROOT/'results').glob('*.json'): shutil.copy2(p,DEST/p.name)
for lib in ['jsmn','qoi','sha256']:
    for variant in ['O3','Oz']:
        shutil.copy2(ROOT/'decompiled'/variant/(lib+'.c'),DEST/'raw'/f'{lib}-{variant}.c')
rows=json.loads((ROOT/'results/source_metrics.json').read_text())
data={(r['variant'],r['library']):r for r in rows}
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="840" height="424" viewBox="0 0 840 424" role="img" aria-labelledby="title desc">',
'<title id="title">Optimized binaries decompile into longer source</title>',
'<desc id="desc">C lexical tokens in functions. jsmn: original 1493, O3 2235, Oz 1986. QOI: original 1754, O3 3562, Oz 3611. SHA256: original 1028, O3 3065, Oz 1723.</desc>',
'<rect width="840" height="424" rx="12" fill="#121d2b"/>',
'<g font-family="system-ui, sans-serif" fill="#e8edf4">',
'<text x="27" y="37" font-size="20" font-weight="700">Less machine code. More source tokens.</text>',
'<text x="27" y="61" font-size="12" fill="#aabbd0">Function definitions only · comments and whitespace excluded · lower is shorter</text>']
colors={'source':'#65ac9a','O3':'#e18b66','Oz':'#9b91de'}
for i,(v,label) in enumerate([('source','Original C'),('O3','Ghidra from O3'),('Oz','Ghidra from Oz')]):
 x=28+i*224
 svg += [f'<rect x="{x}" y="81" width="12" height="12" rx="2" fill="{colors[v]}"/>',f'<text x="{x+19}" y="92" font-size="12">{label}</text>']
for i,(lib,label) in enumerate([('jsmn','jsmn'),('qoi','QOI'),('sha256','SHA-256')]):
 y=128+i*91
 svg.append(f'<text x="28" y="{y+17}" font-size="15" font-weight="700">{label}</text>')
 for j,v in enumerate(['source','O3','Oz']):
  n=data[v,lib]['tokens']; width=n/4000*570;yy=y+j*23
  svg += [f'<rect x="126" y="{yy}" width="{width:.1f}" height="16" rx="3" fill="{colors[v]}"/>',f'<text x="{134+width:.1f}" y="{yy+13}" font-size="12">{n:,}</text>']
svg+=['<text x="28" y="404" font-size="11" fill="#aabbd0">LLVM 22.1.8 · Ghidra 12.1.4 · native x86-64 · full LTO</text>','</g></svg>']
(DEST/'source-growth.svg').write_text('\n'.join(svg))
files=[]
for directory in ['src','scripts','upstream','decompiled','fixtures']:
    files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'O3_scalar' not in p.parts)
files.extend(ROOT/f for f in ['README.md','LICENSE'])
files.extend(p for p in (ROOT/'results').iterdir() if p.is_file() and p.suffix in ['.json','.txt','.log'] and 'progress' not in p.name and not p.name.startswith('decompile-'))
files.extend(p for p in (ROOT/'tools').iterdir() if p.is_file() and p.name in ['release.json','download-url.txt'])
for variant in ['O0','O2','O3','Oz','O3_generic','O3_unroll','O3_debug','Oz_debug']:
    files.extend(p for p in (ROOT/'build'/variant).iterdir() if p.is_file())
for directory in (ROOT/'build').glob('rt_*'):
    files.extend(p for p in directory.iterdir() if p.is_file())
archive=DEST/'experiment.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(set(files)):
        info=tar.gettarinfo(str(p),arcname='llvm-ghidra-experiment/'+str(p.relative_to(ROOT)))
        info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
        with p.open('rb') as f:tar.addfile(info,f)
(DEST/'SHA256SUMS').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  experiment.tar.gz\n')
print(f'Packaged {len(set(files))} files; {archive.stat().st_size:,} bytes; {archive}')
