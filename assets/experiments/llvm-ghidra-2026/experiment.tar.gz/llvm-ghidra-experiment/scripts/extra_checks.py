#!/usr/bin/env python3
import pathlib,subprocess,json,os,ctypes as C,sys,itertools
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from test import load,Parser,Token
records=[]
# Held-out randomized testing after the semantic repairs; not used to choose casts.
for v in ['O3','Oz']:
    for opt in ['O3','Oz']:
        path=ROOT/'build'/f'rt_{v}_jsmn'/f'repaired_{opt}.so'
        env={**os.environ,'JSON_TEST_SEED':'0x8b17','JSON_TEST_CASES':'100000'}
        p=subprocess.run([sys.executable,str(ROOT/'scripts/test.py'),'--worker','jsmn',str(path)],capture_output=True,text=True,env=env)
        result=json.loads(p.stdout) if p.returncode==0 else {'ok':False,'error':p.stderr}
        records.append({'kind':'holdout','variant':v,'opt':opt,'seed':'0x8b17',**result});print(v,opt,'holdout',result.get('ok'),flush=True)
# Small, human-readable regression demonstrating the missing unsigned comparison.
regressions=[]
for data in [b'"\\u!000"',b'"\\u0000"',b';123 ',b'\x07} ']:
    outputs={}
    for name,path in [('original','build/O3/libraries.so'),('normalized_O3','build/rt_O3_jsmn/recompiled_O3.so'),('normalized_Oz','build/rt_Oz_jsmn/recompiled_O3.so'),('repaired_O3','build/rt_O3_jsmn/repaired_O3.so'),('repaired_Oz','build/rt_Oz_jsmn/repaired_O3.so')]:
        lib=load(ROOT/path);parser=Parser();toks=(Token*16)();lib.jsmn_init(C.byref(parser))
        rc=lib.jsmn_parse(C.byref(parser),data,len(data),toks,16)
        outputs[name]={'return':rc,'parser':{'pos':parser.pos,'toknext':parser.toknext,'toksuper':parser.toksuper}}
    regressions.append({'input_ascii':data.decode('ascii'),'input_hex':data.hex(),'outputs':outputs})
(ROOT/'results/regressions.json').write_text(json.dumps(regressions,indent=2))
# Sanitizers are diagnostics, not a performance measurement or equivalence proof.
configs=[('original_sha','src/libraries.c',[]),('normalized_generic_sha','build/rt_O3_generic_sha256/normalized.c',[]),('original_json','src/libraries.c',['-DCHECK_JSON']),('repaired_O3_json','build/rt_O3_jsmn/repaired.c',['-DCHECK_JSON']),('repaired_Oz_json','build/rt_Oz_jsmn/repaired.c',['-DCHECK_JSON'])]
for name,source,defines in configs:
    out=ROOT/'build'/('san_'+name)
    cmd=['clang','-std=c11','-O1','-g','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fwrapv','-fno-strict-aliasing','-Wno-int-conversion','-Wno-incompatible-pointer-types',*defines,source,'src/sanitize_driver.c','-o',str(out)]
    subprocess.run(cmd,cwd=ROOT,check=True)
    p=subprocess.run([str(out)],capture_output=True,text=True,cwd=ROOT)
    (ROOT/'results'/('sanitizer_'+name+'.log')).write_text(p.stdout+p.stderr)
    records.append({'kind':'sanitizer','name':name,'returncode':p.returncode,'command':cmd,'log':'results/sanitizer_'+name+'.log'})
    print('sanitizer',name,p.returncode,flush=True)
# Record the original source's signed-shift assumption and the common flag used.
for label,flags in [('default',[]),('wrapv',['-fwrapv'])]:
    out=ROOT/'build'/('ub_probe_'+label)
    cmd=['clang','-O2','-fsanitize=undefined','-fno-sanitize-recover=all',*flags,'src/sha_ub_probe.c','-o',str(out)]
    subprocess.run(cmd,cwd=ROOT,check=True);p=subprocess.run([str(out)],capture_output=True,text=True)
    (ROOT/'results'/('upstream_sha_ub_'+label+'.log')).write_text(p.stdout+p.stderr)
    records.append({'kind':'upstream_shift_probe','mode':label,'returncode':p.returncode})
(ROOT/'results/extra_checks.json').write_text(json.dumps(records,indent=2))
