
void sha256_transform(long param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  long lVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  uint uVar14;
  uint uVar15;
  uint local_138 [66];
  
  uVar1 = *param_2;
  local_138[0] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[1];
  local_138[1] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[2];
  local_138[2] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[3];
  local_138[3] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[4];
  local_138[4] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[5];
  local_138[5] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[6];
  local_138[6] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[7];
  local_138[7] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[8];
  local_138[8] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[9];
  local_138[9] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = param_2[10];
  local_138[10] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = param_2[0xb];
  local_138[0xb] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = param_2[0xc];
  local_138[0xc] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = param_2[0xd];
  local_138[0xd] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = param_2[0xe];
  local_138[0xe] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = param_2[0xf];
  local_138[0xf] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  lVar4 = 0;
  do {
    uVar3 = local_138[lVar4 + 0xe];
    uVar7 = local_138[lVar4 + 1];
    uVar15 = local_138[lVar4 + 2];
    uVar5 = (uVar3 >> 10 ^ (uVar3 >> 0x13 | uVar3 << 0xd) ^ (uVar3 >> 0x11 | uVar3 << 0xf)) +
            local_138[lVar4 + 9] + local_138[lVar4] +
            (uVar7 >> 3 ^ (uVar7 >> 0x12 | uVar7 << 0xe) ^ (uVar7 >> 7 | uVar7 << 0x19));
    local_138[lVar4 + 0x10] = uVar5;
    uVar3 = local_138[lVar4 + 0xf];
    uVar9 = (uVar15 >> 3 ^ (uVar15 >> 0x12 | uVar15 << 0xe) ^ (uVar15 >> 7 | uVar15 << 0x19)) +
            uVar7 + (uVar3 >> 10 ^ (uVar3 >> 0x13 | uVar3 << 0xd) ^ (uVar3 >> 0x11 | uVar3 << 0xf))
                    + local_138[lVar4 + 10];
    local_138[lVar4 + 0x11] = uVar9;
    uVar3 = local_138[lVar4 + 3];
    local_138[lVar4 + 0x12] =
         (uVar3 >> 3 ^ (uVar3 >> 0x12 | uVar3 << 0xe) ^ (uVar3 >> 7 | uVar3 << 0x19)) + uVar15 +
         (uVar5 >> 10 ^ (uVar5 >> 0x13 | uVar5 * 0x2000) ^ (uVar5 >> 0x11 | uVar5 * 0x8000)) +
         local_138[lVar4 + 0xb];
    uVar7 = local_138[lVar4 + 4];
    local_138[lVar4 + 0x13] =
         (uVar7 >> 3 ^ (uVar7 >> 0x12 | uVar7 << 0xe) ^ (uVar7 >> 7 | uVar7 << 0x19)) + uVar3 +
         (uVar9 >> 10 ^ (uVar9 >> 0x13 | uVar9 * 0x2000) ^ (uVar9 >> 0x11 | uVar9 * 0x8000)) +
         local_138[lVar4 + 0xc];
    lVar4 = lVar4 + 4;
  } while (lVar4 != 0x30);
  lVar4 = 0;
  uVar3 = *(uint *)(param_1 + 0x50);
  uVar7 = *(uint *)(param_1 + 0x54);
  uVar15 = *(uint *)(param_1 + 0x58);
  uVar5 = *(uint *)(param_1 + 0x5c);
  uVar9 = *(uint *)(param_1 + 0x60);
  uVar12 = *(uint *)(param_1 + 100);
  uVar10 = *(uint *)(param_1 + 0x68);
  uVar8 = *(uint *)(param_1 + 0x6c);
  do {
    uVar11 = uVar12;
    uVar14 = uVar9;
    uVar6 = uVar7;
    uVar2 = uVar3;
    iVar13 = (~uVar14 & uVar10 | uVar11 & uVar14) + uVar8 +
             ((uVar14 >> 0x19 | uVar14 << 7) ^
             (uVar14 >> 0xb | uVar14 << 0x15) ^ (uVar14 >> 6 | uVar14 << 0x1a)) + (&k)[lVar4] +
             local_138[lVar4];
    uVar12 = uVar5 + iVar13;
    uVar7 = (uVar6 & uVar15 ^ (uVar6 ^ uVar15) & uVar2) +
            ((uVar2 >> 0x16 | uVar2 << 10) ^
            (uVar2 >> 0xd | uVar2 << 0x13) ^ (uVar2 >> 2 | uVar2 << 0x1e)) + iVar13;
    iVar13 = (~uVar12 & uVar11 | uVar14 & uVar12) + uVar10 +
             ((uVar12 >> 0x19 | uVar12 * 0x80) ^
             (uVar12 >> 0xb | uVar12 * 0x200000) ^ (uVar12 >> 6 | uVar12 * 0x4000000)) +
             (&DAT_00100a04)[lVar4] + local_138[lVar4 + 1];
    lVar4 = lVar4 + 2;
    uVar9 = uVar15 + iVar13;
    uVar3 = (uVar2 & uVar6 ^ (uVar2 ^ uVar6) & uVar7) +
            ((uVar7 >> 0x16 | uVar7 * 0x400) ^
            (uVar7 >> 0xd | uVar7 * 0x80000) ^ (uVar7 >> 2 | uVar7 * 0x40000000)) + iVar13;
    uVar15 = uVar2;
    uVar5 = uVar6;
    uVar10 = uVar14;
    uVar8 = uVar11;
  } while (lVar4 != 0x40);
  *(uint *)(param_1 + 0x50) = uVar3 + *(int *)(param_1 + 0x50);
  *(undefined4 *)(param_1 + 0x54) = *(undefined4 *)(param_1 + 0x54);
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_1 + 0x58);
  *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_1 + 0x5c);
  *(uint *)(param_1 + 0x60) = uVar9 + *(int *)(param_1 + 0x60);
  *(undefined4 *)(param_1 + 100) = *(undefined4 *)(param_1 + 100);
  *(undefined4 *)(param_1 + 0x68) = *(undefined4 *)(param_1 + 0x68);
  *(undefined4 *)(param_1 + 0x6c) = *(undefined4 *)(param_1 + 0x6c);
  return;
}

