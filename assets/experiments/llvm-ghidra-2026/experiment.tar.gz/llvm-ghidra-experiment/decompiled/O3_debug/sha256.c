
void sha256_transform(SHA256_CTX *ctx,BYTE *data)

{
  undefined4 uVar1;
  WORD WVar2;
  WORD WVar3;
  WORD WVar4;
  WORD WVar5;
  WORD WVar6;
  WORD WVar7;
  WORD WVar8;
  uint uVar9;
  long lVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  WORD WVar14;
  uint uVar15;
  WORD WVar16;
  uint uVar17;
  WORD WVar18;
  int iVar19;
  uint uVar20;
  WORD WVar21;
  WORD WVar22;
  uint local_138 [66];
  
                    /* Unresolved local var: WORD[64] m@[???]
                       Unresolved local var: WORD j@[???]
                       Unresolved local var: WORD i@[???]
                       Unresolved local var: WORD a@[???]
                       Unresolved local var: WORD b@[???]
                       Unresolved local var: WORD c@[???]
                       Unresolved local var: WORD d@[???]
                       Unresolved local var: WORD e@[???]
                       Unresolved local var: WORD f@[???]
                       Unresolved local var: WORD g@[???]
                       Unresolved local var: WORD h@[???]
                       Unresolved local var: WORD t1@[???]
                       Unresolved local var: WORD t2@[???] */
  uVar1 = *(undefined4 *)data;
  local_138[0] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 4);
  local_138[1] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 8);
  local_138[2] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0xc);
  local_138[3] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x10);
  local_138[4] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x14);
  local_138[5] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x18);
  local_138[6] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x1c);
  local_138[7] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x20);
  local_138[8] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x24);
  local_138[9] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x28);
  local_138[10] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x2c);
  local_138[0xb] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x30);
  local_138[0xc] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x34);
  local_138[0xd] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x38);
  local_138[0xe] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x3c);
  local_138[0xf] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  lVar10 = 0;
  do {
    uVar9 = local_138[lVar10 + 0xe];
    uVar12 = local_138[lVar10 + 1];
    uVar13 = local_138[lVar10 + 2];
    uVar11 = (uVar9 >> 10 ^ (uVar9 >> 0x13 | uVar9 << 0xd) ^ (uVar9 >> 0x11 | uVar9 << 0xf)) +
             local_138[lVar10 + 9] + local_138[lVar10] +
             (uVar12 >> 3 ^ (uVar12 >> 0x12 | uVar12 << 0xe) ^ (uVar12 >> 7 | uVar12 << 0x19));
    local_138[lVar10 + 0x10] = uVar11;
    uVar9 = local_138[lVar10 + 0xf];
    uVar15 = (uVar13 >> 3 ^ (uVar13 >> 0x12 | uVar13 << 0xe) ^ (uVar13 >> 7 | uVar13 << 0x19)) +
             uVar12 + (uVar9 >> 10 ^ (uVar9 >> 0x13 | uVar9 << 0xd) ^ (uVar9 >> 0x11 | uVar9 << 0xf)
                      ) + local_138[lVar10 + 10];
    local_138[lVar10 + 0x11] = uVar15;
    uVar9 = local_138[lVar10 + 3];
    local_138[lVar10 + 0x12] =
         (uVar9 >> 3 ^ (uVar9 >> 0x12 | uVar9 << 0xe) ^ (uVar9 >> 7 | uVar9 << 0x19)) + uVar13 +
         (uVar11 >> 10 ^ (uVar11 >> 0x13 | uVar11 * 0x2000) ^ (uVar11 >> 0x11 | uVar11 * 0x8000)) +
         local_138[lVar10 + 0xb];
    uVar12 = local_138[lVar10 + 4];
    local_138[lVar10 + 0x13] =
         (uVar12 >> 3 ^ (uVar12 >> 0x12 | uVar12 << 0xe) ^ (uVar12 >> 7 | uVar12 << 0x19)) + uVar9 +
         (uVar15 >> 10 ^ (uVar15 >> 0x13 | uVar15 * 0x2000) ^ (uVar15 >> 0x11 | uVar15 * 0x8000)) +
         local_138[lVar10 + 0xc];
    lVar10 = lVar10 + 4;
  } while (lVar10 != 0x30);
  WVar2 = ctx->state[1];
  WVar3 = ctx->state[2];
  WVar4 = ctx->state[3];
  WVar5 = ctx->state[4];
  WVar6 = ctx->state[5];
  WVar7 = ctx->state[6];
  WVar8 = ctx->state[7];
  lVar10 = 0;
  uVar9 = ctx->state[0];
  uVar12 = ctx->state[1];
  WVar22 = ctx->state[2];
  uVar13 = ctx->state[3];
  WVar21 = ctx->state[4];
  WVar18 = ctx->state[5];
  WVar16 = ctx->state[6];
  WVar14 = ctx->state[7];
  do {
    uVar17 = WVar18;
    uVar20 = WVar21;
    uVar15 = uVar12;
    uVar11 = uVar9;
    iVar19 = (~uVar20 & WVar16 | uVar17 & uVar20) + WVar14 +
             ((uVar20 >> 0x19 | uVar20 << 7) ^
             (uVar20 >> 0xb | uVar20 << 0x15) ^ (uVar20 >> 6 | uVar20 << 0x1a)) + k[lVar10] +
             local_138[lVar10];
    WVar18 = uVar13 + iVar19;
    uVar12 = (uVar15 & WVar22 ^ (uVar15 ^ WVar22) & uVar11) +
             ((uVar11 >> 0x16 | uVar11 << 10) ^
             (uVar11 >> 0xd | uVar11 << 0x13) ^ (uVar11 >> 2 | uVar11 << 0x1e)) + iVar19;
    iVar19 = (~WVar18 & uVar17 | uVar20 & WVar18) + WVar16 +
             ((WVar18 >> 0x19 | WVar18 * 0x80) ^
             (WVar18 >> 0xb | WVar18 * 0x200000) ^ (WVar18 >> 6 | WVar18 * 0x4000000)) +
             k[lVar10 + 1] + local_138[lVar10 + 1];
    lVar10 = lVar10 + 2;
    WVar21 = WVar22 + iVar19;
    uVar9 = (uVar11 & uVar15 ^ (uVar11 ^ uVar15) & uVar12) +
            ((uVar12 >> 0x16 | uVar12 * 0x400) ^
            (uVar12 >> 0xd | uVar12 * 0x80000) ^ (uVar12 >> 2 | uVar12 * 0x40000000)) + iVar19;
    WVar22 = uVar11;
    uVar13 = uVar15;
    WVar16 = uVar20;
    WVar14 = uVar17;
  } while (lVar10 != 0x40);
  ctx->state[0] = uVar9 + ctx->state[0];
  ctx->state[1] = WVar2;
  ctx->state[2] = WVar3;
  ctx->state[3] = WVar4;
  ctx->state[4] = WVar21 + WVar5;
  ctx->state[5] = WVar6;
  ctx->state[6] = WVar7;
  ctx->state[7] = WVar8;
  return;
}




void sha256_init(SHA256_CTX *ctx)

{
  ctx->datalen = 0;
  ctx->bitlen = 0;
  ctx->state[0] = 0x6a09e667;
  ctx->state[1] = 0xbb67ae85;
  ctx->state[2] = 0x3c6ef372;
  ctx->state[3] = 0xa54ff53a;
  ctx->state[4] = 0x510e527f;
  ctx->state[5] = 0x9b05688c;
  ctx->state[6] = 0x1f83d9ab;
  ctx->state[7] = 0x5be0cd19;
  return;
}




void sha256_update(SHA256_CTX *ctx,BYTE *data,size_t len)

{
  bool bVar1;
  uint uVar2;
  ulong uVar3;
  ulong uVar4;
  
                    /* Unresolved local var: WORD i@[???] */
  if (len != 0) {
    uVar2 = ctx->datalen;
    uVar3 = 0;
    uVar4 = 1;
    do {
      ctx->data[uVar2] = data[uVar3];
      uVar2 = ctx->datalen + 1;
      ctx->datalen = uVar2;
      if (uVar2 == 0x40) {
        sha256_transform(ctx,ctx->data);
        ctx->bitlen = ctx->bitlen + 0x200;
        uVar2 = 0;
        ctx->datalen = 0;
      }
      bVar1 = uVar4 < len;
      uVar3 = uVar4;
      uVar4 = (ulong)((int)uVar4 + 1);
    } while (bVar1);
  }
  return;
}




void sha256_final(SHA256_CTX *ctx,BYTE *hash)

{
  uint uVar1;
  ulong uVar2;
  unsigned_long_long uVar3;
  
                    /* Unresolved local var: WORD i@[???] */
  uVar1 = ctx->datalen;
  uVar2 = (ulong)uVar1;
  ctx->data[uVar2] = 0x80;
  if (uVar2 < 0x38) {
    if (uVar1 != 0x37) {
      memset(ctx->data + uVar2 + 1,0,0x37 - uVar2);
    }
  }
  else {
    if (uVar1 + 1 < 0x40) {
      memset(ctx->data + (uVar1 + 1),0,(ulong)(0x3e - uVar1) + 1);
    }
    sha256_transform(ctx,ctx->data);
    *(undefined1 (*) [32])(ctx->data + 0x18) = ZEXT1232(ZEXT812(0));
    *(undefined1 (*) [32])ctx->data = ZEXT1232(ZEXT812(0));
  }
  uVar3 = (ulong)(ctx->datalen << 3) + ctx->bitlen;
  ctx->bitlen = uVar3;
  ctx->data[0x3f] = (BYTE)uVar3;
  ctx->data[0x3e] = (BYTE)(uVar3 >> 8);
  ctx->data[0x3d] = (BYTE)(uVar3 >> 0x10);
  ctx->data[0x3c] = (BYTE)(uVar3 >> 0x18);
  ctx->data[0x3b] = (BYTE)(uVar3 >> 0x20);
  ctx->data[0x3a] = (BYTE)(uVar3 >> 0x28);
  ctx->data[0x39] = (BYTE)(uVar3 >> 0x30);
  ctx->data[0x38] = (BYTE)(uVar3 >> 0x38);
  sha256_transform(ctx,ctx->data);
  *hash = *(BYTE *)((long)ctx->state + 3);
  hash[4] = *(BYTE *)((long)ctx->state + 7);
  hash[8] = *(BYTE *)((long)ctx->state + 0xb);
  hash[0xc] = *(BYTE *)((long)ctx->state + 0xf);
  hash[0x10] = *(BYTE *)((long)ctx->state + 0x13);
  hash[0x14] = *(BYTE *)((long)ctx->state + 0x17);
  hash[0x18] = *(BYTE *)((long)ctx->state + 0x1b);
  hash[0x1c] = *(BYTE *)((long)ctx->state + 0x1f);
  hash[1] = *(BYTE *)((long)ctx->state + 2);
  hash[5] = *(BYTE *)((long)ctx->state + 6);
  hash[9] = *(BYTE *)((long)ctx->state + 10);
  hash[0xd] = *(BYTE *)((long)ctx->state + 0xe);
  hash[0x11] = *(BYTE *)((long)ctx->state + 0x12);
  hash[0x15] = *(BYTE *)((long)ctx->state + 0x16);
  hash[0x19] = *(BYTE *)((long)ctx->state + 0x1a);
  hash[0x1d] = *(BYTE *)((long)ctx->state + 0x1e);
  hash[2] = *(BYTE *)((long)ctx->state + 1);
  hash[6] = *(BYTE *)((long)ctx->state + 5);
  hash[10] = *(BYTE *)((long)ctx->state + 9);
  hash[0xe] = *(BYTE *)((long)ctx->state + 0xd);
  hash[0x12] = *(BYTE *)((long)ctx->state + 0x11);
  hash[0x16] = *(BYTE *)((long)ctx->state + 0x15);
  hash[0x1a] = *(BYTE *)((long)ctx->state + 0x19);
  hash[0x1e] = *(BYTE *)((long)ctx->state + 0x1d);
  hash[3] = (BYTE)ctx->state[0];
  hash[7] = (BYTE)ctx->state[1];
  hash[0xb] = (BYTE)ctx->state[2];
  hash[0xf] = (BYTE)ctx->state[3];
  hash[0x13] = (BYTE)ctx->state[4];
  hash[0x17] = (BYTE)ctx->state[5];
  hash[0x1b] = (BYTE)ctx->state[6];
  hash[0x1f] = (BYTE)ctx->state[7];
  return;
}



