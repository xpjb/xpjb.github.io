
void * qoi_decode(void *data,int size,qoi_desc *desc,int channels)

{
  undefined4 uVar1;
  void *pvVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  byte bVar7;
  uint uVar8;
  ulong uVar9;
  byte bVar10;
  byte bVar11;
  byte bVar12;
  long lVar13;
  uint uVar14;
  byte bVar15;
  undefined1 auVar16 [16];
  ulong local_150;
  undefined1 local_138 [32];
  undefined1 local_118 [32];
  undefined1 local_f8 [32];
  undefined1 local_d8 [32];
  undefined1 local_b8 [32];
  undefined1 local_98 [32];
  undefined1 local_78 [32];
  undefined1 local_58 [32];
  
                    /* Unresolved local var: qoi_rgba_t[64] index@[???]
                       Unresolved local var: int p@[???]
                       Unresolved local var: int run@[???]
                       Unresolved local var: uchar * bytes@[???]
                       Unresolved local var: uint header_magic@[???]
                       Unresolved local var: int px_len@[???]
                       Unresolved local var: uchar * pixels@[???]
                       Unresolved local var: int chunks_len@[???]
                       Unresolved local var: int px_pos@[???]
                       Unresolved local var: qoi_rgba_t px@[???] */
  if ((data != (void *)0x0) && (desc != (qoi_desc *)0x0)) {
    if ((0x15 < size) && (channels == 3 || (channels & 0xfffffffbU) == 0)) {
      uVar4 = *(uint *)((long)data + 4);
      uVar1 = *(undefined4 *)data;
      desc->width = CONCAT13((char)uVar4,
                             CONCAT12((char)(uVar4 >> 8),
                                      CONCAT11((char)(uVar4 >> 0x10),(char)(uVar4 >> 0x18))));
      uVar8 = uVar4 >> 0x18 | (uVar4 & 0xff0000) >> 8 | (uVar4 & 0xff00) << 8 | uVar4 << 0x18;
      uVar4 = *(uint *)((long)data + 8);
      desc->height = CONCAT13((char)uVar4,
                              CONCAT12((char)(uVar4 >> 8),
                                       CONCAT11((char)(uVar4 >> 0x10),(char)(uVar4 >> 0x18))));
      bVar10 = *(byte *)((long)data + 0xc);
      desc->channels = bVar10;
      bVar11 = *(byte *)((long)data + 0xd);
      desc->colorspace = bVar11;
      if (((uVar8 != 0) &&
          (uVar4 = uVar4 >> 0x18 | (uVar4 & 0xff0000) >> 8 | (uVar4 & 0xff00) << 8 | uVar4 << 0x18,
          uVar4 != 0)) && (0xfd < (byte)(bVar10 - 5))) {
        if (1 < bVar11) {
          return (void *)0x0;
        }
        if (CONCAT13((char)uVar1,
                     CONCAT12((char)((uint)uVar1 >> 8),
                              CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18)))) !=
            0x716f6966) {
          return (void *)0x0;
        }
        if (uVar4 < (uint)(400000000 / (ulong)uVar8)) {
          uVar14 = (uint)bVar10;
          if (channels != 0) {
            uVar14 = channels;
          }
          iVar5 = uVar4 * uVar8 * uVar14;
          pvVar2 = malloc((long)iVar5);
          if (pvVar2 != (void *)0x0) {
            auVar16._0_12_ = ZEXT812(0);
            auVar16._12_4_ = 0;
            local_58 = ZEXT1632(auVar16);
            local_78 = ZEXT1632(auVar16);
            local_98 = ZEXT1632(auVar16);
            local_b8 = local_98;
            local_d8 = local_98;
            local_f8 = local_98;
            local_118 = ZEXT1632(auVar16);
            local_138 = ZEXT1632(auVar16);
            if (iVar5 < 1) {
              return pvVar2;
            }
            iVar3 = 0xe;
            bVar7 = 0xff;
            uVar4 = 0;
            iVar6 = 0;
            bVar12 = 0;
            bVar11 = 0;
            bVar10 = 0;
            do {
              if ((int)uVar4 < 1) {
                uVar4 = 0;
                if (iVar3 < size + -8) {
                    /* Unresolved local var: int b1@[???] */
                  lVar13 = (long)iVar3;
                  local_150 = lVar13 + 1;
                  bVar15 = *(byte *)((long)data + lVar13);
                  uVar9 = (ulong)bVar15;
                  if (bVar15 == 0xff) {
                    uVar4 = iVar3 + 5;
                    bVar10 = *(byte *)((long)data + local_150);
                    bVar11 = *(byte *)((long)data + lVar13 + 2);
                    bVar12 = *(byte *)((long)data + lVar13 + 3);
                    bVar7 = *(byte *)((long)data + lVar13 + 4);
LAB_00102a99:
                    local_150 = (ulong)uVar4;
                    uVar4 = 0;
                  }
                  else {
                    if (bVar15 == 0xfe) {
                      uVar4 = iVar3 + 4;
                      bVar10 = *(byte *)((long)data + local_150);
                      bVar11 = *(byte *)((long)data + lVar13 + 2);
                      bVar12 = *(byte *)((long)data + lVar13 + 3);
                      goto LAB_00102a99;
                    }
                    switch(bVar15) {
                    default:
                      bVar10 = local_138[uVar9 * 4];
                      bVar11 = local_138[uVar9 * 4 + 1];
                      bVar12 = local_138[uVar9 * 4 + 2];
                      bVar7 = local_138[uVar9 * 4 + 3];
                      uVar4 = 0;
                      break;
                    case 0x40:
                    case 0x41:
                    case 0x42:
                    case 0x43:
                    case 0x44:
                    case 0x45:
                    case 0x46:
                    case 0x47:
                    case 0x48:
                    case 0x49:
                    case 0x4a:
                    case 0x4b:
                    case 0x4c:
                    case 0x4d:
                    case 0x4e:
                    case 0x4f:
                    case 0x50:
                    case 0x51:
                    case 0x52:
                    case 0x53:
                    case 0x54:
                    case 0x55:
                    case 0x56:
                    case 0x57:
                    case 0x58:
                    case 0x59:
                    case 0x5a:
                    case 0x5b:
                    case 0x5c:
                    case 0x5d:
                    case 0x5e:
                    case 0x5f:
                    case 0x60:
                    case 0x61:
                    case 0x62:
                    case 99:
                    case 100:
                    case 0x65:
                    case 0x66:
                    case 0x67:
                    case 0x68:
                    case 0x69:
                    case 0x6a:
                    case 0x6b:
                    case 0x6c:
                    case 0x6d:
                    case 0x6e:
                    case 0x6f:
                    case 0x70:
                    case 0x71:
                    case 0x72:
                    case 0x73:
                    case 0x74:
                    case 0x75:
                    case 0x76:
                    case 0x77:
                    case 0x78:
                    case 0x79:
                    case 0x7a:
                    case 0x7b:
                    case 0x7c:
                    case 0x7d:
                    case 0x7e:
                    case 0x7f:
                      uVar4 = 0;
                      bVar12 = (bVar12 + (bVar15 & 3)) - 2;
                      bVar10 = (bVar10 + (bVar15 >> 4 & 3)) - 2;
                      bVar11 = (bVar11 + (bVar15 >> 2 & 3)) - 2;
                      break;
                    case 0x80:
                    case 0x81:
                    case 0x82:
                    case 0x83:
                    case 0x84:
                    case 0x85:
                    case 0x86:
                    case 0x87:
                    case 0x88:
                    case 0x89:
                    case 0x8a:
                    case 0x8b:
                    case 0x8c:
                    case 0x8d:
                    case 0x8e:
                    case 0x8f:
                    case 0x90:
                    case 0x91:
                    case 0x92:
                    case 0x93:
                    case 0x94:
                    case 0x95:
                    case 0x96:
                    case 0x97:
                    case 0x98:
                    case 0x99:
                    case 0x9a:
                    case 0x9b:
                    case 0x9c:
                    case 0x9d:
                    case 0x9e:
                    case 0x9f:
                    case 0xa0:
                    case 0xa1:
                    case 0xa2:
                    case 0xa3:
                    case 0xa4:
                    case 0xa5:
                    case 0xa6:
                    case 0xa7:
                    case 0xa8:
                    case 0xa9:
                    case 0xaa:
                    case 0xab:
                    case 0xac:
                    case 0xad:
                    case 0xae:
                    case 0xaf:
                    case 0xb0:
                    case 0xb1:
                    case 0xb2:
                    case 0xb3:
                    case 0xb4:
                    case 0xb5:
                    case 0xb6:
                    case 0xb7:
                    case 0xb8:
                    case 0xb9:
                    case 0xba:
                    case 0xbb:
                    case 0xbc:
                    case 0xbd:
                    case 0xbe:
                    case 0xbf:
                    /* Unresolved local var: int b2@[???]
                       Unresolved local var: int vg@[???] */
                      bVar15 = bVar15 & 0x3f;
                      uVar4 = iVar3 + 2;
                      bVar11 = (bVar11 + bVar15) - 0x20;
                      bVar10 = bVar10 + ((*(byte *)((long)data + local_150) >> 4) - 0x28) + bVar15;
                      bVar12 = bVar12 + ((*(byte *)((long)data + local_150) & 0xf) - 0x28) + bVar15;
                      goto LAB_00102a99;
                    case 0xc0:
                    case 0xc1:
                    case 0xc2:
                    case 0xc3:
                    case 0xc4:
                    case 0xc5:
                    case 0xc6:
                    case 199:
                    case 200:
                    case 0xc9:
                    case 0xca:
                    case 0xcb:
                    case 0xcc:
                    case 0xcd:
                    case 0xce:
                    case 0xcf:
                    case 0xd0:
                    case 0xd1:
                    case 0xd2:
                    case 0xd3:
                    case 0xd4:
                    case 0xd5:
                    case 0xd6:
                    case 0xd7:
                    case 0xd8:
                    case 0xd9:
                    case 0xda:
                    case 0xdb:
                    case 0xdc:
                    case 0xdd:
                    case 0xde:
                    case 0xdf:
                    case 0xe0:
                    case 0xe1:
                    case 0xe2:
                    case 0xe3:
                    case 0xe4:
                    case 0xe5:
                    case 0xe6:
                    case 0xe7:
                    case 0xe8:
                    case 0xe9:
                    case 0xea:
                    case 0xeb:
                    case 0xec:
                    case 0xed:
                    case 0xee:
                    case 0xef:
                    case 0xf0:
                    case 0xf1:
                    case 0xf2:
                    case 0xf3:
                    case 0xf4:
                    case 0xf5:
                    case 0xf6:
                    case 0xf7:
                    case 0xf8:
                    case 0xf9:
                    case 0xfa:
                    case 0xfb:
                    case 0xfc:
                    case 0xfd:
                      uVar4 = bVar15 & 0x3f;
                    }
                  }
                  uVar9 = (ulong)((uint)bVar7 * 0xb +
                                  (uint)bVar11 + (uint)bVar11 * 4 + (uint)bVar10 + (uint)bVar10 * 2
                                  + (uint)bVar12 * 7 & 0x3f);
                  local_138[uVar9 * 4] = bVar10;
                  local_138[uVar9 * 4 + 1] = bVar11;
                  local_138[uVar9 * 4 + 2] = bVar12;
                  local_138[uVar9 * 4 + 3] = bVar7;
                  iVar3 = (int)local_150;
                }
              }
              else {
                uVar4 = uVar4 - 1;
              }
              *(byte *)((long)pvVar2 + (long)iVar6) = bVar10;
              *(byte *)((long)pvVar2 + (long)iVar6 + 1) = bVar11;
              *(byte *)((long)pvVar2 + (long)(iVar6 + 2)) = bVar12;
              if (uVar14 == 4) {
                *(byte *)((long)pvVar2 + (long)(iVar6 + 3)) = bVar7;
              }
              iVar6 = iVar6 + uVar14;
              if (iVar5 <= iVar6) {
                return pvVar2;
              }
            } while( true );
          }
        }
      }
    }
  }
  return (void *)0x0;
}

