
void sha256_transform(SHA256_CTX *ctx,BYTE *data)

{
  undefined4 uVar1;
  WORD WVar2;
  WORD WVar3;
  WORD WVar4;
  WORD WVar5;
  WORD WVar6;
  WORD WVar7;
  WORD WVar8;
  uint uVar9;
  long lVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  WORD WVar14;
  uint uVar15;
  WORD WVar16;
  uint uVar17;
  WORD WVar18;
  int iVar19;
  uint uVar20;
  WORD WVar21;
  WORD WVar22;
  uint local_138 [66];
  
                    /* Unresolved local var: WORD[64] m@[???]
                       Unresolved local var: WORD j@[???]
                       Unresolved local var: WORD i@[???]
                       Unresolved local var: WORD a@[???]
                       Unresolved local var: WORD b@[???]
                       Unresolved local var: WORD c@[???]
                       Unresolved local var: WORD d@[???]
                       Unresolved local var: WORD e@[???]
                       Unresolved local var: WORD f@[???]
                       Unresolved local var: WORD g@[???]
                       Unresolved local var: WORD h@[???]
                       Unresolved local var: WORD t1@[???]
                       Unresolved local var: WORD t2@[???] */
  uVar1 = *(undefined4 *)data;
  local_138[0] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 4);
  local_138[1] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 8);
  local_138[2] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0xc);
  local_138[3] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x10);
  local_138[4] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x14);
  local_138[5] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x18);
  local_138[6] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x1c);
  local_138[7] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x20);
  local_138[8] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x24);
  local_138[9] = CONCAT13((char)uVar1,
                          CONCAT12((char)((uint)uVar1 >> 8),
                                   CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))
                                  ));
  uVar1 = *(undefined4 *)(data + 0x28);
  local_138[10] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x2c);
  local_138[0xb] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x30);
  local_138[0xc] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x34);
  local_138[0xd] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x38);
  local_138[0xe] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  uVar1 = *(undefined4 *)(data + 0x3c);
  local_138[0xf] =
       CONCAT13((char)uVar1,
                CONCAT12((char)((uint)uVar1 >> 8),
                         CONCAT11((char)((uint)uVar1 >> 0x10),(char)((uint)uVar1 >> 0x18))));
  lVar10 = 0;
  do {
    uVar9 = local_138[lVar10 + 0xe];
    uVar12 = local_138[lVar10 + 1];
    uVar13 = local_138[lVar10 + 2];
    uVar11 = (uVar9 >> 10 ^ (uVar9 >> 0x13 | uVar9 << 0xd) ^ (uVar9 >> 0x11 | uVar9 << 0xf)) +
             local_138[lVar10 + 9] + local_138[lVar10] +
             (uVar12 >> 3 ^ (uVar12 >> 0x12 | uVar12 << 0xe) ^ (uVar12 >> 7 | uVar12 << 0x19));
    local_138[lVar10 + 0x10] = uVar11;
    uVar9 = local_138[lVar10 + 0xf];
    uVar15 = (uVar13 >> 3 ^ (uVar13 >> 0x12 | uVar13 << 0xe) ^ (uVar13 >> 7 | uVar13 << 0x19)) +
             uVar12 + (uVar9 >> 10 ^ (uVar9 >> 0x13 | uVar9 << 0xd) ^ (uVar9 >> 0x11 | uVar9 << 0xf)
                      ) + local_138[lVar10 + 10];
    local_138[lVar10 + 0x11] = uVar15;
    uVar9 = local_138[lVar10 + 3];
    local_138[lVar10 + 0x12] =
         (uVar9 >> 3 ^ (uVar9 >> 0x12 | uVar9 << 0xe) ^ (uVar9 >> 7 | uVar9 << 0x19)) + uVar13 +
         (uVar11 >> 10 ^ (uVar11 >> 0x13 | uVar11 * 0x2000) ^ (uVar11 >> 0x11 | uVar11 * 0x8000)) +
         local_138[lVar10 + 0xb];
    uVar12 = local_138[lVar10 + 4];
    local_138[lVar10 + 0x13] =
         (uVar12 >> 3 ^ (uVar12 >> 0x12 | uVar12 << 0xe) ^ (uVar12 >> 7 | uVar12 << 0x19)) + uVar9 +
         (uVar15 >> 10 ^ (uVar15 >> 0x13 | uVar15 * 0x2000) ^ (uVar15 >> 0x11 | uVar15 * 0x8000)) +
         local_138[lVar10 + 0xc];
    lVar10 = lVar10 + 4;
  } while (lVar10 != 0x30);
  WVar2 = ctx->state[1];
  WVar3 = ctx->state[2];
  WVar4 = ctx->state[3];
  WVar5 = ctx->state[4];
  WVar6 = ctx->state[5];
  WVar7 = ctx->state[6];
  WVar8 = ctx->state[7];
  lVar10 = 0;
  uVar9 = ctx->state[0];
  uVar12 = ctx->state[1];
  WVar22 = ctx->state[2];
  uVar13 = ctx->state[3];
  WVar21 = ctx->state[4];
  WVar18 = ctx->state[5];
  WVar16 = ctx->state[6];
  WVar14 = ctx->state[7];
  do {
    uVar17 = WVar18;
    uVar20 = WVar21;
    uVar15 = uVar12;
    uVar11 = uVar9;
    iVar19 = (~uVar20 & WVar16 | uVar17 & uVar20) + WVar14 +
             ((uVar20 >> 0x19 | uVar20 << 7) ^
             (uVar20 >> 0xb | uVar20 << 0x15) ^ (uVar20 >> 6 | uVar20 << 0x1a)) + k[lVar10] +
             local_138[lVar10];
    WVar18 = uVar13 + iVar19;
    uVar12 = (uVar15 & WVar22 ^ (uVar15 ^ WVar22) & uVar11) +
             ((uVar11 >> 0x16 | uVar11 << 10) ^
             (uVar11 >> 0xd | uVar11 << 0x13) ^ (uVar11 >> 2 | uVar11 << 0x1e)) + iVar19;
    iVar19 = (~WVar18 & uVar17 | uVar20 & WVar18) + WVar16 +
             ((WVar18 >> 0x19 | WVar18 * 0x80) ^
             (WVar18 >> 0xb | WVar18 * 0x200000) ^ (WVar18 >> 6 | WVar18 * 0x4000000)) +
             k[lVar10 + 1] + local_138[lVar10 + 1];
    lVar10 = lVar10 + 2;
    WVar21 = WVar22 + iVar19;
    uVar9 = (uVar11 & uVar15 ^ (uVar11 ^ uVar15) & uVar12) +
            ((uVar12 >> 0x16 | uVar12 * 0x400) ^
            (uVar12 >> 0xd | uVar12 * 0x80000) ^ (uVar12 >> 2 | uVar12 * 0x40000000)) + iVar19;
    WVar22 = uVar11;
    uVar13 = uVar15;
    WVar16 = uVar20;
    WVar14 = uVar17;
  } while (lVar10 != 0x40);
  ctx->state[0] = uVar9 + ctx->state[0];
  ctx->state[1] = WVar2;
  ctx->state[2] = WVar3;
  ctx->state[3] = WVar4;
  ctx->state[4] = WVar21 + WVar5;
  ctx->state[5] = WVar6;
  ctx->state[6] = WVar7;
  ctx->state[7] = WVar8;
  return;
}

