
void sha256_final(SHA256_CTX *ctx,BYTE *hash)

{
  uint uVar1;
  ulong uVar2;
  unsigned_long_long uVar3;
  
                    /* Unresolved local var: WORD i@[???] */
  uVar1 = ctx->datalen;
  uVar2 = (ulong)uVar1;
  ctx->data[uVar2] = 0x80;
  if (uVar2 < 0x38) {
    if (uVar1 != 0x37) {
      memset(ctx->data + uVar2 + 1,0,0x37 - uVar2);
    }
  }
  else {
    if (uVar1 + 1 < 0x40) {
      memset(ctx->data + (uVar1 + 1),0,(ulong)(0x3e - uVar1) + 1);
    }
    sha256_transform(ctx,ctx->data);
    *(undefined1 (*) [32])(ctx->data + 0x18) = ZEXT1232(ZEXT812(0));
    *(undefined1 (*) [32])ctx->data = ZEXT1232(ZEXT812(0));
  }
  uVar3 = (ulong)(ctx->datalen << 3) + ctx->bitlen;
  ctx->bitlen = uVar3;
  ctx->data[0x3f] = (BYTE)uVar3;
  ctx->data[0x3e] = (BYTE)(uVar3 >> 8);
  ctx->data[0x3d] = (BYTE)(uVar3 >> 0x10);
  ctx->data[0x3c] = (BYTE)(uVar3 >> 0x18);
  ctx->data[0x3b] = (BYTE)(uVar3 >> 0x20);
  ctx->data[0x3a] = (BYTE)(uVar3 >> 0x28);
  ctx->data[0x39] = (BYTE)(uVar3 >> 0x30);
  ctx->data[0x38] = (BYTE)(uVar3 >> 0x38);
  sha256_transform(ctx,ctx->data);
  *hash = *(BYTE *)((long)ctx->state + 3);
  hash[4] = *(BYTE *)((long)ctx->state + 7);
  hash[8] = *(BYTE *)((long)ctx->state + 0xb);
  hash[0xc] = *(BYTE *)((long)ctx->state + 0xf);
  hash[0x10] = *(BYTE *)((long)ctx->state + 0x13);
  hash[0x14] = *(BYTE *)((long)ctx->state + 0x17);
  hash[0x18] = *(BYTE *)((long)ctx->state + 0x1b);
  hash[0x1c] = *(BYTE *)((long)ctx->state + 0x1f);
  hash[1] = *(BYTE *)((long)ctx->state + 2);
  hash[5] = *(BYTE *)((long)ctx->state + 6);
  hash[9] = *(BYTE *)((long)ctx->state + 10);
  hash[0xd] = *(BYTE *)((long)ctx->state + 0xe);
  hash[0x11] = *(BYTE *)((long)ctx->state + 0x12);
  hash[0x15] = *(BYTE *)((long)ctx->state + 0x16);
  hash[0x19] = *(BYTE *)((long)ctx->state + 0x1a);
  hash[0x1d] = *(BYTE *)((long)ctx->state + 0x1e);
  hash[2] = *(BYTE *)((long)ctx->state + 1);
  hash[6] = *(BYTE *)((long)ctx->state + 5);
  hash[10] = *(BYTE *)((long)ctx->state + 9);
  hash[0xe] = *(BYTE *)((long)ctx->state + 0xd);
  hash[0x12] = *(BYTE *)((long)ctx->state + 0x11);
  hash[0x16] = *(BYTE *)((long)ctx->state + 0x15);
  hash[0x1a] = *(BYTE *)((long)ctx->state + 0x19);
  hash[0x1e] = *(BYTE *)((long)ctx->state + 0x1d);
  hash[3] = (BYTE)ctx->state[0];
  hash[7] = (BYTE)ctx->state[1];
  hash[0xb] = (BYTE)ctx->state[2];
  hash[0xf] = (BYTE)ctx->state[3];
  hash[0x13] = (BYTE)ctx->state[4];
  hash[0x17] = (BYTE)ctx->state[5];
  hash[0x1b] = (BYTE)ctx->state[6];
  hash[0x1f] = (BYTE)ctx->state[7];
  return;
}

