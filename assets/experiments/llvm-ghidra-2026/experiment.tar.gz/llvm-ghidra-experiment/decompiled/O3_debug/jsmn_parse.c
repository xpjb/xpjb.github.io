
/* WARNING: Type propagation algorithm not settling */

int jsmn_parse(jsmn_parser *parser,char *js,size_t len,jsmntok_t *tokens,uint num_tokens)

{
  uint uVar1;
  char cVar2;
  byte bVar3;
  bool bVar4;
  undefined1 auVar5 [16];
  jsmntok_t jVar6;
  int iVar7;
  uint uVar8;
  ulong uVar9;
  long lVar10;
  int *piVar11;
  uint uVar12;
  ulong uVar13;
  long lVar14;
  uint uVar15;
  uint uVar16;
  jsmntok_t *pjVar17;
  uint uVar18;
  
                    /* Unresolved local var: int count@[???]
                       Unresolved local var: int r@[???]
                       Unresolved local var: jsmntok_t * token@[???]
                       Unresolved local var: int i@[???] */
  uVar8 = parser->pos;
  uVar12 = parser->toknext;
joined_r0x00101e44:
  uVar9 = (ulong)uVar8;
  if (len <= uVar9) {
switchD_00101ec0_caseD_0:
    if (tokens == (jsmntok_t *)0x0) {
      return uVar12;
    }
    uVar8 = parser->toknext - 1;
    if ((int)uVar8 < 0) {
      return uVar12;
    }
    piVar11 = &tokens[uVar8].end;
    lVar14 = (ulong)uVar8 + 1;
    while ((piVar11[-1] == -1 || (*piVar11 != -1))) {
      piVar11 = piVar11 + -4;
      lVar10 = lVar14 + -1;
      bVar4 = lVar14 < 1;
      lVar14 = lVar10;
      if (lVar10 == 0 || bVar4) {
        return uVar12;
      }
    }
    return -3;
  }
  cVar2 = js[uVar9];
  uVar15 = uVar12;
  switch(cVar2) {
  case '\0':
    goto switchD_00101ec0_caseD_0;
  default:
    return -2;
  case '\t':
  case '\n':
  case '\r':
  case ' ':
    break;
  case '\"':
                    /* Unresolved local var: int start@[???]
                       Unresolved local var: jsmntok_t * token@[???] */
    uVar18 = uVar8 + 1;
    uVar9 = (ulong)uVar18;
    parser->pos = uVar18;
    uVar15 = uVar18;
    if (uVar9 < len) {
      do {
        cVar2 = js[uVar9];
        uVar16 = uVar15;
        if (cVar2 == '\\') {
          uVar1 = uVar15 + 1;
          if (uVar1 < len) {
                    /* Unresolved local var: int i@[???] */
            parser->pos = uVar1;
            iVar7 = -2;
            uVar16 = uVar1;
            switch(js[uVar1]) {
            case '\"':
            case '/':
            case '\\':
            case 'b':
            case 'f':
            case 'n':
            case 'r':
            case 't':
              break;
            default:
              goto switchD_001021ea_caseD_23;
            case 'u':
              uVar16 = uVar15 + 2;
              parser->pos = uVar16;
              if ((uVar16 < len) && (bVar3 = js[uVar16], bVar3 != 0)) {
                if ((9 < (byte)(bVar3 - 0x30)) &&
                   ((0x25 < bVar3 - 0x41 ||
                    ((0x3f0000003fU >> ((ulong)(bVar3 - 0x41) & 0x3f) & 1) == 0))))
                goto switchD_001021ea_caseD_23;
                uVar16 = uVar15 + 3;
                parser->pos = uVar16;
                if ((uVar16 < len) && (bVar3 = js[uVar16], bVar3 != 0)) {
                  if ((9 < (byte)(bVar3 - 0x30)) &&
                     ((0x25 < bVar3 - 0x41 ||
                      ((0x3f0000003fU >> ((ulong)(bVar3 - 0x41) & 0x3f) & 1) == 0))))
                  goto switchD_001021ea_caseD_23;
                  uVar16 = uVar15 + 4;
                  parser->pos = uVar16;
                  if ((uVar16 < len) && (bVar3 = js[uVar16], bVar3 != 0)) {
                    if ((9 < (byte)(bVar3 - 0x30)) &&
                       ((0x25 < bVar3 - 0x41 ||
                        ((0x3f0000003fU >> ((ulong)(bVar3 - 0x41) & 0x3f) & 1) == 0))))
                    goto switchD_001021ea_caseD_23;
                    uVar16 = uVar15 + 5;
                    parser->pos = uVar16;
                    if ((uVar16 < len) && (bVar3 = js[uVar16], bVar3 != 0)) {
                      if ((9 < (byte)(bVar3 - 0x30)) &&
                         ((0x25 < bVar3 - 0x41 ||
                          ((0x3f0000003fU >> ((ulong)(bVar3 - 0x41) & 0x3f) & 1) == 0))))
                      goto switchD_001021ea_caseD_23;
                      uVar16 = uVar15 + 6;
                    }
                  }
                }
              }
              uVar16 = uVar16 - 1;
            }
          }
        }
        else {
          if (cVar2 == '\0') break;
          if (cVar2 == '\"') goto LAB_00102331;
        }
        uVar15 = uVar16 + 1;
        uVar9 = (ulong)uVar15;
        parser->pos = uVar15;
        if (len <= uVar9) break;
      } while( true );
    }
    iVar7 = -3;
    goto switchD_001021ea_caseD_23;
  case ',':
    if ((((tokens != (jsmntok_t *)0x0) && ((long)parser->toksuper != -1)) &&
        (1 < tokens[parser->toksuper].type - JSMN_OBJECT)) &&
       (uVar8 = parser->toknext - 1, -1 < (int)uVar8)) {
      piVar11 = &tokens[uVar8].end;
      uVar9 = (ulong)uVar8;
      do {
        if (((((jsmntok_t *)(piVar11 + -2))->type - JSMN_OBJECT < 2) && (piVar11[-1] != -1)) &&
           (*piVar11 == -1)) goto LAB_00102159;
        piVar11 = piVar11 + -4;
        bVar4 = 0 < (long)uVar9;
        uVar9 = uVar9 - 1;
      } while (bVar4);
    }
    break;
  case '-':
  case '0':
  case '1':
  case '2':
  case '3':
  case '4':
  case '5':
  case '6':
  case '7':
  case '8':
  case '9':
  case 'f':
  case 'n':
  case 't':
    if ((tokens != (jsmntok_t *)0x0) && (lVar14 = (long)parser->toksuper, lVar14 != -1)) {
                    /* Unresolved local var: jsmntok_t * t@[???] */
      if (tokens[lVar14].type == JSMN_STRING) {
        if (tokens[lVar14].size != 0) {
          return -2;
        }
      }
      else if (tokens[lVar14].type == JSMN_OBJECT) {
        return -2;
      }
    }
    do {
      bVar3 = js[uVar9];
      uVar13 = (ulong)bVar3;
      iVar7 = -3;
      if (uVar13 < 0x2d) {
        if ((0x100100002600U >> (uVar13 & 0x3f) & 1) != 0) goto LAB_00101f50;
        if (uVar13 == 0) goto switchD_001021ea_caseD_23;
      }
      if ((bVar3 == 0x5d) || (bVar3 == 0x7d)) goto LAB_00101f50;
      if ((byte)(bVar3 + 0x81) < 0xa1) {
        iVar7 = -2;
        goto switchD_001021ea_caseD_23;
      }
      uVar15 = (int)uVar9 + 1;
      uVar9 = (ulong)uVar15;
      parser->pos = uVar15;
      if (len <= uVar9) goto switchD_001021ea_caseD_23;
    } while( true );
  case ':':
switchD_00101ec0_caseD_3a:
    parser->toksuper = parser->toknext - 1;
    uVar15 = uVar12;
    break;
  case '[':
  case '{':
    uVar12 = uVar12 + 1;
    uVar15 = uVar12;
    if (tokens != (jsmntok_t *)0x0) {
      uVar8 = parser->toknext;
      if (num_tokens <= uVar8) {
        return -1;
      }
      parser->toknext = uVar8 + 1;
      tokens[uVar8].start = -1;
      tokens[uVar8].end = -1;
      tokens[uVar8].size = 0;
      lVar14 = (long)parser->toksuper;
      if (lVar14 != -1) {
                    /* Unresolved local var: jsmntok_t * t@[???] */
        if (tokens[lVar14].type == JSMN_OBJECT) {
          return -2;
        }
        tokens[lVar14].size = tokens[lVar14].size + 1;
      }
      tokens[uVar8].type = (cVar2 != '{') + JSMN_OBJECT;
      tokens[uVar8].start = parser->pos;
      goto switchD_00101ec0_caseD_3a;
    }
    break;
  case ']':
  case '}':
    if (tokens != (jsmntok_t *)0x0) {
      uVar12 = parser->toknext - 1;
      if ((int)uVar12 < 0) {
        if (parser->toknext == 0) {
          return -2;
        }
      }
      else {
        pjVar17 = tokens + uVar12;
        uVar9 = (ulong)uVar12;
        while ((pjVar17->start == -1 || (pjVar17->end != -1))) {
          pjVar17 = pjVar17 + -1;
          uVar12 = uVar12 - 1;
          bVar4 = (long)uVar9 < 1;
          uVar9 = uVar9 - 1;
          if (bVar4) {
            return -2;
          }
        }
        if (pjVar17->type != (cVar2 != '}') + JSMN_OBJECT) {
          return -2;
        }
        parser->toksuper = -1;
        piVar11 = &tokens[uVar12].end;
        pjVar17->end = uVar8 + 1;
        uVar9 = uVar9 & 0xffffffff;
        do {
          if ((piVar11[-1] != -1) && (*piVar11 == -1)) goto LAB_00102159;
          piVar11 = piVar11 + -4;
          bVar4 = 0 < (long)uVar9;
          uVar9 = uVar9 - 1;
        } while (bVar4);
      }
    }
  }
  goto switchD_00101ec0_caseD_9;
LAB_00101f50:
  if (tokens == (jsmntok_t *)0x0) {
                    /* Unresolved local var: jsmntype_t type@[???]
                       Unresolved local var: char c@[???]
                       Unresolved local var: jsmntok_t * token@[???] */
    parser->pos = (int)uVar9 - 1;
    uVar15 = uVar12 + 1;
    goto switchD_00101ec0_caseD_9;
  }
                    /* Unresolved local var: jsmntok_t * tok@[???] */
  uVar15 = parser->toknext;
  if (num_tokens <= uVar15) goto LAB_001023de;
  parser->toknext = uVar15 + 1;
  tokens[uVar15].start = -1;
  tokens[uVar15].end = -1;
  tokens[uVar15].size = 0;
  auVar5 = vpunpckldq_avx(ZEXT416(8),ZEXT416(uVar8));
  jVar6 = (jsmntok_t)vpunpcklqdq_avx(auVar5,ZEXT416(parser->pos));
  tokens[uVar15] = jVar6;
  parser->pos = parser->pos - 1;
  iVar7 = parser->toksuper;
  goto joined_r0x00101fa5;
LAB_00102159:
  parser->toksuper = (int)uVar9;
  goto switchD_00101ec0_caseD_9;
LAB_00102331:
  if (tokens == (jsmntok_t *)0x0) {
    uVar15 = uVar12 + 1;
    goto switchD_00101ec0_caseD_9;
  }
                    /* Unresolved local var: jsmntok_t * tok@[???] */
  uVar15 = parser->toknext;
  if (num_tokens <= uVar15) {
LAB_001023de:
    iVar7 = -1;
switchD_001021ea_caseD_23:
    parser->pos = uVar8;
    return iVar7;
  }
  parser->toknext = uVar15 + 1;
  tokens[uVar15].start = -1;
  tokens[uVar15].end = -1;
  tokens[uVar15].size = 0;
  auVar5 = vpunpckldq_avx(ZEXT416(4),ZEXT416(uVar18));
  jVar6 = (jsmntok_t)vpunpcklqdq_avx(auVar5,ZEXT416(parser->pos));
  tokens[uVar15] = jVar6;
  iVar7 = parser->toksuper;
joined_r0x00101fa5:
  uVar15 = uVar12 + 1;
  if ((long)iVar7 != -1) {
    tokens[iVar7].size = tokens[iVar7].size + 1;
    uVar15 = uVar12 + 1;
  }
switchD_00101ec0_caseD_9:
  uVar8 = parser->pos + 1;
  parser->pos = uVar8;
  uVar12 = uVar15;
  goto joined_r0x00101e44;
}

