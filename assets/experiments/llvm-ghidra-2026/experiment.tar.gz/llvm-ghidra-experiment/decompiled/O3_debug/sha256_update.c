
void sha256_update(SHA256_CTX *ctx,BYTE *data,size_t len)

{
  bool bVar1;
  uint uVar2;
  ulong uVar3;
  ulong uVar4;
  
                    /* Unresolved local var: WORD i@[???] */
  if (len != 0) {
    uVar2 = ctx->datalen;
    uVar3 = 0;
    uVar4 = 1;
    do {
      ctx->data[uVar2] = data[uVar3];
      uVar2 = ctx->datalen + 1;
      ctx->datalen = uVar2;
      if (uVar2 == 0x40) {
        sha256_transform(ctx,ctx->data);
        ctx->bitlen = ctx->bitlen + 0x200;
        uVar2 = 0;
        ctx->datalen = 0;
      }
      bVar1 = uVar4 < len;
      uVar3 = uVar4;
      uVar4 = (ulong)((int)uVar4 + 1);
    } while (bVar1);
  }
  return;
}

