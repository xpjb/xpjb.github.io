
void sha256_final(void *param_1,long param_2)

{
  undefined4 local_c;
  
  local_c = *(uint *)((long)param_1 + 0x40);
  if (*(uint *)((long)param_1 + 0x40) < 0x38) {
    *(undefined1 *)((long)param_1 + (ulong)local_c) = 0x80;
    while (local_c = local_c + 1, local_c < 0x38) {
      *(undefined1 *)((long)param_1 + (ulong)local_c) = 0;
    }
  }
  else {
    *(undefined1 *)((long)param_1 + (ulong)local_c) = 0x80;
    while (local_c = local_c + 1, local_c < 0x40) {
      *(undefined1 *)((long)param_1 + (ulong)local_c) = 0;
    }
    sha256_transform(param_1);
    memset(param_1,0,0x38);
  }
  *(ulong *)((long)param_1 + 0x48) =
       (ulong)(uint)(*(int *)((long)param_1 + 0x40) << 3) + *(long *)((long)param_1 + 0x48);
  *(char *)((long)param_1 + 0x3f) = (char)*(undefined8 *)((long)param_1 + 0x48);
  *(char *)((long)param_1 + 0x3e) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 8);
  *(char *)((long)param_1 + 0x3d) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x10);
  *(char *)((long)param_1 + 0x3c) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x18);
  *(char *)((long)param_1 + 0x3b) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x20);
  *(char *)((long)param_1 + 0x3a) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x28);
  *(char *)((long)param_1 + 0x39) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x30);
  *(char *)((long)param_1 + 0x38) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x38);
  sha256_transform(param_1,param_1);
  for (local_c = 0; local_c < 4; local_c = local_c + 1) {
    *(char *)(param_2 + (ulong)local_c) =
         (char)(*(uint *)((long)param_1 + 0x50) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 4)) =
         (char)(*(uint *)((long)param_1 + 0x54) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 8)) =
         (char)(*(uint *)((long)param_1 + 0x58) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0xc)) =
         (char)(*(uint *)((long)param_1 + 0x5c) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0x10)) =
         (char)(*(uint *)((long)param_1 + 0x60) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0x14)) =
         (char)(*(uint *)((long)param_1 + 100) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0x18)) =
         (char)(*(uint *)((long)param_1 + 0x68) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0x1c)) =
         (char)(*(uint *)((long)param_1 + 0x6c) >> (0x18U - (char)(local_c << 3) & 0x1f));
  }
  return;
}

