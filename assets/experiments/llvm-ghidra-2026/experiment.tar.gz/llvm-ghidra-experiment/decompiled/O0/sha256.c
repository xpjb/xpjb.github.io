
void sha256_transform(long param_1,long param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_158 [71];
  uint local_3c;
  uint local_38;
  uint local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  uint local_24;
  uint local_14;
  uint local_10;
  uint local_c;
  
  local_24 = 0;
  for (local_c = 0; local_c < 0x10; local_c = local_c + 1) {
    auStack_158[local_c] =
         (uint)*(byte *)(param_2 + (ulong)local_24) << 0x18 |
         (uint)*(byte *)(param_2 + (ulong)(local_24 + 1)) << 0x10 |
         (uint)*(byte *)(param_2 + (ulong)(local_24 + 2)) << 8 |
         (uint)*(byte *)(param_2 + (ulong)(local_24 + 3));
    local_24 = local_24 + 4;
  }
  for (; local_c < 0x40; local_c = local_c + 1) {
    auStack_158[local_c] =
         ((auStack_158[local_c - 2] >> 0x11 | auStack_158[local_c - 2] << 0xf) ^
          (auStack_158[local_c - 2] >> 0x13 | auStack_158[local_c - 2] << 0xd) ^
         auStack_158[local_c - 2] >> 10) + auStack_158[local_c - 7] +
         ((auStack_158[local_c - 0xf] >> 7 | auStack_158[local_c - 0xf] << 0x19) ^
          (auStack_158[local_c - 0xf] >> 0x12 | auStack_158[local_c - 0xf] << 0xe) ^
         auStack_158[local_c - 0xf] >> 3) + auStack_158[local_c - 0x10];
  }
  local_14 = *(uint *)(param_1 + 0x50);
  local_2c = *(uint *)(param_1 + 0x54);
  local_28 = *(uint *)(param_1 + 0x58);
  local_3c = *(uint *)(param_1 + 0x5c);
  local_10 = *(uint *)(param_1 + 0x60);
  local_34 = *(uint *)(param_1 + 100);
  local_30 = *(uint *)(param_1 + 0x68);
  local_38 = *(uint *)(param_1 + 0x6c);
  for (local_c = 0; local_c < 0x40; local_c = local_c + 1) {
    iVar1 = local_38 +
            ((local_10 >> 6 | local_10 << 0x1a) ^ (local_10 >> 0xb | local_10 << 0x15) ^
            (local_10 >> 0x19 | local_10 << 7)) +
            (local_10 & local_34 ^ (local_10 ^ 0xffffffff) & local_30) +
            *(int *)(k + (ulong)local_c * 4) + auStack_158[local_c];
    uVar2 = local_14 & local_2c;
    uVar3 = local_14 & local_28;
    uVar4 = local_2c & local_28;
    local_38 = local_30;
    local_30 = local_34;
    local_34 = local_10;
    local_10 = local_3c + iVar1;
    local_3c = local_28;
    local_28 = local_2c;
    local_2c = local_14;
    local_14 = iVar1 + ((local_14 >> 2 | local_14 << 0x1e) ^ (local_14 >> 0xd | local_14 << 0x13) ^
                       (local_14 >> 0x16 | local_14 << 10)) + (uVar2 ^ uVar3 ^ uVar4);
  }
  *(uint *)(param_1 + 0x50) = local_14 + *(int *)(param_1 + 0x50);
  *(uint *)(param_1 + 0x54) = local_2c + *(int *)(param_1 + 0x54);
  *(uint *)(param_1 + 0x58) = local_28 + *(int *)(param_1 + 0x58);
  *(uint *)(param_1 + 0x5c) = local_3c + *(int *)(param_1 + 0x5c);
  *(uint *)(param_1 + 0x60) = local_10 + *(int *)(param_1 + 0x60);
  *(uint *)(param_1 + 100) = local_34 + *(int *)(param_1 + 100);
  *(uint *)(param_1 + 0x68) = local_30 + *(int *)(param_1 + 0x68);
  *(uint *)(param_1 + 0x6c) = local_38 + *(int *)(param_1 + 0x6c);
  return;
}




void sha256_init(long param_1)

{
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0x6a09e667;
  *(undefined4 *)(param_1 + 0x54) = 0xbb67ae85;
  *(undefined4 *)(param_1 + 0x58) = 0x3c6ef372;
  *(undefined4 *)(param_1 + 0x5c) = 0xa54ff53a;
  *(undefined4 *)(param_1 + 0x60) = 0x510e527f;
  *(undefined4 *)(param_1 + 100) = 0x9b05688c;
  *(undefined4 *)(param_1 + 0x68) = 0x1f83d9ab;
  *(undefined4 *)(param_1 + 0x6c) = 0x5be0cd19;
  return;
}




void sha256_update(long param_1,long param_2,ulong param_3)

{
  undefined4 local_c;
  
  for (local_c = 0; local_c < param_3; local_c = local_c + 1) {
    *(undefined1 *)(param_1 + (ulong)*(uint *)(param_1 + 0x40)) =
         *(undefined1 *)(param_2 + (ulong)local_c);
    *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + 1;
    if (*(int *)(param_1 + 0x40) == 0x40) {
      sha256_transform(param_1,param_1);
      *(long *)(param_1 + 0x48) = *(long *)(param_1 + 0x48) + 0x200;
      *(undefined4 *)(param_1 + 0x40) = 0;
    }
  }
  return;
}




void sha256_final(void *param_1,long param_2)

{
  undefined4 local_c;
  
  local_c = *(uint *)((long)param_1 + 0x40);
  if (*(uint *)((long)param_1 + 0x40) < 0x38) {
    *(undefined1 *)((long)param_1 + (ulong)local_c) = 0x80;
    while (local_c = local_c + 1, local_c < 0x38) {
      *(undefined1 *)((long)param_1 + (ulong)local_c) = 0;
    }
  }
  else {
    *(undefined1 *)((long)param_1 + (ulong)local_c) = 0x80;
    while (local_c = local_c + 1, local_c < 0x40) {
      *(undefined1 *)((long)param_1 + (ulong)local_c) = 0;
    }
    sha256_transform(param_1);
    memset(param_1,0,0x38);
  }
  *(ulong *)((long)param_1 + 0x48) =
       (ulong)(uint)(*(int *)((long)param_1 + 0x40) << 3) + *(long *)((long)param_1 + 0x48);
  *(char *)((long)param_1 + 0x3f) = (char)*(undefined8 *)((long)param_1 + 0x48);
  *(char *)((long)param_1 + 0x3e) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 8);
  *(char *)((long)param_1 + 0x3d) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x10);
  *(char *)((long)param_1 + 0x3c) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x18);
  *(char *)((long)param_1 + 0x3b) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x20);
  *(char *)((long)param_1 + 0x3a) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x28);
  *(char *)((long)param_1 + 0x39) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x30);
  *(char *)((long)param_1 + 0x38) = (char)((ulong)*(undefined8 *)((long)param_1 + 0x48) >> 0x38);
  sha256_transform(param_1,param_1);
  for (local_c = 0; local_c < 4; local_c = local_c + 1) {
    *(char *)(param_2 + (ulong)local_c) =
         (char)(*(uint *)((long)param_1 + 0x50) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 4)) =
         (char)(*(uint *)((long)param_1 + 0x54) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 8)) =
         (char)(*(uint *)((long)param_1 + 0x58) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0xc)) =
         (char)(*(uint *)((long)param_1 + 0x5c) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0x10)) =
         (char)(*(uint *)((long)param_1 + 0x60) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0x14)) =
         (char)(*(uint *)((long)param_1 + 100) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0x18)) =
         (char)(*(uint *)((long)param_1 + 0x68) >> (0x18U - (char)(local_c << 3) & 0x1f));
    *(char *)(param_2 + (ulong)(local_c + 0x1c)) =
         (char)(*(uint *)((long)param_1 + 0x6c) >> (0x18U - (char)(local_c << 3) & 0x1f));
  }
  return;
}



