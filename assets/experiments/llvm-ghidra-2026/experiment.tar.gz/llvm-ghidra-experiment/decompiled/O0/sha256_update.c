
void sha256_update(long param_1,long param_2,ulong param_3)

{
  undefined4 local_c;
  
  for (local_c = 0; local_c < param_3; local_c = local_c + 1) {
    *(undefined1 *)(param_1 + (ulong)*(uint *)(param_1 + 0x40)) =
         *(undefined1 *)(param_2 + (ulong)local_c);
    *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + 1;
    if (*(int *)(param_1 + 0x40) == 0x40) {
      sha256_transform(param_1,param_1);
      *(long *)(param_1 + 0x48) = *(long *)(param_1 + 0x48) + 0x200;
      *(undefined4 *)(param_1 + 0x40) = 0;
    }
  }
  return;
}

