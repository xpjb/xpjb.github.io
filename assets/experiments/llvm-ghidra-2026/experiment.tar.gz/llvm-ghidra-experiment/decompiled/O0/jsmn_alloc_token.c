
long jsmn_alloc_token(long param_1,long param_2,ulong param_3)

{
  uint uVar1;
  undefined8 local_20;
  
  if (*(uint *)(param_1 + 4) < param_3) {
    uVar1 = *(uint *)(param_1 + 4);
    *(uint *)(param_1 + 4) = uVar1 + 1;
    local_20 = param_2 + (ulong)uVar1 * 0x10;
    *(undefined4 *)(local_20 + 8) = 0xffffffff;
    *(undefined4 *)(local_20 + 4) = 0xffffffff;
    *(undefined4 *)(local_20 + 0xc) = 0;
  }
  else {
    local_20 = 0;
  }
  return local_20;
}

