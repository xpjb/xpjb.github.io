
void * qoi_decode(long param_1,int param_2,uint *param_3,uint param_4)

{
  byte bVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint local_168 [64];
  long local_68;
  int local_60;
  int local_5c;
  void *local_58;
  int local_4c;
  int local_48;
  uint local_44;
  void *local_40;
  int local_38;
  uint local_34;
  long local_30;
  int local_24;
  uint *local_20;
  uint local_18;
  uint local_14;
  int local_10;
  undefined4 local_c;
  
  local_10 = 0;
  local_34 = 0;
  if ((((param_1 == 0) || (param_3 == (uint *)0x0)) ||
      ((param_4 != 0 && ((param_4 != 3 && (param_4 != 4)))))) || (param_2 < 0x16)) {
    local_58 = (void *)0x0;
  }
  else {
    local_68 = param_1;
    local_4c = param_2;
    local_30 = param_1;
    local_20 = param_3;
    local_18 = param_4;
    local_60 = qoi_read_32(param_1,&local_10);
    uVar3 = qoi_read_32(local_30,&local_10);
    *local_20 = uVar3;
    uVar3 = qoi_read_32(local_30,&local_10);
    local_20[1] = uVar3;
    iVar4 = local_10 + 1;
    *(undefined1 *)(local_20 + 2) = *(undefined1 *)(local_30 + local_10);
    local_10 = local_10 + 2;
    *(undefined1 *)((long)local_20 + 9) = *(undefined1 *)(local_30 + iVar4);
    if (((((*local_20 == 0) || (local_20[1] == 0)) || ((byte)local_20[2] < 3)) ||
        ((4 < (byte)local_20[2] || (1 < *(byte *)((long)local_20 + 9))))) ||
       ((local_60 != 0x716f6966 || ((uint)(400000000 / (ulong)*local_20) <= local_20[1])))) {
      local_58 = (void *)0x0;
    }
    else {
      if (local_18 == 0) {
        local_18 = (uint)(byte)local_20[2];
      }
      local_48 = *local_20 * local_20[1] * local_18;
      local_40 = malloc((long)local_48);
      if (local_40 == (void *)0x0) {
        local_58 = (void *)0x0;
      }
      else {
        memset(local_168,0,0x100);
        local_c = 0xff000000;
        local_5c = local_4c + -8;
        for (local_24 = 0; iVar4 = local_10, local_24 < local_48; local_24 = local_18 + local_24) {
          if ((int)local_34 < 1) {
            if (local_10 < local_5c) {
              iVar5 = local_10 + 1;
              local_10 = iVar5;
              bVar1 = *(byte *)(local_30 + iVar4);
              local_14 = (uint)bVar1;
              if (local_14 == 0xfe) {
                local_c._0_2_ =
                     CONCAT11(*(undefined1 *)(local_30 + (iVar4 + 2)),
                              *(undefined1 *)(local_30 + iVar5));
                local_10 = iVar4 + 4;
                local_c._0_3_ =
                     CONCAT12(*(undefined1 *)(local_30 + (iVar4 + 3)),(undefined2)local_c);
              }
              else if (local_14 == 0xff) {
                local_c._0_2_ =
                     CONCAT11(*(undefined1 *)(local_30 + (iVar4 + 2)),
                              *(undefined1 *)(local_30 + iVar5));
                local_c._0_3_ =
                     CONCAT12(*(undefined1 *)(local_30 + (iVar4 + 3)),(undefined2)local_c);
                local_10 = iVar4 + 5;
                local_c = CONCAT13(*(undefined1 *)(local_30 + (iVar4 + 4)),(undefined3)local_c);
              }
              else if ((bVar1 & 0xc0) == 0) {
                local_c = local_168[(int)local_14];
              }
              else if ((local_14 & 0xc0) == 0x40) {
                local_c._0_2_ =
                     CONCAT11(local_c._1_1_ + (((byte)((int)local_14 >> 2) & 3) - 2),
                              (char)local_c + (((byte)((int)local_14 >> 4) & 3) - 2));
                local_c._0_3_ = CONCAT12(local_c._2_1_ + ((bVar1 & 3) - 2),(undefined2)local_c);
              }
              else if ((local_14 & 0xc0) == 0x80) {
                local_10 = iVar4 + 2;
                bVar1 = *(byte *)(local_30 + iVar5);
                local_44 = (uint)bVar1;
                local_38 = (local_14 & 0x3f) - 0x20;
                cVar2 = (char)local_38;
                local_c._0_2_ =
                     CONCAT11(local_c._1_1_ + cVar2,
                              (char)local_c + cVar2 + -8 + (char)((int)(uint)bVar1 >> 4));
                local_c._0_3_ =
                     CONCAT12(local_c._2_1_ + cVar2 + -8 + (bVar1 & 0xf),(undefined2)local_c);
              }
              else if ((local_14 & 0xc0) == 0xc0) {
                local_34 = local_14 & 0x3f;
              }
              local_168[(int)((local_c & 0xff) * 3 + (local_c >> 8 & 0xff) * 5 +
                              (local_c >> 0x10 & 0xff) * 7 + (local_c >> 0x18) * 0xb & 0x3f)] =
                   local_c;
            }
          }
          else {
            local_34 = local_34 - 1;
          }
          *(char *)((long)local_40 + (long)local_24) = (char)local_c;
          *(char *)((long)local_40 + (long)(local_24 + 1)) = local_c._1_1_;
          *(char *)((long)local_40 + (long)(local_24 + 2)) = local_c._2_1_;
          if (local_18 == 4) {
            *(undefined1 *)((long)local_40 + (long)(local_24 + 3)) = local_c._3_1_;
          }
        }
        local_58 = local_40;
      }
    }
  }
  return local_58;
}

