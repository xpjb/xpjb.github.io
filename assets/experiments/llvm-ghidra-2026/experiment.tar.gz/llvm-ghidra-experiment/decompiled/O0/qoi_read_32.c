
uint qoi_read_32(long param_1,int *param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  
  iVar4 = *param_2;
  *param_2 = iVar4 + 1;
  bVar1 = *(byte *)(param_1 + iVar4);
  iVar4 = *param_2;
  *param_2 = iVar4 + 1;
  bVar2 = *(byte *)(param_1 + iVar4);
  iVar4 = *param_2;
  *param_2 = iVar4 + 1;
  bVar3 = *(byte *)(param_1 + iVar4);
  iVar4 = *param_2;
  *param_2 = iVar4 + 1;
  return (uint)bVar1 << 0x18 | (uint)bVar2 << 0x10 | (uint)bVar3 << 8 |
         (uint)*(byte *)(param_1 + iVar4);
}

