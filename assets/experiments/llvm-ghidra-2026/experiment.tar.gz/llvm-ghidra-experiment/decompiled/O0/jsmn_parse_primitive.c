
undefined4
jsmn_parse_primitive(uint *param_1,long param_2,ulong param_3,long param_4,undefined8 param_5)

{
  uint uVar1;
  int iVar2;
  long lVar3;
  int iVar4;
  bool bVar5;
  
  uVar1 = *param_1;
  while( true ) {
    bVar5 = false;
    if (*param_1 < param_3) {
      bVar5 = *(char *)(param_2 + (ulong)*param_1) != '\0';
    }
    if (!bVar5) {
      *param_1 = uVar1;
      return 0xfffffffd;
    }
    iVar2 = (int)*(char *)(param_2 + (ulong)*param_1);
    iVar4 = iVar2 + -0xb;
    if (((((iVar2 - 9U < 2) || (iVar4 = 0, iVar2 == 0xd)) || (iVar4 = 0, iVar2 == 0x20)) ||
        ((iVar4 = 0, iVar2 == 0x2c || (iVar4 = iVar2 + -0x5d, iVar4 == 0)))) || (iVar2 == 0x7d))
    break;
    if ((*(char *)(param_2 + (ulong)*param_1) < ' ') || ('~' < *(char *)(param_2 + (ulong)*param_1))
       ) {
      *param_1 = uVar1;
      return 0xfffffffe;
    }
    *param_1 = *param_1 + 1;
  }
  if (param_4 == 0) {
    *param_1 = *param_1 - 1;
    return 0;
  }
  lVar3 = jsmn_alloc_token(param_1,param_4,param_5,iVar4);
  if (lVar3 == 0) {
    *param_1 = uVar1;
    return 0xffffffff;
  }
  jsmn_fill_token(lVar3,8,uVar1,*param_1);
  *param_1 = *param_1 - 1;
  return 0;
}

