
void qoi_write_32(long param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = *param_2;
  *param_2 = iVar1 + 1;
  *(char *)(param_1 + iVar1) = (char)((uint)param_3 >> 0x18);
  iVar1 = *param_2;
  *param_2 = iVar1 + 1;
  *(char *)(param_1 + iVar1) = (char)((uint)param_3 >> 0x10);
  iVar1 = *param_2;
  *param_2 = iVar1 + 1;
  *(char *)(param_1 + iVar1) = (char)((uint)param_3 >> 8);
  iVar1 = *param_2;
  *param_2 = iVar1 + 1;
  *(char *)(param_1 + iVar1) = (char)param_3;
  return;
}

