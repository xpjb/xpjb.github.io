
void sha256_init(long param_1)

{
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = 0;
  *(undefined4 *)(param_1 + 0x50) = 0x6a09e667;
  *(undefined4 *)(param_1 + 0x54) = 0xbb67ae85;
  *(undefined4 *)(param_1 + 0x58) = 0x3c6ef372;
  *(undefined4 *)(param_1 + 0x5c) = 0xa54ff53a;
  *(undefined4 *)(param_1 + 0x60) = 0x510e527f;
  *(undefined4 *)(param_1 + 100) = 0x9b05688c;
  *(undefined4 *)(param_1 + 0x68) = 0x1f83d9ab;
  *(undefined4 *)(param_1 + 0x6c) = 0x5be0cd19;
  return;
}

