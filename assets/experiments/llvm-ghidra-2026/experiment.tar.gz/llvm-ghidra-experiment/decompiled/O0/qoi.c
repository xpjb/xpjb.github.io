
void * qoi_encode(long param_1,uint *param_2,int *param_3)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  int local_178 [66];
  long local_70;
  int *local_68;
  int local_60;
  int local_5c;
  void *local_58;
  long local_50;
  int local_48;
  uint local_44;
  uint local_40;
  int local_3c;
  int local_38;
  int local_34;
  uint *local_30;
  undefined4 local_24;
  void *local_20;
  char local_18;
  char local_17;
  char local_16;
  char local_15;
  undefined1 local_14 [2];
  byte bStack_12;
  byte bStack_11;
  char local_d;
  int local_c;
  
  if (((((param_1 == 0) || (param_3 == (int *)0x0)) || (param_2 == (uint *)0x0)) ||
      (((*param_2 == 0 || (param_2[1] == 0)) ||
       (((byte)param_2[2] < 3 || ((4 < (byte)param_2[2] || (1 < *(byte *)((long)param_2 + 9)))))))))
     || ((uint)(400000000 / (ulong)*param_2) <= param_2[1])) {
    local_58 = (void *)0x0;
  }
  else {
    local_60 = *param_2 * param_2[1] * ((byte)param_2[2] + 1) + 0x16;
    local_c = 0;
    local_70 = param_1;
    local_68 = param_3;
    local_30 = param_2;
    local_20 = malloc((long)local_60);
    if (local_20 == (void *)0x0) {
      local_58 = (void *)0x0;
    }
    else {
      qoi_write_32(local_20,&local_c,0x716f6966);
      qoi_write_32(local_20,&local_c,*local_30);
      qoi_write_32(local_20,&local_c,local_30[1]);
      iVar3 = local_c + 1;
      *(char *)((long)local_20 + (long)local_c) = (char)local_30[2];
      local_c = local_c + 2;
      *(undefined1 *)((long)local_20 + (long)iVar3) = *(undefined1 *)((long)local_30 + 9);
      local_50 = local_70;
      memset(local_178,0,0x100);
      local_38 = 0;
      local_24 = 0xff000000;
      _local_14 = -0x1000000;
      local_48 = *local_30 * local_30[1] * (uint)(byte)local_30[2];
      local_5c = local_48 - (uint)(byte)local_30[2];
      local_44 = (uint)(byte)local_30[2];
      for (local_34 = 0; iVar3 = local_c, local_24 = _local_14, local_34 < local_48;
          local_34 = local_44 + local_34) {
        bVar1 = *(byte *)(local_50 + (local_34 + 1));
        bVar2 = *(byte *)(local_50 + (local_34 + 2));
        bStack_11 = SUB41(local_24,3);
        _local_14 = CONCAT12(bVar2,CONCAT11(bVar1,*(undefined1 *)(local_50 + local_34)));
        if (local_44 == 4) {
          bStack_11 = *(byte *)(local_50 + (local_34 + 3));
        }
        if (_local_14 == local_24) {
          local_38 = local_38 + 1;
          if ((local_38 == 0x3e) || (local_34 == local_5c)) {
            local_c = local_c + 1;
            *(byte *)((long)local_20 + (long)iVar3) = (char)local_38 - 1U | 0xc0;
            local_38 = 0;
          }
        }
        else {
          if (0 < local_38) {
            local_c = local_c + 1;
            *(byte *)((long)local_20 + (long)iVar3) = (char)local_38 - 1U | 0xc0;
            local_38 = 0;
          }
          iVar3 = local_c;
          local_40 = (_local_14 & 0xff) * 3 + (uint)bVar1 * 5 + (uint)bVar2 * 7 +
                     (uint)bStack_11 * 0xb & 0x3f;
          if (local_178[(int)local_40] == _local_14) {
            local_c = local_c + 1;
            *(char *)((long)local_20 + (long)iVar3) = (char)local_40;
          }
          else {
            local_178[(int)local_40] = _local_14;
            iVar3 = local_c;
            if (bStack_11 == local_24._3_1_) {
              local_16 = local_14[0] - (char)local_24;
              local_d = local_14[1] - local_24._1_1_;
              local_15 = bStack_12 - local_24._2_1_;
              local_18 = local_16 - local_d;
              local_17 = local_15 - local_d;
              if (((((local_16 < -2) || ('\x01' < local_16)) || (local_d < -2)) ||
                  (('\x01' < local_d || (local_15 < -2)))) || ('\x01' < local_15)) {
                if (((local_18 < -8) || ('\a' < local_18)) ||
                   ((local_d < -0x20 ||
                    ((('\x1f' < local_d || (local_17 < -8)) || ('\a' < local_17)))))) {
                  *(undefined1 *)((long)local_20 + (long)local_c) = 0xfe;
                  *(char *)((long)local_20 + (long)(local_c + 1)) = local_14[0];
                  iVar3 = local_c + 3;
                  *(char *)((long)local_20 + (long)(local_c + 2)) = local_14[1];
                  local_c = local_c + 4;
                  *(byte *)((long)local_20 + (long)iVar3) = bStack_12;
                }
                else {
                  iVar3 = local_c + 1;
                  *(byte *)((long)local_20 + (long)local_c) = local_d + 0x20U | 0x80;
                  local_c = local_c + 2;
                  *(byte *)((long)local_20 + (long)iVar3) =
                       (local_18 + '\b') * '\x10' | local_17 + 8U;
                }
              }
              else {
                local_c = local_c + 1;
                *(byte *)((long)local_20 + (long)iVar3) =
                     (local_16 + '\x02') * '\x10' | 0x40U | (local_d + '\x02') * '\x04' |
                     local_15 + 2U;
              }
            }
            else {
              *(undefined1 *)((long)local_20 + (long)local_c) = 0xff;
              *(char *)((long)local_20 + (long)(local_c + 1)) = local_14[0];
              *(char *)((long)local_20 + (long)(local_c + 2)) = local_14[1];
              iVar3 = local_c + 4;
              *(byte *)((long)local_20 + (long)(local_c + 3)) = bStack_12;
              local_c = local_c + 5;
              *(byte *)((long)local_20 + (long)iVar3) = bStack_11;
            }
          }
        }
        local_24 = _local_14;
      }
      for (local_3c = 0; local_3c < 8; local_3c = local_3c + 1) {
        *(undefined1 *)((long)local_20 + (long)local_c) =
             *(undefined1 *)((long)&qoi_padding + (long)local_3c);
        local_c = local_c + 1;
      }
      *local_68 = local_c;
      local_58 = local_20;
    }
  }
  return local_58;
}




void qoi_write_32(long param_1,int *param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = *param_2;
  *param_2 = iVar1 + 1;
  *(char *)(param_1 + iVar1) = (char)((uint)param_3 >> 0x18);
  iVar1 = *param_2;
  *param_2 = iVar1 + 1;
  *(char *)(param_1 + iVar1) = (char)((uint)param_3 >> 0x10);
  iVar1 = *param_2;
  *param_2 = iVar1 + 1;
  *(char *)(param_1 + iVar1) = (char)((uint)param_3 >> 8);
  iVar1 = *param_2;
  *param_2 = iVar1 + 1;
  *(char *)(param_1 + iVar1) = (char)param_3;
  return;
}




void * qoi_decode(long param_1,int param_2,uint *param_3,uint param_4)

{
  byte bVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint local_168 [64];
  long local_68;
  int local_60;
  int local_5c;
  void *local_58;
  int local_4c;
  int local_48;
  uint local_44;
  void *local_40;
  int local_38;
  uint local_34;
  long local_30;
  int local_24;
  uint *local_20;
  uint local_18;
  uint local_14;
  int local_10;
  undefined4 local_c;
  
  local_10 = 0;
  local_34 = 0;
  if ((((param_1 == 0) || (param_3 == (uint *)0x0)) ||
      ((param_4 != 0 && ((param_4 != 3 && (param_4 != 4)))))) || (param_2 < 0x16)) {
    local_58 = (void *)0x0;
  }
  else {
    local_68 = param_1;
    local_4c = param_2;
    local_30 = param_1;
    local_20 = param_3;
    local_18 = param_4;
    local_60 = qoi_read_32(param_1,&local_10);
    uVar3 = qoi_read_32(local_30,&local_10);
    *local_20 = uVar3;
    uVar3 = qoi_read_32(local_30,&local_10);
    local_20[1] = uVar3;
    iVar4 = local_10 + 1;
    *(undefined1 *)(local_20 + 2) = *(undefined1 *)(local_30 + local_10);
    local_10 = local_10 + 2;
    *(undefined1 *)((long)local_20 + 9) = *(undefined1 *)(local_30 + iVar4);
    if (((((*local_20 == 0) || (local_20[1] == 0)) || ((byte)local_20[2] < 3)) ||
        ((4 < (byte)local_20[2] || (1 < *(byte *)((long)local_20 + 9))))) ||
       ((local_60 != 0x716f6966 || ((uint)(400000000 / (ulong)*local_20) <= local_20[1])))) {
      local_58 = (void *)0x0;
    }
    else {
      if (local_18 == 0) {
        local_18 = (uint)(byte)local_20[2];
      }
      local_48 = *local_20 * local_20[1] * local_18;
      local_40 = malloc((long)local_48);
      if (local_40 == (void *)0x0) {
        local_58 = (void *)0x0;
      }
      else {
        memset(local_168,0,0x100);
        local_c = 0xff000000;
        local_5c = local_4c + -8;
        for (local_24 = 0; iVar4 = local_10, local_24 < local_48; local_24 = local_18 + local_24) {
          if ((int)local_34 < 1) {
            if (local_10 < local_5c) {
              iVar5 = local_10 + 1;
              local_10 = iVar5;
              bVar1 = *(byte *)(local_30 + iVar4);
              local_14 = (uint)bVar1;
              if (local_14 == 0xfe) {
                local_c._0_2_ =
                     CONCAT11(*(undefined1 *)(local_30 + (iVar4 + 2)),
                              *(undefined1 *)(local_30 + iVar5));
                local_10 = iVar4 + 4;
                local_c._0_3_ =
                     CONCAT12(*(undefined1 *)(local_30 + (iVar4 + 3)),(undefined2)local_c);
              }
              else if (local_14 == 0xff) {
                local_c._0_2_ =
                     CONCAT11(*(undefined1 *)(local_30 + (iVar4 + 2)),
                              *(undefined1 *)(local_30 + iVar5));
                local_c._0_3_ =
                     CONCAT12(*(undefined1 *)(local_30 + (iVar4 + 3)),(undefined2)local_c);
                local_10 = iVar4 + 5;
                local_c = CONCAT13(*(undefined1 *)(local_30 + (iVar4 + 4)),(undefined3)local_c);
              }
              else if ((bVar1 & 0xc0) == 0) {
                local_c = local_168[(int)local_14];
              }
              else if ((local_14 & 0xc0) == 0x40) {
                local_c._0_2_ =
                     CONCAT11(local_c._1_1_ + (((byte)((int)local_14 >> 2) & 3) - 2),
                              (char)local_c + (((byte)((int)local_14 >> 4) & 3) - 2));
                local_c._0_3_ = CONCAT12(local_c._2_1_ + ((bVar1 & 3) - 2),(undefined2)local_c);
              }
              else if ((local_14 & 0xc0) == 0x80) {
                local_10 = iVar4 + 2;
                bVar1 = *(byte *)(local_30 + iVar5);
                local_44 = (uint)bVar1;
                local_38 = (local_14 & 0x3f) - 0x20;
                cVar2 = (char)local_38;
                local_c._0_2_ =
                     CONCAT11(local_c._1_1_ + cVar2,
                              (char)local_c + cVar2 + -8 + (char)((int)(uint)bVar1 >> 4));
                local_c._0_3_ =
                     CONCAT12(local_c._2_1_ + cVar2 + -8 + (bVar1 & 0xf),(undefined2)local_c);
              }
              else if ((local_14 & 0xc0) == 0xc0) {
                local_34 = local_14 & 0x3f;
              }
              local_168[(int)((local_c & 0xff) * 3 + (local_c >> 8 & 0xff) * 5 +
                              (local_c >> 0x10 & 0xff) * 7 + (local_c >> 0x18) * 0xb & 0x3f)] =
                   local_c;
            }
          }
          else {
            local_34 = local_34 - 1;
          }
          *(char *)((long)local_40 + (long)local_24) = (char)local_c;
          *(char *)((long)local_40 + (long)(local_24 + 1)) = local_c._1_1_;
          *(char *)((long)local_40 + (long)(local_24 + 2)) = local_c._2_1_;
          if (local_18 == 4) {
            *(undefined1 *)((long)local_40 + (long)(local_24 + 3)) = local_c._3_1_;
          }
        }
        local_58 = local_40;
      }
    }
  }
  return local_58;
}




uint qoi_read_32(long param_1,int *param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  
  iVar4 = *param_2;
  *param_2 = iVar4 + 1;
  bVar1 = *(byte *)(param_1 + iVar4);
  iVar4 = *param_2;
  *param_2 = iVar4 + 1;
  bVar2 = *(byte *)(param_1 + iVar4);
  iVar4 = *param_2;
  *param_2 = iVar4 + 1;
  bVar3 = *(byte *)(param_1 + iVar4);
  iVar4 = *param_2;
  *param_2 = iVar4 + 1;
  return (uint)bVar1 << 0x18 | (uint)bVar2 << 0x10 | (uint)bVar3 << 8 |
         (uint)*(byte *)(param_1 + iVar4);
}



