
uint jsmn_parse(uint *param_1,long param_2,ulong param_3,long param_4,undefined4 param_5)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  int *piVar4;
  long lVar5;
  undefined4 uVar6;
  int iVar7;
  bool bVar8;
  uint local_30;
  uint local_c;
  
  local_30 = param_1[1];
  do {
    bVar8 = false;
    if (*param_1 < param_3) {
      bVar8 = *(char *)(param_2 + (ulong)*param_1) != '\0';
    }
    if (!bVar8) {
      if (param_4 != 0) {
        local_c = param_1[1];
        while (local_c = local_c - 1, -1 < (int)local_c) {
          if ((*(int *)(param_4 + (long)(int)local_c * 0x10 + 4) != -1) &&
             (*(int *)(param_4 + (long)(int)local_c * 0x10 + 8) == -1)) {
            return 0xfffffffd;
          }
        }
      }
      return local_30;
    }
    cVar1 = *(char *)(param_2 + (ulong)*param_1);
    switch(cVar1) {
    case '\t':
    case '\n':
    case '\r':
    case ' ':
      break;
    default:
      return 0xfffffffe;
    case '\"':
      uVar2 = jsmn_parse_string(param_1,param_2,param_3,param_4,param_5);
      if ((int)uVar2 < 0) {
        return uVar2;
      }
      local_30 = local_30 + 1;
      if ((param_1[2] != 0xffffffff) && (param_4 != 0)) {
        lVar5 = param_4 + (long)(int)param_1[2] * 0x10;
        *(int *)(lVar5 + 0xc) = *(int *)(lVar5 + 0xc) + 1;
      }
      break;
    case ',':
      if ((((param_4 != 0) && (param_1[2] != 0xffffffff)) &&
          (*(int *)(param_4 + (long)(int)param_1[2] * 0x10) != 2)) &&
         (*(int *)(param_4 + (long)(int)param_1[2] * 0x10) != 1)) {
        local_c = param_1[1];
        do {
          local_c = local_c - 1;
          if ((int)local_c < 0) goto LAB_001021fd;
        } while (((*(int *)(param_4 + (long)(int)local_c * 0x10) != 2) &&
                 (*(int *)(param_4 + (long)(int)local_c * 0x10) != 1)) ||
                ((*(int *)(param_4 + (long)(int)local_c * 0x10 + 4) == -1 ||
                 (*(int *)(param_4 + (long)(int)local_c * 0x10 + 8) != -1))));
        param_1[2] = local_c;
      }
      break;
    case '-':
    case '0':
    case '1':
    case '2':
    case '3':
    case '4':
    case '5':
    case '6':
    case '7':
    case '8':
    case '9':
    case 'f':
    case 'n':
    case 't':
      if (((param_4 != 0) && (param_1[2] != 0xffffffff)) &&
         ((piVar4 = (int *)(param_4 + (long)(int)param_1[2] * 0x10), *piVar4 == 1 ||
          ((*piVar4 == 4 && (piVar4[3] != 0)))))) {
        return 0xfffffffe;
      }
      uVar2 = jsmn_parse_primitive(param_1,param_2,param_3,param_4,param_5);
      if ((int)uVar2 < 0) {
        return uVar2;
      }
      local_30 = local_30 + 1;
      if ((param_1[2] != 0xffffffff) && (param_4 != 0)) {
        lVar5 = param_4 + (long)(int)param_1[2] * 0x10;
        *(int *)(lVar5 + 0xc) = *(int *)(lVar5 + 0xc) + 1;
      }
      break;
    case ':':
      param_1[2] = param_1[1] - 1;
      break;
    case '[':
    case '{':
      local_30 = local_30 + 1;
      if (param_4 != 0) {
        puVar3 = (undefined4 *)jsmn_alloc_token(param_1,param_4,param_5);
        if (puVar3 == (undefined4 *)0x0) {
          return 0xffffffff;
        }
        if (param_1[2] != 0xffffffff) {
          piVar4 = (int *)(param_4 + (long)(int)param_1[2] * 0x10);
          if (*piVar4 == 1) {
            return 0xfffffffe;
          }
          piVar4[3] = piVar4[3] + 1;
        }
        uVar6 = 2;
        if (cVar1 == '{') {
          uVar6 = 1;
        }
        *puVar3 = uVar6;
        puVar3[1] = *param_1;
        param_1[2] = param_1[1] - 1;
      }
      break;
    case ']':
    case '}':
      if (param_4 != 0) {
        iVar7 = 2;
        if (cVar1 == '}') {
          iVar7 = 1;
        }
        local_c = param_1[1];
        do {
          local_c = local_c - 1;
          if ((int)local_c < 0) goto LAB_00101f7f;
          piVar4 = (int *)(param_4 + (long)(int)local_c * 0x10);
        } while ((piVar4[1] == -1) || (piVar4[2] != -1));
        if (*piVar4 != iVar7) {
          return 0xfffffffe;
        }
        param_1[2] = 0xffffffff;
        piVar4[2] = *param_1 + 1;
LAB_00101f7f:
        if (local_c == 0xffffffff) {
          return 0xfffffffe;
        }
        for (; -1 < (int)local_c; local_c = local_c - 1) {
          lVar5 = param_4 + (long)(int)local_c * 0x10;
          if ((*(int *)(lVar5 + 4) != -1) && (*(int *)(lVar5 + 8) == -1)) {
            param_1[2] = local_c;
            break;
          }
        }
      }
    }
LAB_001021fd:
    *param_1 = *param_1 + 1;
  } while( true );
}




long jsmn_alloc_token(long param_1,long param_2,ulong param_3)

{
  uint uVar1;
  undefined8 local_20;
  
  if (*(uint *)(param_1 + 4) < param_3) {
    uVar1 = *(uint *)(param_1 + 4);
    *(uint *)(param_1 + 4) = uVar1 + 1;
    local_20 = param_2 + (ulong)uVar1 * 0x10;
    *(undefined4 *)(local_20 + 8) = 0xffffffff;
    *(undefined4 *)(local_20 + 4) = 0xffffffff;
    *(undefined4 *)(local_20 + 0xc) = 0;
  }
  else {
    local_20 = 0;
  }
  return local_20;
}




undefined4
jsmn_parse_string(uint *param_1,long param_2,ulong param_3,long param_4,undefined8 param_5)

{
  uint uVar1;
  long lVar2;
  bool bVar3;
  int local_2c;
  undefined4 local_18;
  
  uVar1 = *param_1;
  *param_1 = *param_1 + 1;
  while( true ) {
    bVar3 = false;
    if (*param_1 < param_3) {
      bVar3 = *(char *)(param_2 + (ulong)*param_1) != '\0';
    }
    if (!bVar3) break;
    if (*(char *)(param_2 + (ulong)*param_1) == '\"') {
      if (param_4 == 0) {
        local_18 = 0;
      }
      else {
        lVar2 = jsmn_alloc_token(param_1,param_4,param_5);
        if (lVar2 == 0) {
          *param_1 = uVar1;
          local_18 = 0xffffffff;
        }
        else {
          jsmn_fill_token(lVar2,4,uVar1 + 1,*param_1);
          local_18 = 0;
        }
      }
      return local_18;
    }
    if ((*(char *)(param_2 + (ulong)*param_1) == '\\') && (*param_1 + 1 < param_3)) {
      *param_1 = *param_1 + 1;
      switch(*(undefined1 *)(param_2 + (ulong)*param_1)) {
      case 0x22:
      case 0x2f:
      case 0x5c:
      case 0x62:
      case 0x66:
      case 0x6e:
      case 0x72:
      case 0x74:
        break;
      default:
        *param_1 = uVar1;
        return 0xfffffffe;
      case 0x75:
        *param_1 = *param_1 + 1;
        local_2c = 0;
        while( true ) {
          bVar3 = false;
          if ((local_2c < 4) && (bVar3 = false, *param_1 < param_3)) {
            bVar3 = *(char *)(param_2 + (ulong)*param_1) != '\0';
          }
          if (!bVar3) break;
          if ((((*(char *)(param_2 + (ulong)*param_1) < '0') ||
               ('9' < *(char *)(param_2 + (ulong)*param_1))) &&
              ((*(char *)(param_2 + (ulong)*param_1) < 'A' ||
               ('F' < *(char *)(param_2 + (ulong)*param_1))))) &&
             ((*(char *)(param_2 + (ulong)*param_1) < 'a' ||
              ('f' < *(char *)(param_2 + (ulong)*param_1))))) {
            *param_1 = uVar1;
            return 0xfffffffe;
          }
          *param_1 = *param_1 + 1;
          local_2c = local_2c + 1;
        }
        *param_1 = *param_1 - 1;
      }
    }
    *param_1 = *param_1 + 1;
  }
  *param_1 = uVar1;
  return 0xfffffffd;
}




undefined4
jsmn_parse_primitive(uint *param_1,long param_2,ulong param_3,long param_4,undefined8 param_5)

{
  uint uVar1;
  int iVar2;
  long lVar3;
  int iVar4;
  bool bVar5;
  
  uVar1 = *param_1;
  while( true ) {
    bVar5 = false;
    if (*param_1 < param_3) {
      bVar5 = *(char *)(param_2 + (ulong)*param_1) != '\0';
    }
    if (!bVar5) {
      *param_1 = uVar1;
      return 0xfffffffd;
    }
    iVar2 = (int)*(char *)(param_2 + (ulong)*param_1);
    iVar4 = iVar2 + -0xb;
    if (((((iVar2 - 9U < 2) || (iVar4 = 0, iVar2 == 0xd)) || (iVar4 = 0, iVar2 == 0x20)) ||
        ((iVar4 = 0, iVar2 == 0x2c || (iVar4 = iVar2 + -0x5d, iVar4 == 0)))) || (iVar2 == 0x7d))
    break;
    if ((*(char *)(param_2 + (ulong)*param_1) < ' ') || ('~' < *(char *)(param_2 + (ulong)*param_1))
       ) {
      *param_1 = uVar1;
      return 0xfffffffe;
    }
    *param_1 = *param_1 + 1;
  }
  if (param_4 == 0) {
    *param_1 = *param_1 - 1;
    return 0;
  }
  lVar3 = jsmn_alloc_token(param_1,param_4,param_5,iVar4);
  if (lVar3 == 0) {
    *param_1 = uVar1;
    return 0xffffffff;
  }
  jsmn_fill_token(lVar3,8,uVar1,*param_1);
  *param_1 = *param_1 - 1;
  return 0;
}




void jsmn_fill_token(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  *param_1 = param_2;
  param_1[1] = param_3;
  param_1[2] = param_4;
  param_1[3] = 0;
  return;
}




void jsmn_init(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0xffffffff;
  return;
}



