
void sha256_transform(long param_1,long param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint auStack_158 [71];
  uint local_3c;
  uint local_38;
  uint local_34;
  uint local_30;
  uint local_2c;
  uint local_28;
  uint local_24;
  uint local_14;
  uint local_10;
  uint local_c;
  
  local_24 = 0;
  for (local_c = 0; local_c < 0x10; local_c = local_c + 1) {
    auStack_158[local_c] =
         (uint)*(byte *)(param_2 + (ulong)local_24) << 0x18 |
         (uint)*(byte *)(param_2 + (ulong)(local_24 + 1)) << 0x10 |
         (uint)*(byte *)(param_2 + (ulong)(local_24 + 2)) << 8 |
         (uint)*(byte *)(param_2 + (ulong)(local_24 + 3));
    local_24 = local_24 + 4;
  }
  for (; local_c < 0x40; local_c = local_c + 1) {
    auStack_158[local_c] =
         ((auStack_158[local_c - 2] >> 0x11 | auStack_158[local_c - 2] << 0xf) ^
          (auStack_158[local_c - 2] >> 0x13 | auStack_158[local_c - 2] << 0xd) ^
         auStack_158[local_c - 2] >> 10) + auStack_158[local_c - 7] +
         ((auStack_158[local_c - 0xf] >> 7 | auStack_158[local_c - 0xf] << 0x19) ^
          (auStack_158[local_c - 0xf] >> 0x12 | auStack_158[local_c - 0xf] << 0xe) ^
         auStack_158[local_c - 0xf] >> 3) + auStack_158[local_c - 0x10];
  }
  local_14 = *(uint *)(param_1 + 0x50);
  local_2c = *(uint *)(param_1 + 0x54);
  local_28 = *(uint *)(param_1 + 0x58);
  local_3c = *(uint *)(param_1 + 0x5c);
  local_10 = *(uint *)(param_1 + 0x60);
  local_34 = *(uint *)(param_1 + 100);
  local_30 = *(uint *)(param_1 + 0x68);
  local_38 = *(uint *)(param_1 + 0x6c);
  for (local_c = 0; local_c < 0x40; local_c = local_c + 1) {
    iVar1 = local_38 +
            ((local_10 >> 6 | local_10 << 0x1a) ^ (local_10 >> 0xb | local_10 << 0x15) ^
            (local_10 >> 0x19 | local_10 << 7)) +
            (local_10 & local_34 ^ (local_10 ^ 0xffffffff) & local_30) +
            *(int *)(k + (ulong)local_c * 4) + auStack_158[local_c];
    uVar2 = local_14 & local_2c;
    uVar3 = local_14 & local_28;
    uVar4 = local_2c & local_28;
    local_38 = local_30;
    local_30 = local_34;
    local_34 = local_10;
    local_10 = local_3c + iVar1;
    local_3c = local_28;
    local_28 = local_2c;
    local_2c = local_14;
    local_14 = iVar1 + ((local_14 >> 2 | local_14 << 0x1e) ^ (local_14 >> 0xd | local_14 << 0x13) ^
                       (local_14 >> 0x16 | local_14 << 10)) + (uVar2 ^ uVar3 ^ uVar4);
  }
  *(uint *)(param_1 + 0x50) = local_14 + *(int *)(param_1 + 0x50);
  *(uint *)(param_1 + 0x54) = local_2c + *(int *)(param_1 + 0x54);
  *(uint *)(param_1 + 0x58) = local_28 + *(int *)(param_1 + 0x58);
  *(uint *)(param_1 + 0x5c) = local_3c + *(int *)(param_1 + 0x5c);
  *(uint *)(param_1 + 0x60) = local_10 + *(int *)(param_1 + 0x60);
  *(uint *)(param_1 + 100) = local_34 + *(int *)(param_1 + 100);
  *(uint *)(param_1 + 0x68) = local_30 + *(int *)(param_1 + 0x68);
  *(uint *)(param_1 + 0x6c) = local_38 + *(int *)(param_1 + 0x6c);
  return;
}

