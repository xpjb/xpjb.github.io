
undefined4
jsmn_parse_string(uint *param_1,long param_2,ulong param_3,long param_4,undefined8 param_5)

{
  uint uVar1;
  long lVar2;
  bool bVar3;
  int local_2c;
  undefined4 local_18;
  
  uVar1 = *param_1;
  *param_1 = *param_1 + 1;
  while( true ) {
    bVar3 = false;
    if (*param_1 < param_3) {
      bVar3 = *(char *)(param_2 + (ulong)*param_1) != '\0';
    }
    if (!bVar3) break;
    if (*(char *)(param_2 + (ulong)*param_1) == '\"') {
      if (param_4 == 0) {
        local_18 = 0;
      }
      else {
        lVar2 = jsmn_alloc_token(param_1,param_4,param_5);
        if (lVar2 == 0) {
          *param_1 = uVar1;
          local_18 = 0xffffffff;
        }
        else {
          jsmn_fill_token(lVar2,4,uVar1 + 1,*param_1);
          local_18 = 0;
        }
      }
      return local_18;
    }
    if ((*(char *)(param_2 + (ulong)*param_1) == '\\') && (*param_1 + 1 < param_3)) {
      *param_1 = *param_1 + 1;
      switch(*(undefined1 *)(param_2 + (ulong)*param_1)) {
      case 0x22:
      case 0x2f:
      case 0x5c:
      case 0x62:
      case 0x66:
      case 0x6e:
      case 0x72:
      case 0x74:
        break;
      default:
        *param_1 = uVar1;
        return 0xfffffffe;
      case 0x75:
        *param_1 = *param_1 + 1;
        local_2c = 0;
        while( true ) {
          bVar3 = false;
          if ((local_2c < 4) && (bVar3 = false, *param_1 < param_3)) {
            bVar3 = *(char *)(param_2 + (ulong)*param_1) != '\0';
          }
          if (!bVar3) break;
          if ((((*(char *)(param_2 + (ulong)*param_1) < '0') ||
               ('9' < *(char *)(param_2 + (ulong)*param_1))) &&
              ((*(char *)(param_2 + (ulong)*param_1) < 'A' ||
               ('F' < *(char *)(param_2 + (ulong)*param_1))))) &&
             ((*(char *)(param_2 + (ulong)*param_1) < 'a' ||
              ('f' < *(char *)(param_2 + (ulong)*param_1))))) {
            *param_1 = uVar1;
            return 0xfffffffe;
          }
          *param_1 = *param_1 + 1;
          local_2c = local_2c + 1;
        }
        *param_1 = *param_1 - 1;
      }
    }
    *param_1 = *param_1 + 1;
  }
  *param_1 = uVar1;
  return 0xfffffffd;
}

