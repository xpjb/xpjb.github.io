
void sha256_update(long param_1,long param_2,ulong param_3)

{
  int iVar1;
  uint uVar2;
  
  for (uVar2 = 0; uVar2 < param_3; uVar2 = uVar2 + 1) {
    *(undefined1 *)(param_1 + (ulong)*(uint *)(param_1 + 0x40)) =
         *(undefined1 *)(param_2 + (ulong)uVar2);
    iVar1 = *(int *)(param_1 + 0x40) + 1;
    *(int *)(param_1 + 0x40) = iVar1;
    if (iVar1 == 0x40) {
      sha256_transform(param_1,param_1);
      *(long *)(param_1 + 0x48) = *(long *)(param_1 + 0x48) + 0x200;
      *(undefined4 *)(param_1 + 0x40) = 0;
    }
  }
  return;
}

