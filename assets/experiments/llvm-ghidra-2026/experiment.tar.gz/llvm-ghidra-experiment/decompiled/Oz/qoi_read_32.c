
uint qoi_read_32(long param_1,int *param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  
  iVar4 = *param_2;
  *param_2 = iVar4 + 1;
  bVar1 = *(byte *)(param_1 + iVar4);
  *param_2 = iVar4 + 2;
  bVar2 = *(byte *)(param_1 + (iVar4 + 1));
  *param_2 = iVar4 + 3;
  bVar3 = *(byte *)(param_1 + (iVar4 + 2));
  *param_2 = iVar4 + 4;
  return (uint)bVar3 << 8 | (uint)bVar2 << 0x10 | (uint)bVar1 << 0x18 |
         (uint)*(byte *)(param_1 + (iVar4 + 3));
}

