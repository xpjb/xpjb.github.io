
void sha256_final(undefined1 (*param_1) [32],long param_2)

{
  uint uVar1;
  uint uVar2;
  ulong uVar3;
  long lVar4;
  
  uVar2 = *(uint *)param_1[2];
  uVar3 = (ulong)uVar2;
  (*param_1)[uVar3] = 0x80;
  if (uVar3 < 0x38) {
    for (; uVar3 != 0x37; uVar3 = uVar3 + 1) {
      (*param_1)[uVar3 + 1] = 0;
    }
  }
  else {
    for (uVar3 = (ulong)(uVar2 + 1); (uint)uVar3 < 0x40; uVar3 = uVar3 + 1) {
      (*param_1)[uVar3] = 0;
    }
    sha256_transform(param_1,param_1);
    *(undefined1 (*) [32])(*param_1 + 0x18) = ZEXT1232(ZEXT812(0));
    *param_1 = ZEXT1232(ZEXT812(0));
  }
  lVar4 = (ulong)(uint)(*(int *)param_1[2] << 3) + *(long *)(param_1[2] + 8);
  *(long *)(param_1[2] + 8) = lVar4;
  param_1[1][0x1f] = (char)lVar4;
  param_1[1][0x1e] = (char)((ulong)lVar4 >> 8);
  param_1[1][0x1d] = (char)((ulong)lVar4 >> 0x10);
  param_1[1][0x1c] = (char)((ulong)lVar4 >> 0x18);
  param_1[1][0x1b] = (char)((ulong)lVar4 >> 0x20);
  param_1[1][0x1a] = (char)((ulong)lVar4 >> 0x28);
  param_1[1][0x19] = (char)((ulong)lVar4 >> 0x30);
  param_1[1][0x18] = (char)((ulong)lVar4 >> 0x38);
  sha256_transform(param_1,param_1);
  uVar2 = 0x18;
  for (lVar4 = -4; lVar4 != 0; lVar4 = lVar4 + 1) {
    *(char *)(param_2 + 4 + lVar4) = (char)(*(uint *)(param_1[2] + 0x10) >> (uVar2 & 0x1f));
    *(char *)(param_2 + 8 + lVar4) = (char)(*(uint *)(param_1[2] + 0x14) >> (uVar2 & 0x1f));
    *(char *)(param_2 + 0xc + lVar4) = (char)(*(uint *)(param_1[2] + 0x18) >> (uVar2 & 0x1f));
    *(char *)(param_2 + 0x10 + lVar4) = (char)(*(uint *)(param_1[2] + 0x1c) >> (uVar2 & 0x1f));
    *(char *)(param_2 + 0x14 + lVar4) = (char)(*(uint *)param_1[3] >> (uVar2 & 0x1f));
    *(char *)(param_2 + 0x18 + lVar4) = (char)(*(uint *)(param_1[3] + 4) >> (uVar2 & 0x1f));
    *(char *)(param_2 + 0x1c + lVar4) = (char)(*(uint *)(param_1[3] + 8) >> (uVar2 & 0x1f));
    uVar1 = uVar2 & 0x1f;
    uVar2 = uVar2 - 8;
    *(char *)(param_2 + 0x20 + lVar4) = (char)(*(uint *)(param_1[3] + 0xc) >> uVar1);
  }
  return;
}

