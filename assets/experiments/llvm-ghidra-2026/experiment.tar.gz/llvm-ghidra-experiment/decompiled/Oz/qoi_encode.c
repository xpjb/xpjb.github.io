
undefined4 * qoi_encode(long param_1,uint *param_2,int *param_3)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  uint uVar5;
  byte bVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  undefined4 *puVar11;
  int iVar12;
  long lVar13;
  byte bVar14;
  char cVar15;
  int iVar16;
  int iVar17;
  byte bVar18;
  byte bVar19;
  byte bVar20;
  byte bVar21;
  char cVar22;
  ulong uVar23;
  undefined1 auVar24 [16];
  int local_144;
  int *local_140;
  undefined1 local_138 [32];
  undefined1 local_118 [32];
  undefined1 local_f8 [32];
  undefined1 local_d8 [32];
  undefined1 local_b8 [32];
  undefined1 local_98 [32];
  undefined1 local_78 [32];
  undefined1 local_58 [32];
  
  if (param_2 == (uint *)0x0) {
    return (undefined4 *)0x0;
  }
  if (param_1 == 0) {
    return (undefined4 *)0x0;
  }
  if (param_3 == (int *)0x0) {
    return (undefined4 *)0x0;
  }
  uVar8 = *param_2;
  if ((((uVar8 != 0) && (uVar5 = param_2[1], uVar5 != 0)) &&
      (bVar1 = (byte)param_2[2], 0xfd < (byte)(bVar1 - 5))) &&
     (bVar19 = *(byte *)((long)param_2 + 9), bVar19 < 2)) {
    if ((uint)(400000000 / (ulong)uVar8) <= uVar5) {
      return (undefined4 *)0x0;
    }
    local_140 = param_3;
    puVar11 = malloc((long)(int)((bVar1 + 1) * uVar5 * uVar8 + 0x16));
    if (puVar11 != (undefined4 *)0x0) {
      iVar9 = 0;
      *puVar11 = 0x66696f71;
      local_144 = 4;
      qoi_write_32(puVar11,&local_144,uVar8);
      qoi_write_32(puVar11,&local_144,uVar5);
      auVar24._0_12_ = ZEXT812(0);
      auVar24._12_4_ = 0;
      local_58 = ZEXT1632(auVar24);
      local_78 = ZEXT1632(auVar24);
      local_98 = ZEXT1632(auVar24);
      local_b8 = local_98;
      local_d8 = local_98;
      local_f8 = local_98;
      local_118 = ZEXT1632(auVar24);
      local_138 = ZEXT1632(auVar24);
      iVar16 = uVar5 * uVar8 * (uint)bVar1;
      *(byte *)((long)puVar11 + (long)local_144) = bVar1;
      iVar7 = local_144 + 2;
      iVar12 = 0;
      *(byte *)((long)puVar11 + (long)(local_144 + 1)) = bVar19;
      bVar14 = 0xff;
      bVar18 = 0;
      bVar19 = 0;
      bVar6 = 0;
      do {
        if (iVar16 <= iVar12) {
          for (lVar13 = 0; iVar9 = iVar7 + (int)lVar13, lVar13 != 8; lVar13 = lVar13 + 1) {
            *(undefined1 *)((long)puVar11 + (long)iVar9) = (&qoi_padding)[lVar13];
          }
          *local_140 = iVar9;
          return puVar11;
        }
        bVar20 = bVar14;
        if (bVar1 == 4) {
          bVar20 = *(byte *)(param_1 + (iVar12 + 3));
        }
        bVar2 = *(byte *)(param_1 + iVar12);
        bVar3 = *(byte *)(param_1 + 1 + (long)iVar12);
        bVar4 = *(byte *)(param_1 + (iVar12 + 2));
        uVar8 = (uint)bVar3 << 8 | (uint)bVar4 << 0x10 | (uint)bVar20 << 0x18 | (uint)bVar2;
        bVar21 = (byte)iVar9;
        if (uVar8 == ((uint)bVar18 | (uint)bVar19 << 8 | (uint)bVar6 << 0x10 | (uint)bVar14 << 0x18)
           ) {
          if ((iVar16 - (uint)bVar1 == iVar12) || (iVar9 = iVar9 + 1, iVar9 == 0x3e)) {
            uVar23 = (ulong)(bVar21 | 0xc0);
            iVar9 = 0;
LAB_001022b6:
            iVar10 = iVar7 + 1;
            iVar17 = iVar7;
            bVar19 = (byte)uVar23;
            goto LAB_0010238c;
          }
        }
        else {
          if (0 < iVar9) {
            iVar9 = 0;
            lVar13 = (long)iVar7;
            iVar7 = iVar7 + 1;
            *(byte *)((long)puVar11 + lVar13) = bVar21 - 1 | 0xc0;
          }
          uVar23 = (ulong)((uint)bVar20 * 0xb +
                           (uint)bVar3 + (uint)bVar3 * 4 + (uint)bVar2 + (uint)bVar2 * 2 +
                           (uint)bVar4 * 7 & 0x3f);
          if (*(uint *)(local_138 + uVar23 * 4) == uVar8) goto LAB_001022b6;
          lVar13 = (long)iVar7;
          local_138[uVar23 * 4] = bVar2;
          local_138[uVar23 * 4 + 1] = bVar3;
          local_138[uVar23 * 4 + 2] = bVar4;
          local_138[uVar23 * 4 + 3] = bVar20;
          if (bVar20 == bVar14) {
            cVar22 = bVar3 - bVar19;
            cVar15 = bVar2 - bVar18;
            if ((((byte)(cVar15 + 2U) < 4) && ((byte)(cVar22 + 2U) < 4)) &&
               (bVar19 = (bVar4 - bVar6) + 2, bVar19 < 4)) {
              iVar10 = iVar7 + 1;
              iVar17 = iVar7;
              bVar19 = cVar22 * '\x04' + 8U | cVar15 * '\x10' + 0x20U | bVar19 | 0x40;
            }
            else if ((((byte)((cVar15 - cVar22) + 8U) < 0x10) && ((byte)(cVar22 + 0x20U) < 0x40)) &&
                    (bVar19 = ((bVar4 - bVar6) - cVar22) + 8, bVar19 < 0x10)) {
              *(byte *)((long)puVar11 + lVar13) = cVar22 + 0x20U | 0x80;
              iVar10 = iVar7 + 2;
              iVar17 = iVar7 + 1;
              bVar19 = (bVar19 | (cVar15 - cVar22) * '\x10') + 0x80;
            }
            else {
              *(undefined1 *)((long)puVar11 + lVar13) = 0xfe;
              iVar10 = iVar7 + 4;
              *(byte *)((long)puVar11 + (long)(iVar7 + 1)) = bVar2;
              *(byte *)((long)puVar11 + (long)(iVar7 + 2)) = bVar3;
              iVar17 = iVar7 + 3;
              bVar19 = bVar4;
            }
          }
          else {
            *(undefined1 *)((long)puVar11 + lVar13) = 0xff;
            *(byte *)((long)puVar11 + (long)(iVar7 + 1)) = bVar2;
            *(byte *)((long)puVar11 + (long)(iVar7 + 2)) = bVar3;
            iVar17 = iVar7 + 4;
            iVar10 = iVar7 + 5;
            *(byte *)((long)puVar11 + (long)(iVar7 + 3)) = bVar4;
            bVar19 = bVar20;
          }
LAB_0010238c:
          *(byte *)((long)puVar11 + (long)iVar17) = bVar19;
          iVar7 = iVar10;
        }
        iVar12 = iVar12 + (uint)bVar1;
        bVar14 = bVar20;
        bVar18 = bVar2;
        bVar19 = bVar3;
        bVar6 = bVar4;
      } while( true );
    }
  }
  return (undefined4 *)0x0;
}

