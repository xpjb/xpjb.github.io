
void sha256_transform(long param_1,uint *param_2)

{
  long lVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint auStack_178 [9];
  int local_154 [5];
  uint local_140 [68];
  
  uVar10 = *param_2;
  local_140[2] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[1];
  local_140[3] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[2];
  local_140[4] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[3];
  local_140[5] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[4];
  local_140[6] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[5];
  local_140[7] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[6];
  local_140[8] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[7];
  local_140[9] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[8];
  local_140[10] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[9];
  local_140[0xb] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[10];
  local_140[0xc] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xb];
  local_140[0xd] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xc];
  local_140[0xe] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xd];
  local_140[0xf] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xe];
  local_140[0x10] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xf];
  local_140[0x11] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  lVar1 = 0x10;
  do {
    uVar10 = local_140[lVar1];
    uVar9 = auStack_178[lVar1 + 1];
    local_140[lVar1 + 2] =
         (uVar10 >> 10 ^ (uVar10 << 0xd | uVar10 >> 0x13) ^ (uVar10 << 0xf | uVar10 >> 0x11)) +
         local_154[lVar1] + auStack_178[lVar1] +
         (uVar9 >> 3 ^ (uVar9 << 0xe | uVar9 >> 0x12) ^ (uVar9 << 0x19 | uVar9 >> 7));
    lVar1 = lVar1 + 1;
  } while (lVar1 != 0x40);
  lVar1 = 0;
  uVar10 = *(uint *)(param_1 + 0x50);
  uVar9 = *(uint *)(param_1 + 0x54);
  uVar11 = *(uint *)(param_1 + 0x58);
  uVar8 = *(uint *)(param_1 + 0x5c);
  uVar7 = *(uint *)(param_1 + 0x60);
  uVar6 = *(uint *)(param_1 + 100);
  uVar5 = *(uint *)(param_1 + 0x68);
  uVar12 = *(uint *)(param_1 + 0x6c);
  do {
    uVar3 = uVar5;
    uVar5 = uVar6;
    uVar6 = uVar7;
    uVar2 = uVar11;
    uVar11 = uVar9;
    uVar9 = uVar10;
    iVar4 = ((uVar5 ^ uVar3) & uVar6 ^ uVar3) + uVar12 +
            ((uVar6 << 7 | uVar6 >> 0x19) ^
            (uVar6 << 0x15 | uVar6 >> 0xb) ^ (uVar6 << 0x1a | uVar6 >> 6)) +
            *(int *)((long)&k + lVar1) + *(int *)((long)local_140 + lVar1 + 8);
    uVar7 = uVar8 + iVar4;
    uVar10 = (uVar11 & uVar2 ^ (uVar11 ^ uVar2) & uVar9) +
             ((uVar9 << 10 | uVar9 >> 0x16) ^
             (uVar9 << 0x13 | uVar9 >> 0xd) ^ (uVar9 << 0x1e | uVar9 >> 2)) + iVar4;
    lVar1 = lVar1 + 4;
    uVar8 = uVar2;
    uVar12 = uVar3;
  } while (lVar1 != 0x100);
  *(uint *)(param_1 + 0x50) = uVar10 + *(uint *)(param_1 + 0x50);
  *(uint *)(param_1 + 0x54) = uVar9 + *(uint *)(param_1 + 0x54);
  *(uint *)(param_1 + 0x58) = uVar11 + *(uint *)(param_1 + 0x58);
  *(uint *)(param_1 + 0x5c) = uVar2 + *(uint *)(param_1 + 0x5c);
  *(uint *)(param_1 + 0x60) = uVar7 + *(uint *)(param_1 + 0x60);
  *(uint *)(param_1 + 100) = uVar6 + *(uint *)(param_1 + 100);
  *(uint *)(param_1 + 0x68) = uVar5 + *(uint *)(param_1 + 0x68);
  *(uint *)(param_1 + 0x6c) = uVar3 + *(uint *)(param_1 + 0x6c);
  return;
}




void sha256_init(long param_1)

{
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = 0;
  *(undefined8 *)(param_1 + 0x50) = 0xbb67ae856a09e667;
  *(undefined8 *)(param_1 + 0x58) = 0xa54ff53a3c6ef372;
  *(undefined8 *)(param_1 + 0x60) = 0x9b05688c510e527f;
  *(undefined8 *)(param_1 + 0x68) = 0x5be0cd191f83d9ab;
  return;
}




void sha256_update(long param_1,long param_2,ulong param_3)

{
  bool bVar1;
  uint uVar2;
  ulong uVar3;
  ulong uVar4;
  
  if (param_3 != 0) {
    uVar2 = *(uint *)(param_1 + 0x40);
    uVar3 = 0;
    uVar4 = 1;
    do {
      *(undefined1 *)(param_1 + (ulong)uVar2) = *(undefined1 *)(param_2 + uVar3);
      uVar2 = *(int *)(param_1 + 0x40) + 1;
      *(uint *)(param_1 + 0x40) = uVar2;
      if (uVar2 == 0x40) {
        sha256_transform(param_1,param_1);
        *(long *)(param_1 + 0x48) = *(long *)(param_1 + 0x48) + 0x200;
        *(undefined4 *)(param_1 + 0x40) = 0;
        uVar2 = 0;
      }
      bVar1 = uVar4 < param_3;
      uVar3 = uVar4;
      uVar4 = (ulong)((int)uVar4 + 1);
    } while (bVar1);
  }
  return;
}




void sha256_final(undefined8 *param_1,undefined1 *param_2)

{
  uint uVar1;
  ulong uVar2;
  long lVar3;
  
  uVar1 = *(uint *)(param_1 + 8);
  uVar2 = (ulong)uVar1;
  *(undefined1 *)((long)param_1 + uVar2) = 0x80;
  if (uVar2 < 0x38) {
    if (uVar1 != 0x37) {
      memset((void *)((long)param_1 + uVar2 + 1),0,0x37 - uVar2);
    }
  }
  else {
    if (uVar1 + 1 < 0x40) {
      memset((void *)((ulong)(uVar1 + 1) + (long)param_1),0,(ulong)(0x3e - uVar1) + 1);
    }
    sha256_transform(param_1,param_1);
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    *param_1 = 0;
    param_1[1] = 0;
    param_1[6] = 0;
  }
  lVar3 = (ulong)(uint)(*(int *)(param_1 + 8) << 3) + param_1[9];
  param_1[9] = lVar3;
  *(char *)((long)param_1 + 0x3f) = (char)lVar3;
  *(char *)((long)param_1 + 0x3e) = (char)((ulong)lVar3 >> 8);
  *(char *)((long)param_1 + 0x3d) = (char)((ulong)lVar3 >> 0x10);
  *(char *)((long)param_1 + 0x3c) = (char)((ulong)lVar3 >> 0x18);
  *(char *)((long)param_1 + 0x3b) = (char)((ulong)lVar3 >> 0x20);
  *(char *)((long)param_1 + 0x3a) = (char)((ulong)lVar3 >> 0x28);
  *(char *)((long)param_1 + 0x39) = (char)((ulong)lVar3 >> 0x30);
  *(char *)(param_1 + 7) = (char)((ulong)lVar3 >> 0x38);
  sha256_transform(param_1,param_1);
  *param_2 = *(undefined1 *)((long)param_1 + 0x53);
  param_2[4] = *(undefined1 *)((long)param_1 + 0x57);
  param_2[8] = *(undefined1 *)((long)param_1 + 0x5b);
  param_2[0xc] = *(undefined1 *)((long)param_1 + 0x5f);
  param_2[0x10] = *(undefined1 *)((long)param_1 + 99);
  param_2[0x14] = *(undefined1 *)((long)param_1 + 0x67);
  param_2[0x18] = *(undefined1 *)((long)param_1 + 0x6b);
  param_2[0x1c] = *(undefined1 *)((long)param_1 + 0x6f);
  param_2[1] = *(undefined1 *)((long)param_1 + 0x52);
  param_2[5] = *(undefined1 *)((long)param_1 + 0x56);
  param_2[9] = *(undefined1 *)((long)param_1 + 0x5a);
  param_2[0xd] = *(undefined1 *)((long)param_1 + 0x5e);
  param_2[0x11] = *(undefined1 *)((long)param_1 + 0x62);
  param_2[0x15] = *(undefined1 *)((long)param_1 + 0x66);
  param_2[0x19] = *(undefined1 *)((long)param_1 + 0x6a);
  param_2[0x1d] = *(undefined1 *)((long)param_1 + 0x6e);
  param_2[2] = *(undefined1 *)((long)param_1 + 0x51);
  param_2[6] = *(undefined1 *)((long)param_1 + 0x55);
  param_2[10] = *(undefined1 *)((long)param_1 + 0x59);
  param_2[0xe] = *(undefined1 *)((long)param_1 + 0x5d);
  param_2[0x12] = *(undefined1 *)((long)param_1 + 0x61);
  param_2[0x16] = *(undefined1 *)((long)param_1 + 0x65);
  param_2[0x1a] = *(undefined1 *)((long)param_1 + 0x69);
  param_2[0x1e] = *(undefined1 *)((long)param_1 + 0x6d);
  param_2[3] = *(undefined1 *)(param_1 + 10);
  param_2[7] = *(undefined1 *)((long)param_1 + 0x54);
  param_2[0xb] = *(undefined1 *)(param_1 + 0xb);
  param_2[0xf] = *(undefined1 *)((long)param_1 + 0x5c);
  param_2[0x13] = *(undefined1 *)(param_1 + 0xc);
  param_2[0x17] = *(undefined1 *)((long)param_1 + 100);
  param_2[0x1b] = *(undefined1 *)(param_1 + 0xd);
  param_2[0x1f] = *(undefined1 *)((long)param_1 + 0x6c);
  return;
}



