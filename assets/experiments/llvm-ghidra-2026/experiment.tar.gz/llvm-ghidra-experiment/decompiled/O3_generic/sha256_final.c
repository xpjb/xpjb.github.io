
void sha256_final(undefined8 *param_1,undefined1 *param_2)

{
  uint uVar1;
  ulong uVar2;
  long lVar3;
  
  uVar1 = *(uint *)(param_1 + 8);
  uVar2 = (ulong)uVar1;
  *(undefined1 *)((long)param_1 + uVar2) = 0x80;
  if (uVar2 < 0x38) {
    if (uVar1 != 0x37) {
      memset((void *)((long)param_1 + uVar2 + 1),0,0x37 - uVar2);
    }
  }
  else {
    if (uVar1 + 1 < 0x40) {
      memset((void *)((ulong)(uVar1 + 1) + (long)param_1),0,(ulong)(0x3e - uVar1) + 1);
    }
    sha256_transform(param_1,param_1);
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[2] = 0;
    param_1[3] = 0;
    *param_1 = 0;
    param_1[1] = 0;
    param_1[6] = 0;
  }
  lVar3 = (ulong)(uint)(*(int *)(param_1 + 8) << 3) + param_1[9];
  param_1[9] = lVar3;
  *(char *)((long)param_1 + 0x3f) = (char)lVar3;
  *(char *)((long)param_1 + 0x3e) = (char)((ulong)lVar3 >> 8);
  *(char *)((long)param_1 + 0x3d) = (char)((ulong)lVar3 >> 0x10);
  *(char *)((long)param_1 + 0x3c) = (char)((ulong)lVar3 >> 0x18);
  *(char *)((long)param_1 + 0x3b) = (char)((ulong)lVar3 >> 0x20);
  *(char *)((long)param_1 + 0x3a) = (char)((ulong)lVar3 >> 0x28);
  *(char *)((long)param_1 + 0x39) = (char)((ulong)lVar3 >> 0x30);
  *(char *)(param_1 + 7) = (char)((ulong)lVar3 >> 0x38);
  sha256_transform(param_1,param_1);
  *param_2 = *(undefined1 *)((long)param_1 + 0x53);
  param_2[4] = *(undefined1 *)((long)param_1 + 0x57);
  param_2[8] = *(undefined1 *)((long)param_1 + 0x5b);
  param_2[0xc] = *(undefined1 *)((long)param_1 + 0x5f);
  param_2[0x10] = *(undefined1 *)((long)param_1 + 99);
  param_2[0x14] = *(undefined1 *)((long)param_1 + 0x67);
  param_2[0x18] = *(undefined1 *)((long)param_1 + 0x6b);
  param_2[0x1c] = *(undefined1 *)((long)param_1 + 0x6f);
  param_2[1] = *(undefined1 *)((long)param_1 + 0x52);
  param_2[5] = *(undefined1 *)((long)param_1 + 0x56);
  param_2[9] = *(undefined1 *)((long)param_1 + 0x5a);
  param_2[0xd] = *(undefined1 *)((long)param_1 + 0x5e);
  param_2[0x11] = *(undefined1 *)((long)param_1 + 0x62);
  param_2[0x15] = *(undefined1 *)((long)param_1 + 0x66);
  param_2[0x19] = *(undefined1 *)((long)param_1 + 0x6a);
  param_2[0x1d] = *(undefined1 *)((long)param_1 + 0x6e);
  param_2[2] = *(undefined1 *)((long)param_1 + 0x51);
  param_2[6] = *(undefined1 *)((long)param_1 + 0x55);
  param_2[10] = *(undefined1 *)((long)param_1 + 0x59);
  param_2[0xe] = *(undefined1 *)((long)param_1 + 0x5d);
  param_2[0x12] = *(undefined1 *)((long)param_1 + 0x61);
  param_2[0x16] = *(undefined1 *)((long)param_1 + 0x65);
  param_2[0x1a] = *(undefined1 *)((long)param_1 + 0x69);
  param_2[0x1e] = *(undefined1 *)((long)param_1 + 0x6d);
  param_2[3] = *(undefined1 *)(param_1 + 10);
  param_2[7] = *(undefined1 *)((long)param_1 + 0x54);
  param_2[0xb] = *(undefined1 *)(param_1 + 0xb);
  param_2[0xf] = *(undefined1 *)((long)param_1 + 0x5c);
  param_2[0x13] = *(undefined1 *)(param_1 + 0xc);
  param_2[0x17] = *(undefined1 *)((long)param_1 + 100);
  param_2[0x1b] = *(undefined1 *)(param_1 + 0xd);
  param_2[0x1f] = *(undefined1 *)((long)param_1 + 0x6c);
  return;
}

