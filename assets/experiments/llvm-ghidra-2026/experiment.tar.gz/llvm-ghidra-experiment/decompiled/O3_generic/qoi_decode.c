
void * qoi_decode(uint *param_1,int param_2,uint *param_3,uint param_4)

{
  void *pvVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  byte bVar6;
  uint uVar7;
  ulong uVar8;
  byte bVar9;
  byte bVar10;
  byte bVar11;
  long lVar12;
  uint uVar13;
  byte bVar14;
  ulong local_150;
  byte local_138 [264];
  
  if ((param_1 != (uint *)0x0) && (param_3 != (uint *)0x0)) {
    if ((0x15 < param_2) && (param_4 == 3 || (param_4 & 0xfffffffb) == 0)) {
      uVar13 = *param_1;
      uVar3 = param_1[1];
      uVar7 = uVar3 >> 0x18 | (uVar3 & 0xff0000) >> 8 | (uVar3 & 0xff00) << 8 | uVar3 << 0x18;
      *param_3 = uVar7;
      uVar3 = param_1[2];
      uVar3 = uVar3 >> 0x18 | (uVar3 & 0xff0000) >> 8 | (uVar3 & 0xff00) << 8 | uVar3 << 0x18;
      param_3[1] = uVar3;
      bVar9 = (byte)param_1[3];
      *(byte *)(param_3 + 2) = bVar9;
      bVar10 = *(byte *)((long)param_1 + 0xd);
      *(byte *)((long)param_3 + 9) = bVar10;
      if (((uVar7 != 0) && (uVar3 != 0)) && (0xfd < (byte)(bVar9 - 5))) {
        if (1 < bVar10) {
          return (void *)0x0;
        }
        if ((uVar13 >> 0x18 | (uVar13 & 0xff0000) >> 8 | (uVar13 & 0xff00) << 8 | uVar13 << 0x18) !=
            0x716f6966) {
          return (void *)0x0;
        }
        if (uVar3 < (uint)(400000000 / (ulong)uVar7)) {
          uVar13 = (uint)bVar9;
          if (param_4 != 0) {
            uVar13 = param_4;
          }
          iVar4 = uVar3 * uVar7 * uVar13;
          pvVar1 = malloc((long)iVar4);
          if (pvVar1 != (void *)0x0) {
            local_138[0xf0] = 0;
            local_138[0xf1] = 0;
            local_138[0xf2] = 0;
            local_138[0xf3] = 0;
            local_138[0xf4] = 0;
            local_138[0xf5] = 0;
            local_138[0xf6] = 0;
            local_138[0xf7] = 0;
            local_138[0xf8] = 0;
            local_138[0xf9] = 0;
            local_138[0xfa] = 0;
            local_138[0xfb] = 0;
            local_138[0xfc] = 0;
            local_138[0xfd] = 0;
            local_138[0xfe] = 0;
            local_138[0xff] = 0;
            local_138[0xe0] = 0;
            local_138[0xe1] = 0;
            local_138[0xe2] = 0;
            local_138[0xe3] = 0;
            local_138[0xe4] = 0;
            local_138[0xe5] = 0;
            local_138[0xe6] = 0;
            local_138[0xe7] = 0;
            local_138[0xe8] = 0;
            local_138[0xe9] = 0;
            local_138[0xea] = 0;
            local_138[0xeb] = 0;
            local_138[0xec] = 0;
            local_138[0xed] = 0;
            local_138[0xee] = 0;
            local_138[0xef] = 0;
            local_138[0xd0] = 0;
            local_138[0xd1] = 0;
            local_138[0xd2] = 0;
            local_138[0xd3] = 0;
            local_138[0xd4] = 0;
            local_138[0xd5] = 0;
            local_138[0xd6] = 0;
            local_138[0xd7] = 0;
            local_138[0xd8] = 0;
            local_138[0xd9] = 0;
            local_138[0xda] = 0;
            local_138[0xdb] = 0;
            local_138[0xdc] = 0;
            local_138[0xdd] = 0;
            local_138[0xde] = 0;
            local_138[0xdf] = 0;
            local_138[0xc0] = 0;
            local_138[0xc1] = 0;
            local_138[0xc2] = 0;
            local_138[0xc3] = 0;
            local_138[0xc4] = 0;
            local_138[0xc5] = 0;
            local_138[0xc6] = 0;
            local_138[199] = 0;
            local_138[200] = 0;
            local_138[0xc9] = 0;
            local_138[0xca] = 0;
            local_138[0xcb] = 0;
            local_138[0xcc] = 0;
            local_138[0xcd] = 0;
            local_138[0xce] = 0;
            local_138[0xcf] = 0;
            local_138[0xb0] = 0;
            local_138[0xb1] = 0;
            local_138[0xb2] = 0;
            local_138[0xb3] = 0;
            local_138[0xb4] = 0;
            local_138[0xb5] = 0;
            local_138[0xb6] = 0;
            local_138[0xb7] = 0;
            local_138[0xb8] = 0;
            local_138[0xb9] = 0;
            local_138[0xba] = 0;
            local_138[0xbb] = 0;
            local_138[0xbc] = 0;
            local_138[0xbd] = 0;
            local_138[0xbe] = 0;
            local_138[0xbf] = 0;
            local_138[0xa0] = 0;
            local_138[0xa1] = 0;
            local_138[0xa2] = 0;
            local_138[0xa3] = 0;
            local_138[0xa4] = 0;
            local_138[0xa5] = 0;
            local_138[0xa6] = 0;
            local_138[0xa7] = 0;
            local_138[0xa8] = 0;
            local_138[0xa9] = 0;
            local_138[0xaa] = 0;
            local_138[0xab] = 0;
            local_138[0xac] = 0;
            local_138[0xad] = 0;
            local_138[0xae] = 0;
            local_138[0xaf] = 0;
            local_138[0x90] = 0;
            local_138[0x91] = 0;
            local_138[0x92] = 0;
            local_138[0x93] = 0;
            local_138[0x94] = 0;
            local_138[0x95] = 0;
            local_138[0x96] = 0;
            local_138[0x97] = 0;
            local_138[0x98] = 0;
            local_138[0x99] = 0;
            local_138[0x9a] = 0;
            local_138[0x9b] = 0;
            local_138[0x9c] = 0;
            local_138[0x9d] = 0;
            local_138[0x9e] = 0;
            local_138[0x9f] = 0;
            local_138[0x80] = 0;
            local_138[0x81] = 0;
            local_138[0x82] = 0;
            local_138[0x83] = 0;
            local_138[0x84] = 0;
            local_138[0x85] = 0;
            local_138[0x86] = 0;
            local_138[0x87] = 0;
            local_138[0x88] = 0;
            local_138[0x89] = 0;
            local_138[0x8a] = 0;
            local_138[0x8b] = 0;
            local_138[0x8c] = 0;
            local_138[0x8d] = 0;
            local_138[0x8e] = 0;
            local_138[0x8f] = 0;
            local_138[0x70] = 0;
            local_138[0x71] = 0;
            local_138[0x72] = 0;
            local_138[0x73] = 0;
            local_138[0x74] = 0;
            local_138[0x75] = 0;
            local_138[0x76] = 0;
            local_138[0x77] = 0;
            local_138[0x78] = 0;
            local_138[0x79] = 0;
            local_138[0x7a] = 0;
            local_138[0x7b] = 0;
            local_138[0x7c] = 0;
            local_138[0x7d] = 0;
            local_138[0x7e] = 0;
            local_138[0x7f] = 0;
            local_138[0x60] = 0;
            local_138[0x61] = 0;
            local_138[0x62] = 0;
            local_138[99] = 0;
            local_138[100] = 0;
            local_138[0x65] = 0;
            local_138[0x66] = 0;
            local_138[0x67] = 0;
            local_138[0x68] = 0;
            local_138[0x69] = 0;
            local_138[0x6a] = 0;
            local_138[0x6b] = 0;
            local_138[0x6c] = 0;
            local_138[0x6d] = 0;
            local_138[0x6e] = 0;
            local_138[0x6f] = 0;
            local_138[0x50] = 0;
            local_138[0x51] = 0;
            local_138[0x52] = 0;
            local_138[0x53] = 0;
            local_138[0x54] = 0;
            local_138[0x55] = 0;
            local_138[0x56] = 0;
            local_138[0x57] = 0;
            local_138[0x58] = 0;
            local_138[0x59] = 0;
            local_138[0x5a] = 0;
            local_138[0x5b] = 0;
            local_138[0x5c] = 0;
            local_138[0x5d] = 0;
            local_138[0x5e] = 0;
            local_138[0x5f] = 0;
            local_138[0x40] = 0;
            local_138[0x41] = 0;
            local_138[0x42] = 0;
            local_138[0x43] = 0;
            local_138[0x44] = 0;
            local_138[0x45] = 0;
            local_138[0x46] = 0;
            local_138[0x47] = 0;
            local_138[0x48] = 0;
            local_138[0x49] = 0;
            local_138[0x4a] = 0;
            local_138[0x4b] = 0;
            local_138[0x4c] = 0;
            local_138[0x4d] = 0;
            local_138[0x4e] = 0;
            local_138[0x4f] = 0;
            local_138[0x30] = 0;
            local_138[0x31] = 0;
            local_138[0x32] = 0;
            local_138[0x33] = 0;
            local_138[0x34] = 0;
            local_138[0x35] = 0;
            local_138[0x36] = 0;
            local_138[0x37] = 0;
            local_138[0x38] = 0;
            local_138[0x39] = 0;
            local_138[0x3a] = 0;
            local_138[0x3b] = 0;
            local_138[0x3c] = 0;
            local_138[0x3d] = 0;
            local_138[0x3e] = 0;
            local_138[0x3f] = 0;
            local_138[0x20] = 0;
            local_138[0x21] = 0;
            local_138[0x22] = 0;
            local_138[0x23] = 0;
            local_138[0x24] = 0;
            local_138[0x25] = 0;
            local_138[0x26] = 0;
            local_138[0x27] = 0;
            local_138[0x28] = 0;
            local_138[0x29] = 0;
            local_138[0x2a] = 0;
            local_138[0x2b] = 0;
            local_138[0x2c] = 0;
            local_138[0x2d] = 0;
            local_138[0x2e] = 0;
            local_138[0x2f] = 0;
            local_138[0x10] = 0;
            local_138[0x11] = 0;
            local_138[0x12] = 0;
            local_138[0x13] = 0;
            local_138[0x14] = 0;
            local_138[0x15] = 0;
            local_138[0x16] = 0;
            local_138[0x17] = 0;
            local_138[0x18] = 0;
            local_138[0x19] = 0;
            local_138[0x1a] = 0;
            local_138[0x1b] = 0;
            local_138[0x1c] = 0;
            local_138[0x1d] = 0;
            local_138[0x1e] = 0;
            local_138[0x1f] = 0;
            local_138[0] = 0;
            local_138[1] = 0;
            local_138[2] = 0;
            local_138[3] = 0;
            local_138[4] = 0;
            local_138[5] = 0;
            local_138[6] = 0;
            local_138[7] = 0;
            local_138[8] = 0;
            local_138[9] = 0;
            local_138[10] = 0;
            local_138[0xb] = 0;
            local_138[0xc] = 0;
            local_138[0xd] = 0;
            local_138[0xe] = 0;
            local_138[0xf] = 0;
            if (iVar4 < 1) {
              return pvVar1;
            }
            iVar2 = 0xe;
            uVar3 = 0;
            bVar6 = 0xff;
            iVar5 = 0;
            bVar11 = 0;
            bVar10 = 0;
            bVar9 = 0;
            do {
              if ((int)uVar3 < 1) {
                uVar3 = 0;
                if (iVar2 < param_2 + -8) {
                  lVar12 = (long)iVar2;
                  local_150 = lVar12 + 1;
                  bVar14 = *(byte *)((long)param_1 + lVar12);
                  uVar8 = (ulong)bVar14;
                  if (bVar14 == 0xff) {
                    bVar9 = *(byte *)((long)param_1 + local_150);
                    bVar10 = *(byte *)((long)param_1 + lVar12 + 2);
                    bVar11 = *(byte *)((long)param_1 + lVar12 + 3);
                    uVar7 = iVar2 + 5;
                    bVar6 = *(byte *)((long)param_1 + lVar12 + 4);
LAB_00102aad:
                    uVar3 = 0;
                    local_150 = (ulong)uVar7;
                  }
                  else {
                    if (bVar14 == 0xfe) {
                      bVar9 = *(byte *)((long)param_1 + local_150);
                      bVar10 = *(byte *)((long)param_1 + lVar12 + 2);
                      bVar11 = *(byte *)((long)param_1 + lVar12 + 3);
                      uVar7 = iVar2 + 4;
                      goto LAB_00102aad;
                    }
                    switch(bVar14) {
                    default:
                      bVar9 = local_138[uVar8 * 4];
                      bVar10 = local_138[uVar8 * 4 + 1];
                      bVar11 = local_138[uVar8 * 4 + 2];
                      bVar6 = local_138[uVar8 * 4 + 3];
                      break;
                    case 0x40:
                    case 0x41:
                    case 0x42:
                    case 0x43:
                    case 0x44:
                    case 0x45:
                    case 0x46:
                    case 0x47:
                    case 0x48:
                    case 0x49:
                    case 0x4a:
                    case 0x4b:
                    case 0x4c:
                    case 0x4d:
                    case 0x4e:
                    case 0x4f:
                    case 0x50:
                    case 0x51:
                    case 0x52:
                    case 0x53:
                    case 0x54:
                    case 0x55:
                    case 0x56:
                    case 0x57:
                    case 0x58:
                    case 0x59:
                    case 0x5a:
                    case 0x5b:
                    case 0x5c:
                    case 0x5d:
                    case 0x5e:
                    case 0x5f:
                    case 0x60:
                    case 0x61:
                    case 0x62:
                    case 99:
                    case 100:
                    case 0x65:
                    case 0x66:
                    case 0x67:
                    case 0x68:
                    case 0x69:
                    case 0x6a:
                    case 0x6b:
                    case 0x6c:
                    case 0x6d:
                    case 0x6e:
                    case 0x6f:
                    case 0x70:
                    case 0x71:
                    case 0x72:
                    case 0x73:
                    case 0x74:
                    case 0x75:
                    case 0x76:
                    case 0x77:
                    case 0x78:
                    case 0x79:
                    case 0x7a:
                    case 0x7b:
                    case 0x7c:
                    case 0x7d:
                    case 0x7e:
                    case 0x7f:
                      bVar9 = (bVar9 + (bVar14 >> 4 & 3)) - 2;
                      bVar10 = (bVar10 + (bVar14 >> 2 & 3)) - 2;
                      bVar11 = (bVar11 + (bVar14 & 3)) - 2;
                      break;
                    case 0x80:
                    case 0x81:
                    case 0x82:
                    case 0x83:
                    case 0x84:
                    case 0x85:
                    case 0x86:
                    case 0x87:
                    case 0x88:
                    case 0x89:
                    case 0x8a:
                    case 0x8b:
                    case 0x8c:
                    case 0x8d:
                    case 0x8e:
                    case 0x8f:
                    case 0x90:
                    case 0x91:
                    case 0x92:
                    case 0x93:
                    case 0x94:
                    case 0x95:
                    case 0x96:
                    case 0x97:
                    case 0x98:
                    case 0x99:
                    case 0x9a:
                    case 0x9b:
                    case 0x9c:
                    case 0x9d:
                    case 0x9e:
                    case 0x9f:
                    case 0xa0:
                    case 0xa1:
                    case 0xa2:
                    case 0xa3:
                    case 0xa4:
                    case 0xa5:
                    case 0xa6:
                    case 0xa7:
                    case 0xa8:
                    case 0xa9:
                    case 0xaa:
                    case 0xab:
                    case 0xac:
                    case 0xad:
                    case 0xae:
                    case 0xaf:
                    case 0xb0:
                    case 0xb1:
                    case 0xb2:
                    case 0xb3:
                    case 0xb4:
                    case 0xb5:
                    case 0xb6:
                    case 0xb7:
                    case 0xb8:
                    case 0xb9:
                    case 0xba:
                    case 0xbb:
                    case 0xbc:
                    case 0xbd:
                    case 0xbe:
                    case 0xbf:
                      uVar7 = iVar2 + 2;
                      bVar14 = bVar14 & 0x3f;
                      bVar9 = bVar9 + (*(byte *)((long)param_1 + local_150) >> 4) + bVar14 + -0x28;
                      bVar10 = (bVar10 + bVar14) - 0x20;
                      bVar11 = bVar11 + bVar14 + (*(byte *)((long)param_1 + local_150) & 0xf) +
                                        -0x28;
                      goto LAB_00102aad;
                    case 0xc0:
                    case 0xc1:
                    case 0xc2:
                    case 0xc3:
                    case 0xc4:
                    case 0xc5:
                    case 0xc6:
                    case 199:
                    case 200:
                    case 0xc9:
                    case 0xca:
                    case 0xcb:
                    case 0xcc:
                    case 0xcd:
                    case 0xce:
                    case 0xcf:
                    case 0xd0:
                    case 0xd1:
                    case 0xd2:
                    case 0xd3:
                    case 0xd4:
                    case 0xd5:
                    case 0xd6:
                    case 0xd7:
                    case 0xd8:
                    case 0xd9:
                    case 0xda:
                    case 0xdb:
                    case 0xdc:
                    case 0xdd:
                    case 0xde:
                    case 0xdf:
                    case 0xe0:
                    case 0xe1:
                    case 0xe2:
                    case 0xe3:
                    case 0xe4:
                    case 0xe5:
                    case 0xe6:
                    case 0xe7:
                    case 0xe8:
                    case 0xe9:
                    case 0xea:
                    case 0xeb:
                    case 0xec:
                    case 0xed:
                    case 0xee:
                    case 0xef:
                    case 0xf0:
                    case 0xf1:
                    case 0xf2:
                    case 0xf3:
                    case 0xf4:
                    case 0xf5:
                    case 0xf6:
                    case 0xf7:
                    case 0xf8:
                    case 0xf9:
                    case 0xfa:
                    case 0xfb:
                    case 0xfc:
                    case 0xfd:
                      uVar3 = bVar14 & 0x3f;
                      goto LAB_00102b64;
                    }
                    uVar3 = 0;
                  }
LAB_00102b64:
                  uVar8 = (ulong)((uint)bVar6 * 0xb +
                                  (uint)bVar10 + (uint)bVar10 * 4 + (uint)bVar9 + (uint)bVar9 * 2 +
                                  (uint)bVar11 * 7 & 0x3f);
                  local_138[uVar8 * 4] = bVar9;
                  local_138[uVar8 * 4 + 1] = bVar10;
                  local_138[uVar8 * 4 + 2] = bVar11;
                  local_138[uVar8 * 4 + 3] = bVar6;
                  iVar2 = (int)local_150;
                }
              }
              else {
                uVar3 = uVar3 - 1;
              }
              *(byte *)((long)pvVar1 + (long)iVar5) = bVar9;
              *(byte *)((long)pvVar1 + (long)iVar5 + 1) = bVar10;
              *(byte *)((long)pvVar1 + (long)(iVar5 + 2)) = bVar11;
              if (uVar13 == 4) {
                *(byte *)((long)pvVar1 + (long)(iVar5 + 3)) = bVar6;
              }
              iVar5 = iVar5 + uVar13;
              if (iVar4 <= iVar5) {
                return pvVar1;
              }
            } while( true );
          }
        }
      }
    }
  }
  return (void *)0x0;
}

