
undefined4 * qoi_encode(long param_1,uint *param_2,int *param_3)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  undefined4 *puVar5;
  char cVar6;
  byte bVar7;
  int iVar8;
  byte bVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  byte bVar14;
  char cVar15;
  ulong uVar16;
  int iVar17;
  long lVar18;
  int iVar19;
  int iVar20;
  char cVar21;
  uint uVar22;
  uint uVar23;
  undefined4 local_138;
  undefined8 uStack_130;
  undefined8 local_128;
  undefined8 uStack_120;
  undefined8 local_118;
  undefined8 uStack_110;
  undefined8 local_108;
  undefined8 uStack_100;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined8 uStack_40;
  
  if ((((param_2 != (uint *)0x0) && (param_1 != 0)) && (param_3 != (int *)0x0)) &&
     ((uVar22 = *param_2, uVar22 != 0 && (uVar23 = param_2[1], uVar23 != 0)))) {
    bVar1 = (byte)param_2[2];
    if ((0xfd < (byte)(bVar1 - 5)) &&
       ((bVar7 = *(byte *)((long)param_2 + 9), bVar7 < 2 &&
        (uVar23 < (uint)(400000000 / (ulong)uVar22))))) {
      puVar5 = malloc((long)(int)((bVar1 + 1) * uVar23 * uVar22 + 0x16));
      if (puVar5 != (undefined4 *)0x0) {
        *puVar5 = 0x66696f71;
        *(char *)(puVar5 + 1) = (char)(uVar22 >> 0x18);
        *(char *)((long)puVar5 + 5) = (char)(uVar22 >> 0x10);
        *(char *)((long)puVar5 + 6) = (char)(uVar22 >> 8);
        *(char *)((long)puVar5 + 7) = (char)uVar22;
        *(char *)(puVar5 + 2) = (char)(uVar23 >> 0x18);
        *(char *)((long)puVar5 + 9) = (char)(uVar23 >> 0x10);
        *(char *)((long)puVar5 + 10) = (char)(uVar23 >> 8);
        *(char *)((long)puVar5 + 0xb) = (char)uVar23;
        *(byte *)(puVar5 + 3) = bVar1;
        *(byte *)((long)puVar5 + 0xd) = bVar7;
        local_48 = 0;
        uStack_40 = 0;
        local_58 = 0;
        uStack_50 = 0;
        local_68 = 0;
        uStack_60 = 0;
        local_78 = 0;
        uStack_70 = 0;
        local_88 = 0;
        uStack_80 = 0;
        local_98 = 0;
        uStack_90 = 0;
        local_a8 = 0;
        uStack_a0 = 0;
        local_b8 = 0;
        uStack_b0 = 0;
        local_c8 = 0;
        uStack_c0 = 0;
        local_d8 = 0;
        uStack_d0 = 0;
        local_e8 = 0;
        uStack_e0 = 0;
        local_f8 = 0;
        uStack_f0 = 0;
        local_108 = 0;
        uStack_100 = 0;
        local_118 = 0;
        uStack_110 = 0;
        local_128 = 0;
        uStack_120 = 0;
        _local_138 = 0;
        uStack_130 = 0;
        iVar19 = uVar23 * uVar22 * (uint)bVar1;
        if (iVar19 < 1) {
          iVar20 = 0xe;
        }
        else {
          iVar20 = 0xe;
          iVar8 = 0;
          iVar13 = 0;
          uVar23 = 0;
          bVar7 = 0;
          bVar9 = 0;
          uVar22 = 0xff;
          do {
            uVar11 = uVar22;
            if (bVar1 == 4) {
              uVar11 = (uint)*(byte *)(param_1 + (iVar13 + 3));
            }
            bVar2 = *(byte *)(param_1 + iVar13);
            bVar3 = *(byte *)(param_1 + 1 + (long)iVar13);
            bVar4 = *(byte *)(param_1 + (iVar13 + 2));
            uVar12 = (uint)bVar3 << 8 | (uint)bVar4 << 0x10 | uVar11 << 0x18 | (uint)bVar2;
            bVar14 = (byte)iVar8;
            if (uVar12 == ((uint)bVar7 | (uint)bVar9 << 8 | uVar23 << 0x10 | uVar22 << 0x18)) {
              if ((iVar19 - (uint)bVar1 == iVar13) || (iVar8 = iVar8 + 1, iVar8 == 0x3e)) {
                uVar16 = (ulong)(bVar14 | 0xc0);
                iVar10 = iVar20 + 1;
                iVar8 = 0;
                iVar17 = iVar20;
                goto LAB_001025c4;
              }
            }
            else {
              if (0 < iVar8) {
                lVar18 = (long)iVar20;
                iVar20 = iVar20 + 1;
                *(byte *)((long)puVar5 + lVar18) = bVar14 - 1 | 0xc0;
                iVar8 = 0;
              }
              uVar16 = (ulong)(uVar11 * 0xb +
                               (((uint)bVar3 * 5 + (uint)bVar2 + (uint)bVar2 * 2 + (uint)bVar4 * 8)
                               - (uint)bVar4) & 0x3f);
              iVar17 = iVar20;
              if ((&local_138)[uVar16] == uVar12) {
                iVar10 = iVar20 + 1;
              }
              else {
                *(byte *)(&local_138 + uVar16) = bVar2;
                *(byte *)((long)&local_138 + uVar16 * 4 + 1) = bVar3;
                *(byte *)((long)&local_138 + uVar16 * 4 + 2) = bVar4;
                *(char *)((long)&local_138 + uVar16 * 4 + 3) = (char)uVar11;
                if ((char)uVar11 == (char)uVar22) {
                  cVar21 = bVar2 - bVar7;
                  cVar15 = bVar3 - bVar9;
                  cVar6 = bVar4 - (char)uVar23;
                  if ((((byte)(cVar21 + 2U) < 4) && ((byte)(cVar15 + 2U) < 4)) &&
                     (bVar7 = cVar6 + 2, bVar7 < 4)) {
                    uVar16 = (ulong)(byte)(cVar15 * '\x04' + 8U | cVar21 * '\x10' + 0x20U | bVar7 |
                                          0x40);
                    iVar10 = iVar20 + 1;
                  }
                  else if ((((byte)((cVar21 - cVar15) + 8U) < 0x10) &&
                           ((byte)(cVar15 + 0x20U) < 0x40)) &&
                          (bVar7 = (cVar6 - cVar15) + 8, bVar7 < 0x10)) {
                    iVar17 = iVar20 + 1;
                    *(byte *)((long)puVar5 + (long)iVar20) = cVar15 + 0x20U | 0x80;
                    iVar10 = iVar20 + 2;
                    uVar16 = (ulong)(byte)((bVar7 | (cVar21 - cVar15) * '\x10') + 0x80);
                  }
                  else {
                    *(undefined1 *)((long)puVar5 + (long)iVar20) = 0xfe;
                    *(byte *)((long)puVar5 + (long)(iVar20 + 1)) = bVar2;
                    iVar17 = iVar20 + 3;
                    *(byte *)((long)puVar5 + (long)(iVar20 + 2)) = bVar3;
                    iVar10 = iVar20 + 4;
                    uVar16 = (ulong)bVar4;
                  }
                }
                else {
                  *(undefined1 *)((long)puVar5 + (long)iVar20) = 0xff;
                  *(byte *)((long)puVar5 + (long)(iVar20 + 1)) = bVar2;
                  *(byte *)((long)puVar5 + (long)(iVar20 + 2)) = bVar3;
                  iVar17 = iVar20 + 4;
                  *(byte *)((long)puVar5 + (long)(iVar20 + 3)) = bVar4;
                  iVar10 = iVar20 + 5;
                  uVar16 = (ulong)uVar11;
                }
              }
LAB_001025c4:
              *(char *)((long)puVar5 + (long)iVar17) = (char)uVar16;
              iVar20 = iVar10;
            }
            uVar23 = (uint)bVar4;
            iVar13 = iVar13 + (uint)bVar1;
            bVar7 = bVar2;
            bVar9 = bVar3;
            uVar22 = uVar11;
          } while (iVar13 < iVar19);
        }
        *(undefined1 *)((long)puVar5 + (long)iVar20) = 0;
        *(undefined4 *)((long)puVar5 + (long)(iVar20 + 1)) = 0;
        *(undefined2 *)((long)puVar5 + (long)(iVar20 + 5)) = 0;
        *(undefined1 *)((long)puVar5 + (long)(iVar20 + 7)) = 1;
        *param_3 = iVar20 + 8;
        return puVar5;
      }
    }
  }
  return (undefined4 *)0x0;
}

