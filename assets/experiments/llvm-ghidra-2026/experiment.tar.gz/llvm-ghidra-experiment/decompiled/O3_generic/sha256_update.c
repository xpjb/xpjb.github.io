
void sha256_update(long param_1,long param_2,ulong param_3)

{
  bool bVar1;
  uint uVar2;
  ulong uVar3;
  ulong uVar4;
  
  if (param_3 != 0) {
    uVar2 = *(uint *)(param_1 + 0x40);
    uVar3 = 0;
    uVar4 = 1;
    do {
      *(undefined1 *)(param_1 + (ulong)uVar2) = *(undefined1 *)(param_2 + uVar3);
      uVar2 = *(int *)(param_1 + 0x40) + 1;
      *(uint *)(param_1 + 0x40) = uVar2;
      if (uVar2 == 0x40) {
        sha256_transform(param_1,param_1);
        *(long *)(param_1 + 0x48) = *(long *)(param_1 + 0x48) + 0x200;
        *(undefined4 *)(param_1 + 0x40) = 0;
        uVar2 = 0;
      }
      bVar1 = uVar4 < param_3;
      uVar3 = uVar4;
      uVar4 = (ulong)((int)uVar4 + 1);
    } while (bVar1);
  }
  return;
}

