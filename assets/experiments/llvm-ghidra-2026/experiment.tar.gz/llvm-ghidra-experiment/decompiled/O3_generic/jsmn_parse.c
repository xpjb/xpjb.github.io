
uint jsmn_parse(uint *param_1,long param_2,ulong param_3,long param_4,uint param_5)

{
  uint uVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  bool bVar5;
  uint uVar6;
  ulong uVar7;
  long lVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  ulong uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  long lVar16;
  
  uVar6 = *param_1;
  uVar10 = param_1[1];
joined_r0x00101e04:
  uVar7 = (ulong)uVar6;
  if (param_3 <= uVar7) {
switchD_00101e80_caseD_0:
    if (param_4 == 0) {
      return uVar10;
    }
    uVar6 = param_1[1] - 1;
    if ((int)uVar6 < 0) {
      return uVar10;
    }
    piVar9 = (int *)(param_4 + (ulong)uVar6 * 0x10 + 8);
    lVar16 = (ulong)uVar6 + 1;
    while ((piVar9[-1] == -1 || (*piVar9 != -1))) {
      piVar9 = piVar9 + -4;
      lVar8 = lVar16 + -1;
      bVar5 = lVar16 < 1;
      lVar16 = lVar8;
      if (lVar8 == 0 || bVar5) {
        return uVar10;
      }
    }
    return 0xfffffffd;
  }
  cVar2 = *(char *)(param_2 + uVar7);
  uVar11 = uVar10;
  switch(cVar2) {
  case '\0':
    goto switchD_00101e80_caseD_0;
  default:
    return 0xfffffffe;
  case '\t':
  case '\n':
  case '\r':
  case ' ':
    break;
  case '\"':
    uVar15 = uVar6 + 1;
    uVar7 = (ulong)uVar15;
    *param_1 = uVar15;
    uVar13 = uVar15;
    if (uVar7 < param_3) {
      do {
        cVar2 = *(char *)(param_2 + uVar7);
        uVar14 = uVar13;
        if (cVar2 == '\\') {
          uVar1 = uVar13 + 1;
          if (uVar1 < param_3) {
            *param_1 = uVar1;
            uVar11 = 0xfffffffe;
            uVar14 = uVar1;
            switch(*(undefined1 *)(param_2 + (ulong)uVar1)) {
            case 0x22:
            case 0x2f:
            case 0x5c:
            case 0x62:
            case 0x66:
            case 0x6e:
            case 0x72:
            case 0x74:
              break;
            default:
              goto switchD_0010219a_caseD_23;
            case 0x75:
              uVar14 = uVar13 + 2;
              *param_1 = uVar14;
              if ((uVar14 < param_3) && (bVar3 = *(byte *)(param_2 + (ulong)uVar14), bVar3 != 0)) {
                if ((9 < (byte)(bVar3 - 0x30)) &&
                   ((0x25 < bVar3 - 0x41 ||
                    ((0x3f0000003fU >> ((ulong)(bVar3 - 0x41) & 0x3f) & 1) == 0))))
                goto switchD_0010219a_caseD_23;
                uVar14 = uVar13 + 3;
                *param_1 = uVar14;
                if ((uVar14 < param_3) && (bVar3 = *(byte *)(param_2 + (ulong)uVar14), bVar3 != 0))
                {
                  if ((9 < (byte)(bVar3 - 0x30)) &&
                     ((0x25 < bVar3 - 0x41 ||
                      ((0x3f0000003fU >> ((ulong)(bVar3 - 0x41) & 0x3f) & 1) == 0))))
                  goto switchD_0010219a_caseD_23;
                  uVar14 = uVar13 + 4;
                  *param_1 = uVar14;
                  if ((uVar14 < param_3) && (bVar3 = *(byte *)(param_2 + (ulong)uVar14), bVar3 != 0)
                     ) {
                    if ((9 < (byte)(bVar3 - 0x30)) &&
                       ((0x25 < bVar3 - 0x41 ||
                        ((0x3f0000003fU >> ((ulong)(bVar3 - 0x41) & 0x3f) & 1) == 0))))
                    goto switchD_0010219a_caseD_23;
                    uVar14 = uVar13 + 5;
                    *param_1 = uVar14;
                    if ((uVar14 < param_3) &&
                       (bVar3 = *(byte *)(param_2 + (ulong)uVar14), bVar3 != 0)) {
                      if ((9 < (byte)(bVar3 - 0x30)) &&
                         ((0x25 < bVar3 - 0x41 ||
                          ((0x3f0000003fU >> ((ulong)(bVar3 - 0x41) & 0x3f) & 1) == 0))))
                      goto switchD_0010219a_caseD_23;
                      uVar14 = uVar13 + 6;
                    }
                  }
                }
              }
              uVar14 = uVar14 - 1;
            }
          }
        }
        else {
          if (cVar2 == '\0') break;
          if (cVar2 == '\"') goto LAB_001022e1;
        }
        uVar13 = uVar14 + 1;
        uVar7 = (ulong)uVar13;
        *param_1 = uVar13;
        if (param_3 <= uVar7) break;
      } while( true );
    }
    uVar11 = 0xfffffffd;
    goto switchD_0010219a_caseD_23;
  case ',':
    if ((((param_4 != 0) && ((long)(int)param_1[2] != -1)) &&
        (1 < *(int *)(param_4 + (long)(int)param_1[2] * 0x10) - 1U)) &&
       (uVar6 = param_1[1] - 1, -1 < (int)uVar6)) {
      piVar9 = (int *)((ulong)uVar6 * 0x10 + param_4 + 8);
      uVar7 = (ulong)uVar6;
      do {
        if (((piVar9[-2] - 1U < 2) && (piVar9[-1] != -1)) && (*piVar9 == -1)) goto LAB_00102109;
        piVar9 = piVar9 + -4;
        bVar5 = 0 < (long)uVar7;
        uVar7 = uVar7 - 1;
      } while (bVar5);
    }
    break;
  case '-':
  case '0':
  case '1':
  case '2':
  case '3':
  case '4':
  case '5':
  case '6':
  case '7':
  case '8':
  case '9':
  case 'f':
  case 'n':
  case 't':
    if ((param_4 != 0) && ((long)(int)param_1[2] != -1)) {
      lVar16 = (long)(int)param_1[2] * 0x10;
      iVar4 = *(int *)(param_4 + lVar16);
      if (iVar4 == 4) {
        if (*(int *)(lVar16 + param_4 + 0xc) != 0) {
          return 0xfffffffe;
        }
      }
      else if (iVar4 == 1) {
        return 0xfffffffe;
      }
    }
    do {
      bVar3 = *(byte *)(param_2 + uVar7);
      uVar12 = (ulong)bVar3;
      uVar11 = 0xfffffffd;
      if (uVar12 < 0x2d) {
        if ((0x100100002600U >> (uVar12 & 0x3f) & 1) != 0) goto LAB_00101f10;
        if (uVar12 == 0) goto switchD_0010219a_caseD_23;
      }
      if ((bVar3 == 0x5d) || (bVar3 == 0x7d)) goto LAB_00101f10;
      if ((byte)(bVar3 + 0x81) < 0xa1) {
        uVar11 = 0xfffffffe;
        goto switchD_0010219a_caseD_23;
      }
      uVar13 = (int)uVar7 + 1;
      uVar7 = (ulong)uVar13;
      *param_1 = uVar13;
      if (param_3 <= uVar7) goto switchD_0010219a_caseD_23;
    } while( true );
  case ':':
switchD_00101e80_caseD_3a:
    param_1[2] = param_1[1] - 1;
    uVar11 = uVar10;
    break;
  case '[':
  case '{':
    uVar10 = uVar10 + 1;
    uVar11 = uVar10;
    if (param_4 != 0) {
      uVar6 = param_1[1];
      if (param_5 <= uVar6) {
        return 0xffffffff;
      }
      param_1[1] = uVar6 + 1;
      lVar16 = (ulong)uVar6 * 0x10;
      *(undefined8 *)(param_4 + 4 + lVar16) = 0xffffffffffffffff;
      *(undefined4 *)(param_4 + 0xc + lVar16) = 0;
      if ((long)(int)param_1[2] != -1) {
        lVar8 = (long)(int)param_1[2] * 0x10;
        if (*(int *)(param_4 + lVar8) == 1) {
          return 0xfffffffe;
        }
        piVar9 = (int *)(lVar8 + param_4 + 0xc);
        *piVar9 = *piVar9 + 1;
      }
      *(int *)(lVar16 + param_4) = (cVar2 != '{') + 1;
      ((int *)(lVar16 + param_4))[1] = *param_1;
      goto switchD_00101e80_caseD_3a;
    }
    break;
  case ']':
  case '}':
    if (param_4 != 0) {
      uVar10 = param_1[1] - 1;
      if ((int)uVar10 < 0) {
        if (param_1[1] == 0) {
          return 0xfffffffe;
        }
      }
      else {
        piVar9 = (int *)((ulong)uVar10 * 0x10 + param_4);
        uVar7 = (ulong)uVar10;
        while ((piVar9[1] == -1 || (piVar9[2] != -1))) {
          piVar9 = piVar9 + -4;
          uVar10 = uVar10 - 1;
          bVar5 = (long)uVar7 < 1;
          uVar7 = uVar7 - 1;
          if (bVar5) {
            return 0xfffffffe;
          }
        }
        if (*piVar9 != (cVar2 != '}') + 1) {
          return 0xfffffffe;
        }
        param_1[2] = 0xffffffff;
        piVar9[2] = uVar6 + 1;
        piVar9 = (int *)((ulong)uVar10 * 0x10 + param_4 + 8);
        uVar7 = uVar7 & 0xffffffff;
        do {
          if ((piVar9[-1] != -1) && (*piVar9 == -1)) goto LAB_00102109;
          piVar9 = piVar9 + -4;
          bVar5 = 0 < (long)uVar7;
          uVar7 = uVar7 - 1;
        } while (bVar5);
      }
    }
  }
  goto switchD_00101e80_caseD_9;
LAB_00101f10:
  if (param_4 == 0) {
    *param_1 = (int)uVar7 - 1;
    goto LAB_00101f80;
  }
  uVar11 = param_1[1];
  if (param_5 <= uVar11) goto LAB_0010239e;
  param_1[1] = uVar11 + 1;
  lVar16 = (ulong)uVar11 * 0x10;
  *(undefined8 *)(param_4 + 4 + lVar16) = 0xffffffffffffffff;
  *(undefined4 *)(param_4 + 0xc + lVar16) = 0;
  uVar11 = *param_1;
  *(undefined4 *)(param_4 + lVar16) = 8;
  *(uint *)(param_4 + 4 + lVar16) = uVar6;
  *(uint *)(param_4 + 8 + lVar16) = uVar11;
  *(undefined4 *)(param_4 + 0xc + lVar16) = 0;
  *param_1 = *param_1 - 1;
  uVar6 = param_1[2];
  goto joined_r0x00101f67;
LAB_00102109:
  param_1[2] = (uint)uVar7;
  goto switchD_00101e80_caseD_9;
LAB_001022e1:
  if (param_4 == 0) {
LAB_00101f80:
    uVar11 = uVar10 + 1;
    goto switchD_00101e80_caseD_9;
  }
  uVar11 = param_1[1];
  if (param_5 <= uVar11) {
LAB_0010239e:
    uVar11 = 0xffffffff;
switchD_0010219a_caseD_23:
    *param_1 = uVar6;
    return uVar11;
  }
  param_1[1] = uVar11 + 1;
  lVar16 = (ulong)uVar11 * 0x10;
  *(undefined8 *)(param_4 + 4 + lVar16) = 0xffffffffffffffff;
  *(undefined4 *)(param_4 + 0xc + lVar16) = 0;
  uVar6 = *param_1;
  *(undefined4 *)(param_4 + lVar16) = 4;
  *(uint *)(param_4 + 4 + lVar16) = uVar15;
  *(uint *)(param_4 + 8 + lVar16) = uVar6;
  *(undefined4 *)(param_4 + 0xc + lVar16) = 0;
  uVar6 = param_1[2];
joined_r0x00101f67:
  uVar11 = uVar10 + 1;
  if ((long)(int)uVar6 != -1) {
    piVar9 = (int *)(param_4 + 0xc + (long)(int)uVar6 * 0x10);
    *piVar9 = *piVar9 + 1;
    uVar11 = uVar10 + 1;
  }
switchD_00101e80_caseD_9:
  uVar6 = *param_1 + 1;
  *param_1 = uVar6;
  uVar10 = uVar11;
  goto joined_r0x00101e04;
}

