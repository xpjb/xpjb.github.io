
void sha256_transform(long param_1,uint *param_2)

{
  long lVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint auStack_178 [9];
  int local_154 [5];
  uint local_140 [68];
  
  uVar10 = *param_2;
  local_140[2] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[1];
  local_140[3] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[2];
  local_140[4] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[3];
  local_140[5] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[4];
  local_140[6] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[5];
  local_140[7] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[6];
  local_140[8] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[7];
  local_140[9] = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18
  ;
  uVar10 = param_2[8];
  local_140[10] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[9];
  local_140[0xb] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[10];
  local_140[0xc] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xb];
  local_140[0xd] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xc];
  local_140[0xe] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xd];
  local_140[0xf] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xe];
  local_140[0x10] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  uVar10 = param_2[0xf];
  local_140[0x11] =
       uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
  lVar1 = 0x10;
  do {
    uVar10 = local_140[lVar1];
    uVar9 = auStack_178[lVar1 + 1];
    local_140[lVar1 + 2] =
         (uVar10 >> 10 ^ (uVar10 << 0xd | uVar10 >> 0x13) ^ (uVar10 << 0xf | uVar10 >> 0x11)) +
         local_154[lVar1] + auStack_178[lVar1] +
         (uVar9 >> 3 ^ (uVar9 << 0xe | uVar9 >> 0x12) ^ (uVar9 << 0x19 | uVar9 >> 7));
    lVar1 = lVar1 + 1;
  } while (lVar1 != 0x40);
  lVar1 = 0;
  uVar10 = *(uint *)(param_1 + 0x50);
  uVar9 = *(uint *)(param_1 + 0x54);
  uVar11 = *(uint *)(param_1 + 0x58);
  uVar8 = *(uint *)(param_1 + 0x5c);
  uVar7 = *(uint *)(param_1 + 0x60);
  uVar6 = *(uint *)(param_1 + 100);
  uVar5 = *(uint *)(param_1 + 0x68);
  uVar12 = *(uint *)(param_1 + 0x6c);
  do {
    uVar3 = uVar5;
    uVar5 = uVar6;
    uVar6 = uVar7;
    uVar2 = uVar11;
    uVar11 = uVar9;
    uVar9 = uVar10;
    iVar4 = ((uVar5 ^ uVar3) & uVar6 ^ uVar3) + uVar12 +
            ((uVar6 << 7 | uVar6 >> 0x19) ^
            (uVar6 << 0x15 | uVar6 >> 0xb) ^ (uVar6 << 0x1a | uVar6 >> 6)) +
            *(int *)((long)&k + lVar1) + *(int *)((long)local_140 + lVar1 + 8);
    uVar7 = uVar8 + iVar4;
    uVar10 = (uVar11 & uVar2 ^ (uVar11 ^ uVar2) & uVar9) +
             ((uVar9 << 10 | uVar9 >> 0x16) ^
             (uVar9 << 0x13 | uVar9 >> 0xd) ^ (uVar9 << 0x1e | uVar9 >> 2)) + iVar4;
    lVar1 = lVar1 + 4;
    uVar8 = uVar2;
    uVar12 = uVar3;
  } while (lVar1 != 0x100);
  *(uint *)(param_1 + 0x50) = uVar10 + *(uint *)(param_1 + 0x50);
  *(uint *)(param_1 + 0x54) = uVar9 + *(uint *)(param_1 + 0x54);
  *(uint *)(param_1 + 0x58) = uVar11 + *(uint *)(param_1 + 0x58);
  *(uint *)(param_1 + 0x5c) = uVar2 + *(uint *)(param_1 + 0x5c);
  *(uint *)(param_1 + 0x60) = uVar7 + *(uint *)(param_1 + 0x60);
  *(uint *)(param_1 + 100) = uVar6 + *(uint *)(param_1 + 100);
  *(uint *)(param_1 + 0x68) = uVar5 + *(uint *)(param_1 + 0x68);
  *(uint *)(param_1 + 0x6c) = uVar3 + *(uint *)(param_1 + 0x6c);
  return;
}

