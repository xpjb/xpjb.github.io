
void sha256_transform(long param_1,undefined1 (*param_2) [32])

{
  undefined1 auVar1 [16];
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  uint uVar5;
  uint uVar6;
  long lVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  undefined1 auVar19 [16];
  undefined1 auVar20 [32];
  undefined1 auVar21 [32];
  undefined1 auVar22 [32];
  undefined1 auVar23 [16];
  undefined1 auVar24 [16];
  undefined1 local_138 [32];
  undefined1 local_118 [32];
  uint auStack_f8 [50];
  
  auVar1 = *(undefined1 (*) [16])*param_2;
  auVar2 = *(undefined1 (*) [16])(*param_2 + 0x10);
  lVar7 = 0;
  auVar19 = SUB6416(ZEXT464(0xd090501),0);
  auVar3 = vpshufb_avx(auVar2,auVar19);
  auVar4 = vpshufb_avx(auVar1,auVar19);
  auVar3 = vpunpckldq_avx(auVar4,auVar3);
  auVar20 = vpmovzxbd_avx2(auVar3);
  auVar22 = vpslld_avx2(auVar20,0x10);
  auVar23 = SUB6416(ZEXT464(0xe0a0602),0);
  auVar3 = vpshufb_avx(auVar2,auVar23);
  auVar4 = vpshufb_avx(auVar1,auVar23);
  auVar24 = SUB6416(ZEXT464(0xf0b0703),0);
  auVar2 = vpshufb_avx(auVar2,auVar24);
  auVar1 = vpshufb_avx(auVar1,auVar24);
  auVar1 = vpunpckldq_avx(auVar1,auVar2);
  auVar2 = vpunpckldq_avx(auVar4,auVar3);
  auVar20 = vpmovzxbd_avx2(auVar1);
  auVar21 = vpslld_avx2(*param_2,0x18);
  auVar22 = vpor_avx2(auVar22,auVar21);
  auVar21 = vpmovzxbd_avx2(auVar2);
  auVar21 = vpslld_avx2(auVar21,8);
  auVar20 = vpor_avx2(auVar21,auVar20);
  local_138 = vpor_avx2(auVar22,auVar20);
  auVar1 = *(undefined1 (*) [16])(param_2[1] + 0x10);
  auVar2 = *(undefined1 (*) [16])param_2[1];
  auVar3 = vpshufb_avx(auVar1,auVar19);
  auVar4 = vpshufb_avx(auVar2,auVar19);
  auVar19 = vpunpckldq_avx(auVar4,auVar3);
  auVar3 = vpshufb_avx(auVar1,auVar23);
  auVar4 = vpshufb_avx(auVar2,auVar23);
  auVar1 = vpshufb_avx(auVar1,auVar24);
  auVar2 = vpshufb_avx(auVar2,auVar24);
  auVar1 = vpunpckldq_avx(auVar2,auVar1);
  auVar20 = vpmovzxbd_avx2(auVar19);
  auVar2 = vpunpckldq_avx(auVar4,auVar3);
  auVar21 = vpmovzxbd_avx2(auVar1);
  auVar20 = vpslld_avx2(auVar20,0x10);
  auVar22 = vpslld_avx2(param_2[1],0x18);
  auVar22 = vpor_avx2(auVar20,auVar22);
  auVar20 = vpmovzxbd_avx2(auVar2);
  auVar20 = vpslld_avx2(auVar20,8);
  auVar20 = vpor_avx2(auVar20,auVar21);
  local_118 = vpor_avx2(auVar22,auVar20);
  do {
    uVar6 = *(uint *)(local_118 + lVar7 * 4 + 0x18);
    uVar10 = *(uint *)(local_138 + lVar7 * 4 + 4);
    uVar18 = *(uint *)(local_138 + lVar7 * 4 + 8);
    uVar8 = (uVar6 >> 10 ^ (uVar6 >> 0x13 | uVar6 << 0xd) ^ (uVar6 >> 0x11 | uVar6 << 0xf)) +
            *(int *)(local_118 + lVar7 * 4 + 4) + *(int *)(local_138 + lVar7 * 4) +
            (uVar10 >> 3 ^ (uVar10 >> 0x12 | uVar10 << 0xe) ^ (uVar10 >> 7 | uVar10 << 0x19));
    auStack_f8[lVar7] = uVar8;
    uVar6 = *(uint *)(local_118 + lVar7 * 4 + 0x1c);
    uVar12 = (uVar18 >> 3 ^ (uVar18 >> 0x12 | uVar18 << 0xe) ^ (uVar18 >> 7 | uVar18 << 0x19)) +
             uVar10 + (uVar6 >> 10 ^ (uVar6 >> 0x13 | uVar6 << 0xd) ^ (uVar6 >> 0x11 | uVar6 << 0xf)
                      ) + *(int *)(local_118 + lVar7 * 4 + 8);
    auStack_f8[lVar7 + 1] = uVar12;
    uVar6 = *(uint *)(local_138 + lVar7 * 4 + 0xc);
    auStack_f8[lVar7 + 2] =
         (uVar6 >> 3 ^ (uVar6 >> 0x12 | uVar6 << 0xe) ^ (uVar6 >> 7 | uVar6 << 0x19)) + uVar18 +
         (uVar8 >> 10 ^ (uVar8 >> 0x13 | uVar8 * 0x2000) ^ (uVar8 >> 0x11 | uVar8 * 0x8000)) +
         *(int *)(local_118 + lVar7 * 4 + 0xc);
    uVar10 = *(uint *)(local_138 + lVar7 * 4 + 0x10);
    auStack_f8[lVar7 + 3] =
         (uVar10 >> 3 ^ (uVar10 >> 0x12 | uVar10 << 0xe) ^ (uVar10 >> 7 | uVar10 << 0x19)) + uVar6 +
         (uVar12 >> 10 ^ (uVar12 >> 0x13 | uVar12 * 0x2000) ^ (uVar12 >> 0x11 | uVar12 * 0x8000)) +
         *(int *)(local_118 + lVar7 * 4 + 0x10);
    lVar7 = lVar7 + 4;
  } while (lVar7 != 0x30);
  lVar7 = 0;
  uVar6 = *(uint *)(param_1 + 0x50);
  uVar10 = *(uint *)(param_1 + 0x54);
  uVar18 = *(uint *)(param_1 + 0x58);
  uVar8 = *(uint *)(param_1 + 0x5c);
  uVar12 = *(uint *)(param_1 + 0x60);
  uVar15 = *(uint *)(param_1 + 100);
  uVar13 = *(uint *)(param_1 + 0x68);
  uVar11 = *(uint *)(param_1 + 0x6c);
  do {
    uVar14 = uVar15;
    uVar17 = uVar12;
    uVar9 = uVar10;
    uVar5 = uVar6;
    iVar16 = (~uVar17 & uVar13 | uVar14 & uVar17) + uVar11 +
             ((uVar17 >> 0x19 | uVar17 << 7) ^
             (uVar17 >> 0xb | uVar17 << 0x15) ^ (uVar17 >> 6 | uVar17 << 0x1a)) + (&k)[lVar7] +
             *(int *)(local_138 + lVar7 * 4);
    uVar15 = uVar8 + iVar16;
    uVar10 = (uVar9 & uVar18 ^ (uVar9 ^ uVar18) & uVar5) +
             ((uVar5 >> 0x16 | uVar5 << 10) ^
             (uVar5 >> 0xd | uVar5 << 0x13) ^ (uVar5 >> 2 | uVar5 << 0x1e)) + iVar16;
    iVar16 = (~uVar15 & uVar14 | uVar17 & uVar15) + uVar13 +
             ((uVar15 >> 0x19 | uVar15 * 0x80) ^
             (uVar15 >> 0xb | uVar15 * 0x200000) ^ (uVar15 >> 6 | uVar15 * 0x4000000)) +
             (&DAT_00100a34)[lVar7] + *(int *)(local_138 + lVar7 * 4 + 4);
    lVar7 = lVar7 + 2;
    uVar12 = uVar18 + iVar16;
    uVar6 = (uVar5 & uVar9 ^ (uVar5 ^ uVar9) & uVar10) +
            ((uVar10 >> 0x16 | uVar10 * 0x400) ^
            (uVar10 >> 0xd | uVar10 * 0x80000) ^ (uVar10 >> 2 | uVar10 * 0x40000000)) + iVar16;
    uVar18 = uVar5;
    uVar8 = uVar9;
    uVar13 = uVar17;
    uVar11 = uVar14;
  } while (lVar7 != 0x40);
  *(uint *)(param_1 + 0x50) = uVar6 + *(int *)(param_1 + 0x50);
  *(undefined4 *)(param_1 + 0x54) = *(undefined4 *)(param_1 + 0x54);
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_1 + 0x58);
  *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_1 + 0x5c);
  *(uint *)(param_1 + 0x60) = uVar12 + *(int *)(param_1 + 0x60);
  *(undefined4 *)(param_1 + 100) = *(undefined4 *)(param_1 + 100);
  *(undefined4 *)(param_1 + 0x68) = *(undefined4 *)(param_1 + 0x68);
  *(undefined4 *)(param_1 + 0x6c) = *(undefined4 *)(param_1 + 0x6c);
  return;
}




void sha256_init(long param_1)

{
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = 0;
  *(undefined8 *)(param_1 + 0x50) = 0xbb67ae856a09e667;
  *(undefined8 *)(param_1 + 0x58) = 0xa54ff53a3c6ef372;
  *(undefined8 *)(param_1 + 0x60) = 0x9b05688c510e527f;
  *(undefined8 *)(param_1 + 0x68) = 0x5be0cd191f83d9ab;
  return;
}




void sha256_update(long param_1,long param_2,ulong param_3)

{
  bool bVar1;
  uint uVar2;
  ulong uVar3;
  ulong uVar4;
  
  if (param_3 != 0) {
    uVar2 = *(uint *)(param_1 + 0x40);
    uVar3 = 0;
    uVar4 = 1;
    do {
      *(undefined1 *)(param_1 + (ulong)uVar2) = *(undefined1 *)(param_2 + uVar3);
      uVar2 = *(int *)(param_1 + 0x40) + 1;
      *(uint *)(param_1 + 0x40) = uVar2;
      if (uVar2 == 0x40) {
        sha256_transform(param_1,param_1);
        *(long *)(param_1 + 0x48) = *(long *)(param_1 + 0x48) + 0x200;
        uVar2 = 0;
        *(undefined4 *)(param_1 + 0x40) = 0;
      }
      bVar1 = uVar4 < param_3;
      uVar3 = uVar4;
      uVar4 = (ulong)((int)uVar4 + 1);
    } while (bVar1);
  }
  return;
}




void sha256_final(undefined1 (*param_1) [32],undefined1 *param_2)

{
  uint uVar1;
  ulong uVar2;
  long lVar3;
  
  uVar1 = *(uint *)param_1[2];
  uVar2 = (ulong)uVar1;
  (*param_1)[uVar2] = 0x80;
  if (uVar2 < 0x38) {
    if (uVar1 != 0x37) {
      memset(*param_1 + uVar2 + 1,0,0x37 - uVar2);
    }
  }
  else {
    if (uVar1 + 1 < 0x40) {
      memset(*param_1 + (uVar1 + 1),0,(ulong)(0x3e - uVar1) + 1);
    }
    sha256_transform(param_1,param_1);
    *(undefined1 (*) [32])(*param_1 + 0x18) = ZEXT1232(ZEXT812(0));
    *param_1 = ZEXT1232(ZEXT812(0));
  }
  lVar3 = (ulong)(uint)(*(int *)param_1[2] << 3) + *(long *)(param_1[2] + 8);
  *(long *)(param_1[2] + 8) = lVar3;
  param_1[1][0x1f] = (char)lVar3;
  param_1[1][0x1e] = (char)((ulong)lVar3 >> 8);
  param_1[1][0x1d] = (char)((ulong)lVar3 >> 0x10);
  param_1[1][0x1c] = (char)((ulong)lVar3 >> 0x18);
  param_1[1][0x1b] = (char)((ulong)lVar3 >> 0x20);
  param_1[1][0x1a] = (char)((ulong)lVar3 >> 0x28);
  param_1[1][0x19] = (char)((ulong)lVar3 >> 0x30);
  param_1[1][0x18] = (char)((ulong)lVar3 >> 0x38);
  sha256_transform(param_1,param_1);
  *param_2 = param_1[2][0x13];
  param_2[4] = param_1[2][0x17];
  param_2[8] = param_1[2][0x1b];
  param_2[0xc] = param_1[2][0x1f];
  param_2[0x10] = param_1[3][3];
  param_2[0x14] = param_1[3][7];
  param_2[0x18] = param_1[3][0xb];
  param_2[0x1c] = param_1[3][0xf];
  param_2[1] = param_1[2][0x12];
  param_2[5] = param_1[2][0x16];
  param_2[9] = param_1[2][0x1a];
  param_2[0xd] = param_1[2][0x1e];
  param_2[0x11] = param_1[3][2];
  param_2[0x15] = param_1[3][6];
  param_2[0x19] = param_1[3][10];
  param_2[0x1d] = param_1[3][0xe];
  param_2[2] = param_1[2][0x11];
  param_2[6] = param_1[2][0x15];
  param_2[10] = param_1[2][0x19];
  param_2[0xe] = param_1[2][0x1d];
  param_2[0x12] = param_1[3][1];
  param_2[0x16] = param_1[3][5];
  param_2[0x1a] = param_1[3][9];
  param_2[0x1e] = param_1[3][0xd];
  param_2[3] = param_1[2][0x10];
  param_2[7] = param_1[2][0x14];
  param_2[0xb] = param_1[2][0x18];
  param_2[0xf] = param_1[2][0x1c];
  param_2[0x13] = param_1[3][0];
  param_2[0x17] = param_1[3][4];
  param_2[0x1b] = param_1[3][8];
  param_2[0x1f] = param_1[3][0xc];
  return;
}



