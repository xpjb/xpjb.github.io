
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * qoi_encode(long param_1,uint *param_2,int *param_3)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  undefined1 auVar5 [16];
  undefined1 auVar6 [16];
  undefined1 auVar7 [32];
  undefined4 *puVar8;
  char cVar9;
  byte bVar10;
  int iVar11;
  int iVar12;
  byte bVar13;
  uint uVar14;
  uint uVar15;
  int iVar16;
  byte bVar17;
  char cVar18;
  int iVar19;
  ulong uVar20;
  int iVar21;
  long lVar22;
  int iVar23;
  char cVar24;
  uint uVar25;
  int iVar26;
  uint uVar27;
  undefined4 local_138;
  undefined8 uStack_130;
  undefined8 uStack_128;
  undefined8 uStack_120;
  undefined8 local_118;
  undefined8 uStack_110;
  undefined8 uStack_108;
  undefined8 uStack_100;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined8 uStack_e8;
  undefined8 uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 uStack_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 uStack_a8;
  undefined8 uStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  
  if (((((param_2 != (uint *)0x0) && (param_1 != 0)) && (param_3 != (int *)0x0)) &&
      ((uVar25 = *param_2, uVar25 != 0 && (uVar27 = param_2[1], uVar27 != 0)))) &&
     ((bVar1 = (byte)param_2[2], 0xfd < (byte)(bVar1 - 5) &&
      ((bVar10 = *(byte *)((long)param_2 + 9), bVar10 < 2 &&
       (uVar27 < (uint)(400000000 / (ulong)uVar25))))))) {
    puVar8 = malloc((long)(int)((bVar1 + 1) * uVar27 * uVar25 + 0x16));
    if (puVar8 != (undefined4 *)0x0) {
      iVar26 = uVar27 * uVar25 * (uint)bVar1;
      *puVar8 = 0x66696f71;
      auVar6 = vpshufd_avx(ZEXT416(uVar25),0x50);
      auVar7 = vpermq_avx2(ZEXT1632(auVar6),0x50);
      auVar7 = vpsrlvd_avx2(auVar7,_DAT_001009c0);
      auVar6 = vpshufb_avx(auVar7._0_16_,SUB6416(ZEXT464(0xc080400),0));
      auVar5 = vpshufb_avx(auVar7._16_16_,SUB6416(ZEXT464(0xc080400),0));
      auVar6 = vpunpckldq_avx(auVar6,auVar5);
      *(long *)(puVar8 + 1) = auVar6._0_8_;
      *(byte *)(puVar8 + 3) = bVar1;
      *(byte *)((long)puVar8 + 0xd) = bVar10;
      local_58 = 0;
      uStack_50 = 0;
      uStack_48 = 0;
      uStack_40 = 0;
      local_78 = 0;
      uStack_70 = 0;
      uStack_68 = 0;
      uStack_60 = 0;
      local_98 = 0;
      uStack_90 = 0;
      uStack_88 = 0;
      uStack_80 = 0;
      local_b8 = 0;
      uStack_b0 = 0;
      uStack_a8 = 0;
      uStack_a0 = 0;
      local_d8 = 0;
      uStack_d0 = 0;
      uStack_c8 = 0;
      uStack_c0 = 0;
      local_f8 = 0;
      uStack_f0 = 0;
      uStack_e8 = 0;
      uStack_e0 = 0;
      local_118 = 0;
      uStack_110 = 0;
      uStack_108 = 0;
      uStack_100 = 0;
      _local_138 = 0;
      uStack_130 = 0;
      uStack_128 = 0;
      uStack_120 = 0;
      if (iVar26 < 1) {
        iVar23 = 0xe;
      }
      else {
        iVar11 = 0;
        iVar16 = 0;
        uVar27 = 0;
        iVar23 = 0xe;
        bVar10 = 0;
        bVar13 = 0;
        uVar25 = 0xff;
        do {
          uVar14 = uVar25;
          if (bVar1 == 4) {
            uVar14 = (uint)*(byte *)(param_1 + (iVar16 + 3));
          }
          bVar2 = *(byte *)(param_1 + iVar16);
          bVar3 = *(byte *)(param_1 + 1 + (long)iVar16);
          bVar4 = *(byte *)(param_1 + (iVar16 + 2));
          uVar15 = (uint)bVar3 << 8 | (uint)bVar4 << 0x10 | uVar14 << 0x18 | (uint)bVar2;
          bVar17 = (byte)iVar11;
          if (uVar15 == ((uint)bVar10 | (uint)bVar13 << 8 | uVar27 << 0x10 | uVar25 << 0x18)) {
            if ((iVar26 - (uint)bVar1 == iVar16) || (iVar11 = iVar11 + 1, iVar11 == 0x3e)) {
              iVar11 = 0;
              uVar20 = (ulong)(bVar17 | 0xc0);
              iVar21 = iVar23;
              iVar23 = iVar23 + 1;
              goto LAB_001025ff;
            }
          }
          else {
            if (0 < iVar11) {
              iVar11 = 0;
              lVar22 = (long)iVar23;
              iVar23 = iVar23 + 1;
              *(byte *)((long)puVar8 + lVar22) = bVar17 - 1 | 0xc0;
            }
            uVar20 = (ulong)(uVar14 * 0xb +
                             (((uint)bVar3 * 5 + (uint)bVar2 + (uint)bVar2 * 2 + (uint)bVar4 * 8) -
                             (uint)bVar4) & 0x3f);
            iVar21 = iVar23;
            if ((&local_138)[uVar20] == uVar15) {
              iVar23 = iVar23 + 1;
            }
            else {
              *(byte *)(&local_138 + uVar20) = bVar2;
              *(byte *)((long)&local_138 + uVar20 * 4 + 1) = bVar3;
              *(byte *)((long)&local_138 + uVar20 * 4 + 2) = bVar4;
              *(char *)((long)&local_138 + uVar20 * 4 + 3) = (char)uVar14;
              if ((char)uVar14 == (char)uVar25) {
                cVar24 = bVar2 - bVar10;
                cVar18 = bVar3 - bVar13;
                cVar9 = bVar4 - (char)uVar27;
                if ((((byte)(cVar24 + 2U) < 4) && ((byte)(cVar18 + 2U) < 4)) &&
                   (bVar10 = cVar9 + 2, bVar10 < 4)) {
                  uVar20 = (ulong)(byte)(cVar18 * '\x04' + 8U | cVar24 * '\x10' + 0x20U | bVar10 |
                                        0x40);
                  iVar23 = iVar23 + 1;
                }
                else if ((((byte)((cVar24 - cVar18) + 8U) < 0x10) && ((byte)(cVar18 + 0x20U) < 0x40)
                         ) && (bVar10 = (cVar9 - cVar18) + 8, bVar10 < 0x10)) {
                  iVar21 = iVar23 + 1;
                  *(byte *)((long)puVar8 + (long)iVar23) = cVar18 + 0x20U | 0x80;
                  uVar20 = (ulong)(byte)((bVar10 | (cVar24 - cVar18) * '\x10') + 0x80);
                  iVar23 = iVar23 + 2;
                }
                else {
                  *(undefined1 *)((long)puVar8 + (long)iVar23) = 0xfe;
                  *(byte *)((long)puVar8 + (long)(iVar23 + 1)) = bVar2;
                  iVar21 = iVar23 + 3;
                  *(byte *)((long)puVar8 + (long)(iVar23 + 2)) = bVar3;
                  uVar20 = (ulong)bVar4;
                  iVar23 = iVar23 + 4;
                }
              }
              else {
                iVar12 = iVar23 + 2;
                *(undefined1 *)((long)puVar8 + (long)iVar23) = 0xff;
                iVar21 = iVar23 + 4;
                *(byte *)((long)puVar8 + (long)(iVar23 + 1)) = bVar2;
                iVar19 = iVar23 + 3;
                iVar23 = iVar23 + 5;
                *(byte *)((long)puVar8 + (long)iVar12) = bVar3;
                uVar20 = (ulong)uVar14;
                *(byte *)((long)puVar8 + (long)iVar19) = bVar4;
              }
            }
LAB_001025ff:
            *(char *)((long)puVar8 + (long)iVar21) = (char)uVar20;
          }
          uVar27 = (uint)bVar4;
          iVar16 = iVar16 + (uint)bVar1;
          bVar10 = bVar2;
          bVar13 = bVar3;
          uVar25 = uVar14;
        } while (iVar16 < iVar26);
      }
      *(undefined1 *)((long)puVar8 + (long)iVar23) = 0;
      *(undefined4 *)((long)puVar8 + (long)(iVar23 + 1)) = 0;
      *(undefined2 *)((long)puVar8 + (long)(iVar23 + 5)) = 0;
      *(undefined1 *)((long)puVar8 + (long)(iVar23 + 7)) = 1;
      *param_3 = iVar23 + 8;
      return puVar8;
    }
  }
                    /* WARNING: Read-only address (ram,0x001009c0) is written */
  return (undefined4 *)0x0;
}

