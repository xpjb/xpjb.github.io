
void sha256_init(long param_1)

{
  *(undefined4 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = 0;
  *(undefined8 *)(param_1 + 0x50) = 0xbb67ae856a09e667;
  *(undefined8 *)(param_1 + 0x58) = 0xa54ff53a3c6ef372;
  *(undefined8 *)(param_1 + 0x60) = 0x9b05688c510e527f;
  *(undefined8 *)(param_1 + 0x68) = 0x5be0cd191f83d9ab;
  return;
}

