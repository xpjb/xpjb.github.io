
void sha256_final(undefined1 (*param_1) [32],undefined1 *param_2)

{
  uint uVar1;
  ulong uVar2;
  long lVar3;
  
  uVar1 = *(uint *)param_1[2];
  uVar2 = (ulong)uVar1;
  (*param_1)[uVar2] = 0x80;
  if (uVar2 < 0x38) {
    if (uVar1 != 0x37) {
      memset(*param_1 + uVar2 + 1,0,0x37 - uVar2);
    }
  }
  else {
    if (uVar1 + 1 < 0x40) {
      memset(*param_1 + (uVar1 + 1),0,(ulong)(0x3e - uVar1) + 1);
    }
    sha256_transform(param_1,param_1);
    *(undefined1 (*) [32])(*param_1 + 0x18) = ZEXT1232(ZEXT812(0));
    *param_1 = ZEXT1232(ZEXT812(0));
  }
  lVar3 = (ulong)(uint)(*(int *)param_1[2] << 3) + *(long *)(param_1[2] + 8);
  *(long *)(param_1[2] + 8) = lVar3;
  param_1[1][0x1f] = (char)lVar3;
  param_1[1][0x1e] = (char)((ulong)lVar3 >> 8);
  param_1[1][0x1d] = (char)((ulong)lVar3 >> 0x10);
  param_1[1][0x1c] = (char)((ulong)lVar3 >> 0x18);
  param_1[1][0x1b] = (char)((ulong)lVar3 >> 0x20);
  param_1[1][0x1a] = (char)((ulong)lVar3 >> 0x28);
  param_1[1][0x19] = (char)((ulong)lVar3 >> 0x30);
  param_1[1][0x18] = (char)((ulong)lVar3 >> 0x38);
  sha256_transform(param_1,param_1);
  *param_2 = param_1[2][0x13];
  param_2[4] = param_1[2][0x17];
  param_2[8] = param_1[2][0x1b];
  param_2[0xc] = param_1[2][0x1f];
  param_2[0x10] = param_1[3][3];
  param_2[0x14] = param_1[3][7];
  param_2[0x18] = param_1[3][0xb];
  param_2[0x1c] = param_1[3][0xf];
  param_2[1] = param_1[2][0x12];
  param_2[5] = param_1[2][0x16];
  param_2[9] = param_1[2][0x1a];
  param_2[0xd] = param_1[2][0x1e];
  param_2[0x11] = param_1[3][2];
  param_2[0x15] = param_1[3][6];
  param_2[0x19] = param_1[3][10];
  param_2[0x1d] = param_1[3][0xe];
  param_2[2] = param_1[2][0x11];
  param_2[6] = param_1[2][0x15];
  param_2[10] = param_1[2][0x19];
  param_2[0xe] = param_1[2][0x1d];
  param_2[0x12] = param_1[3][1];
  param_2[0x16] = param_1[3][5];
  param_2[0x1a] = param_1[3][9];
  param_2[0x1e] = param_1[3][0xd];
  param_2[3] = param_1[2][0x10];
  param_2[7] = param_1[2][0x14];
  param_2[0xb] = param_1[2][0x18];
  param_2[0xf] = param_1[2][0x1c];
  param_2[0x13] = param_1[3][0];
  param_2[0x17] = param_1[3][4];
  param_2[0x1b] = param_1[3][8];
  param_2[0x1f] = param_1[3][0xc];
  return;
}

