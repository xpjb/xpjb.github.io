
void sha256_transform(long param_1,undefined1 (*param_2) [32])

{
  undefined1 auVar1 [16];
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  uint uVar5;
  uint uVar6;
  long lVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  undefined1 auVar19 [16];
  undefined1 auVar20 [32];
  undefined1 auVar21 [32];
  undefined1 auVar22 [32];
  undefined1 auVar23 [16];
  undefined1 auVar24 [16];
  undefined1 local_138 [32];
  undefined1 local_118 [32];
  uint auStack_f8 [50];
  
  auVar1 = *(undefined1 (*) [16])*param_2;
  auVar2 = *(undefined1 (*) [16])(*param_2 + 0x10);
  lVar7 = 0;
  auVar19 = SUB6416(ZEXT464(0xd090501),0);
  auVar3 = vpshufb_avx(auVar2,auVar19);
  auVar4 = vpshufb_avx(auVar1,auVar19);
  auVar3 = vpunpckldq_avx(auVar4,auVar3);
  auVar20 = vpmovzxbd_avx2(auVar3);
  auVar22 = vpslld_avx2(auVar20,0x10);
  auVar23 = SUB6416(ZEXT464(0xe0a0602),0);
  auVar3 = vpshufb_avx(auVar2,auVar23);
  auVar4 = vpshufb_avx(auVar1,auVar23);
  auVar24 = SUB6416(ZEXT464(0xf0b0703),0);
  auVar2 = vpshufb_avx(auVar2,auVar24);
  auVar1 = vpshufb_avx(auVar1,auVar24);
  auVar1 = vpunpckldq_avx(auVar1,auVar2);
  auVar2 = vpunpckldq_avx(auVar4,auVar3);
  auVar20 = vpmovzxbd_avx2(auVar1);
  auVar21 = vpslld_avx2(*param_2,0x18);
  auVar22 = vpor_avx2(auVar22,auVar21);
  auVar21 = vpmovzxbd_avx2(auVar2);
  auVar21 = vpslld_avx2(auVar21,8);
  auVar20 = vpor_avx2(auVar21,auVar20);
  local_138 = vpor_avx2(auVar22,auVar20);
  auVar1 = *(undefined1 (*) [16])(param_2[1] + 0x10);
  auVar2 = *(undefined1 (*) [16])param_2[1];
  auVar3 = vpshufb_avx(auVar1,auVar19);
  auVar4 = vpshufb_avx(auVar2,auVar19);
  auVar19 = vpunpckldq_avx(auVar4,auVar3);
  auVar3 = vpshufb_avx(auVar1,auVar23);
  auVar4 = vpshufb_avx(auVar2,auVar23);
  auVar1 = vpshufb_avx(auVar1,auVar24);
  auVar2 = vpshufb_avx(auVar2,auVar24);
  auVar1 = vpunpckldq_avx(auVar2,auVar1);
  auVar20 = vpmovzxbd_avx2(auVar19);
  auVar2 = vpunpckldq_avx(auVar4,auVar3);
  auVar21 = vpmovzxbd_avx2(auVar1);
  auVar20 = vpslld_avx2(auVar20,0x10);
  auVar22 = vpslld_avx2(param_2[1],0x18);
  auVar22 = vpor_avx2(auVar20,auVar22);
  auVar20 = vpmovzxbd_avx2(auVar2);
  auVar20 = vpslld_avx2(auVar20,8);
  auVar20 = vpor_avx2(auVar20,auVar21);
  local_118 = vpor_avx2(auVar22,auVar20);
  do {
    uVar6 = *(uint *)(local_118 + lVar7 * 4 + 0x18);
    uVar10 = *(uint *)(local_138 + lVar7 * 4 + 4);
    uVar18 = *(uint *)(local_138 + lVar7 * 4 + 8);
    uVar8 = (uVar6 >> 10 ^ (uVar6 >> 0x13 | uVar6 << 0xd) ^ (uVar6 >> 0x11 | uVar6 << 0xf)) +
            *(int *)(local_118 + lVar7 * 4 + 4) + *(int *)(local_138 + lVar7 * 4) +
            (uVar10 >> 3 ^ (uVar10 >> 0x12 | uVar10 << 0xe) ^ (uVar10 >> 7 | uVar10 << 0x19));
    auStack_f8[lVar7] = uVar8;
    uVar6 = *(uint *)(local_118 + lVar7 * 4 + 0x1c);
    uVar12 = (uVar18 >> 3 ^ (uVar18 >> 0x12 | uVar18 << 0xe) ^ (uVar18 >> 7 | uVar18 << 0x19)) +
             uVar10 + (uVar6 >> 10 ^ (uVar6 >> 0x13 | uVar6 << 0xd) ^ (uVar6 >> 0x11 | uVar6 << 0xf)
                      ) + *(int *)(local_118 + lVar7 * 4 + 8);
    auStack_f8[lVar7 + 1] = uVar12;
    uVar6 = *(uint *)(local_138 + lVar7 * 4 + 0xc);
    auStack_f8[lVar7 + 2] =
         (uVar6 >> 3 ^ (uVar6 >> 0x12 | uVar6 << 0xe) ^ (uVar6 >> 7 | uVar6 << 0x19)) + uVar18 +
         (uVar8 >> 10 ^ (uVar8 >> 0x13 | uVar8 * 0x2000) ^ (uVar8 >> 0x11 | uVar8 * 0x8000)) +
         *(int *)(local_118 + lVar7 * 4 + 0xc);
    uVar10 = *(uint *)(local_138 + lVar7 * 4 + 0x10);
    auStack_f8[lVar7 + 3] =
         (uVar10 >> 3 ^ (uVar10 >> 0x12 | uVar10 << 0xe) ^ (uVar10 >> 7 | uVar10 << 0x19)) + uVar6 +
         (uVar12 >> 10 ^ (uVar12 >> 0x13 | uVar12 * 0x2000) ^ (uVar12 >> 0x11 | uVar12 * 0x8000)) +
         *(int *)(local_118 + lVar7 * 4 + 0x10);
    lVar7 = lVar7 + 4;
  } while (lVar7 != 0x30);
  lVar7 = 0;
  uVar6 = *(uint *)(param_1 + 0x50);
  uVar10 = *(uint *)(param_1 + 0x54);
  uVar18 = *(uint *)(param_1 + 0x58);
  uVar8 = *(uint *)(param_1 + 0x5c);
  uVar12 = *(uint *)(param_1 + 0x60);
  uVar15 = *(uint *)(param_1 + 100);
  uVar13 = *(uint *)(param_1 + 0x68);
  uVar11 = *(uint *)(param_1 + 0x6c);
  do {
    uVar14 = uVar15;
    uVar17 = uVar12;
    uVar9 = uVar10;
    uVar5 = uVar6;
    iVar16 = (~uVar17 & uVar13 | uVar14 & uVar17) + uVar11 +
             ((uVar17 >> 0x19 | uVar17 << 7) ^
             (uVar17 >> 0xb | uVar17 << 0x15) ^ (uVar17 >> 6 | uVar17 << 0x1a)) + (&k)[lVar7] +
             *(int *)(local_138 + lVar7 * 4);
    uVar15 = uVar8 + iVar16;
    uVar10 = (uVar9 & uVar18 ^ (uVar9 ^ uVar18) & uVar5) +
             ((uVar5 >> 0x16 | uVar5 << 10) ^
             (uVar5 >> 0xd | uVar5 << 0x13) ^ (uVar5 >> 2 | uVar5 << 0x1e)) + iVar16;
    iVar16 = (~uVar15 & uVar14 | uVar17 & uVar15) + uVar13 +
             ((uVar15 >> 0x19 | uVar15 * 0x80) ^
             (uVar15 >> 0xb | uVar15 * 0x200000) ^ (uVar15 >> 6 | uVar15 * 0x4000000)) +
             (&DAT_00100a34)[lVar7] + *(int *)(local_138 + lVar7 * 4 + 4);
    lVar7 = lVar7 + 2;
    uVar12 = uVar18 + iVar16;
    uVar6 = (uVar5 & uVar9 ^ (uVar5 ^ uVar9) & uVar10) +
            ((uVar10 >> 0x16 | uVar10 * 0x400) ^
            (uVar10 >> 0xd | uVar10 * 0x80000) ^ (uVar10 >> 2 | uVar10 * 0x40000000)) + iVar16;
    uVar18 = uVar5;
    uVar8 = uVar9;
    uVar13 = uVar17;
    uVar11 = uVar14;
  } while (lVar7 != 0x40);
  *(uint *)(param_1 + 0x50) = uVar6 + *(int *)(param_1 + 0x50);
  *(undefined4 *)(param_1 + 0x54) = *(undefined4 *)(param_1 + 0x54);
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_1 + 0x58);
  *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_1 + 0x5c);
  *(uint *)(param_1 + 0x60) = uVar12 + *(int *)(param_1 + 0x60);
  *(undefined4 *)(param_1 + 100) = *(undefined4 *)(param_1 + 100);
  *(undefined4 *)(param_1 + 0x68) = *(undefined4 *)(param_1 + 0x68);
  *(undefined4 *)(param_1 + 0x6c) = *(undefined4 *)(param_1 + 0x6c);
  return;
}

