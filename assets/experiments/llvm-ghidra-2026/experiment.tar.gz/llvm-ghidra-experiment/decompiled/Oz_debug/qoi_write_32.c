
void qoi_write_32(uchar *bytes,int *p,uint v)

{
  int iVar1;
  
  iVar1 = *p;
  *p = iVar1 + 1;
  bytes[iVar1] = (uchar)(v >> 0x18);
  iVar1 = *p;
  *p = iVar1 + 1;
  bytes[iVar1] = (uchar)(v >> 0x10);
  iVar1 = *p;
  *p = iVar1 + 1;
  bytes[iVar1] = (uchar)(v >> 8);
  iVar1 = *p;
  *p = iVar1 + 1;
  bytes[iVar1] = (uchar)v;
  return;
}

