
void * qoi_encode(void *data,qoi_desc *desc,int *out_len)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  uint v;
  byte bVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  uchar *bytes;
  int iVar10;
  long lVar11;
  byte bVar12;
  char cVar13;
  int iVar14;
  int iVar15;
  byte bVar16;
  byte bVar17;
  byte bVar18;
  byte bVar19;
  char cVar20;
  ulong uVar21;
  undefined1 auVar22 [16];
  int local_144;
  int *local_140;
  undefined1 local_138 [32];
  undefined1 local_118 [32];
  undefined1 local_f8 [32];
  undefined1 local_d8 [32];
  undefined1 local_b8 [32];
  undefined1 local_98 [32];
  undefined1 local_78 [32];
  undefined1 local_58 [32];
  
                    /* Unresolved local var: qoi_rgba_t[64] index@[???]
                       Unresolved local var: int max_size@[???]
                       Unresolved local var: int p@[???]
                       Unresolved local var: uchar * bytes@[???]
                       Unresolved local var: uchar * pixels@[???]
                       Unresolved local var: int px_len@[???]
                       Unresolved local var: int px_end@[???]
                       Unresolved local var: int channels@[???]
                       Unresolved local var: int px_pos@[???]
                       Unresolved local var: int run@[???]
                       Unresolved local var: qoi_rgba_t px_prev@[???]
                       Unresolved local var: qoi_rgba_t px@[???]
                       Unresolved local var: int i@[???] */
  if (desc == (qoi_desc *)0x0) {
    return (void *)0x0;
  }
  if (data == (void *)0x0) {
    return (void *)0x0;
  }
  if (out_len == (int *)0x0) {
    return (void *)0x0;
  }
  uVar7 = desc->width;
  if ((((uVar7 != 0) && (v = desc->height, v != 0)) &&
      (bVar1 = desc->channels, 0xfd < (byte)(bVar1 - 5))) && (bVar17 = desc->colorspace, bVar17 < 2)
     ) {
    if ((uint)(400000000 / (ulong)uVar7) <= v) {
      return (void *)0x0;
    }
    local_140 = out_len;
    bytes = malloc((long)(int)((bVar1 + 1) * v * uVar7 + 0x16));
    if (bytes != (uchar *)0x0) {
      iVar8 = 0;
      builtin_memcpy(bytes,"qoif",4);
      local_144 = 4;
      qoi_write_32(bytes,&local_144,uVar7);
      qoi_write_32(bytes,&local_144,v);
      auVar22._0_12_ = ZEXT812(0);
      auVar22._12_4_ = 0;
      local_58 = ZEXT1632(auVar22);
      local_78 = ZEXT1632(auVar22);
      local_98 = ZEXT1632(auVar22);
      local_b8 = local_98;
      local_d8 = local_98;
      local_f8 = local_98;
      local_118 = ZEXT1632(auVar22);
      local_138 = ZEXT1632(auVar22);
      iVar14 = v * uVar7 * (uint)bVar1;
      bytes[local_144] = bVar1;
      iVar6 = local_144 + 2;
      iVar10 = 0;
      bytes[local_144 + 1] = bVar17;
      bVar12 = 0xff;
      bVar16 = 0;
      bVar17 = 0;
      bVar5 = 0;
      do {
        if (iVar14 <= iVar10) {
          for (lVar11 = 0; iVar8 = iVar6 + (int)lVar11, lVar11 != 8; lVar11 = lVar11 + 1) {
            bytes[iVar8] = ""[lVar11];
          }
          *local_140 = iVar8;
          return bytes;
        }
        bVar18 = bVar12;
        if (bVar1 == 4) {
          bVar18 = *(byte *)((long)data + (long)(iVar10 + 3));
        }
        bVar2 = *(byte *)((long)data + (long)iVar10);
        bVar3 = *(byte *)((long)data + (long)iVar10 + 1);
        bVar4 = *(byte *)((long)data + (long)(iVar10 + 2));
        uVar7 = (uint)bVar3 << 8 | (uint)bVar4 << 0x10 | (uint)bVar18 << 0x18 | (uint)bVar2;
        bVar19 = (byte)iVar8;
        if (uVar7 == ((uint)bVar16 | (uint)bVar17 << 8 | (uint)bVar5 << 0x10 | (uint)bVar12 << 0x18)
           ) {
          if ((iVar14 - (uint)bVar1 == iVar10) || (iVar8 = iVar8 + 1, iVar8 == 0x3e)) {
            uVar21 = (ulong)(bVar19 | 0xc0);
            iVar8 = 0;
LAB_001022b6:
            iVar9 = iVar6 + 1;
            iVar15 = iVar6;
            bVar17 = (byte)uVar21;
            goto LAB_0010238c;
          }
        }
        else {
                    /* Unresolved local var: int index_pos@[???] */
          if (0 < iVar8) {
            iVar8 = 0;
            lVar11 = (long)iVar6;
            iVar6 = iVar6 + 1;
            bytes[lVar11] = bVar19 - 1 | 0xc0;
          }
          uVar21 = (ulong)((uint)bVar18 * 0xb +
                           (uint)bVar3 + (uint)bVar3 * 4 + (uint)bVar2 + (uint)bVar2 * 2 +
                           (uint)bVar4 * 7 & 0x3f);
          if (*(uint *)(local_138 + uVar21 * 4) == uVar7) goto LAB_001022b6;
          local_138[uVar21 * 4] = bVar2;
          local_138[uVar21 * 4 + 1] = bVar3;
          local_138[uVar21 * 4 + 2] = bVar4;
          local_138[uVar21 * 4 + 3] = bVar18;
          if (bVar18 == bVar12) {
                    /* Unresolved local var: char vr@[???]
                       Unresolved local var: char vg@[???]
                       Unresolved local var: char vb@[???]
                       Unresolved local var: char vg_b@[???]
                       Unresolved local var: char vg_r@[???] */
            cVar20 = bVar3 - bVar17;
            cVar13 = bVar2 - bVar16;
            if ((((byte)(cVar13 + 2U) < 4) && ((byte)(cVar20 + 2U) < 4)) &&
               (bVar17 = (bVar4 - bVar5) + 2, bVar17 < 4)) {
              iVar9 = iVar6 + 1;
              iVar15 = iVar6;
              bVar17 = cVar20 * '\x04' + 8U | cVar13 * '\x10' + 0x20U | bVar17 | 0x40;
            }
            else if ((((byte)((cVar13 - cVar20) + 8U) < 0x10) && ((byte)(cVar20 + 0x20U) < 0x40)) &&
                    (bVar17 = ((bVar4 - bVar5) - cVar20) + 8, bVar17 < 0x10)) {
              bytes[iVar6] = cVar20 + 0x20U | 0x80;
              iVar9 = iVar6 + 2;
              iVar15 = iVar6 + 1;
              bVar17 = (bVar17 | (cVar13 - cVar20) * '\x10') + 0x80;
            }
            else {
              bytes[iVar6] = 0xfe;
              iVar9 = iVar6 + 4;
              bytes[iVar6 + 1] = bVar2;
              bytes[iVar6 + 2] = bVar3;
              iVar15 = iVar6 + 3;
              bVar17 = bVar4;
            }
          }
          else {
            bytes[iVar6] = 0xff;
            bytes[iVar6 + 1] = bVar2;
            bytes[iVar6 + 2] = bVar3;
            iVar15 = iVar6 + 4;
            iVar9 = iVar6 + 5;
            bytes[iVar6 + 3] = bVar4;
            bVar17 = bVar18;
          }
LAB_0010238c:
          bytes[iVar15] = bVar17;
          iVar6 = iVar9;
        }
        iVar10 = iVar10 + (uint)bVar1;
        bVar12 = bVar18;
        bVar16 = bVar2;
        bVar17 = bVar3;
        bVar5 = bVar4;
      } while( true );
    }
  }
  return (void *)0x0;
}




void qoi_write_32(uchar *bytes,int *p,uint v)

{
  int iVar1;
  
  iVar1 = *p;
  *p = iVar1 + 1;
  bytes[iVar1] = (uchar)(v >> 0x18);
  iVar1 = *p;
  *p = iVar1 + 1;
  bytes[iVar1] = (uchar)(v >> 0x10);
  iVar1 = *p;
  *p = iVar1 + 1;
  bytes[iVar1] = (uchar)(v >> 8);
  iVar1 = *p;
  *p = iVar1 + 1;
  bytes[iVar1] = (uchar)v;
  return;
}




void * qoi_decode(void *data,int size,qoi_desc *desc,int channels)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  void *pvVar4;
  int iVar5;
  long lVar6;
  byte bVar7;
  byte bVar8;
  ulong uVar9;
  byte bVar10;
  byte bVar11;
  int iVar12;
  byte bVar13;
  int iVar14;
  undefined1 auVar15 [16];
  ulong local_158;
  int local_144 [3];
  undefined1 local_138 [32];
  undefined1 local_118 [32];
  undefined1 local_f8 [32];
  undefined1 local_d8 [32];
  undefined1 local_b8 [32];
  undefined1 local_98 [32];
  undefined1 local_78 [32];
  undefined1 local_58 [32];
  
                    /* Unresolved local var: qoi_rgba_t[64] index@[???]
                       Unresolved local var: int p@[???]
                       Unresolved local var: int run@[???]
                       Unresolved local var: uchar * bytes@[???]
                       Unresolved local var: uint header_magic@[???]
                       Unresolved local var: int px_len@[???]
                       Unresolved local var: uchar * pixels@[???]
                       Unresolved local var: int chunks_len@[???]
                       Unresolved local var: int px_pos@[???]
                       Unresolved local var: qoi_rgba_t px@[???] */
  local_144[0] = 0;
  if ((data != (void *)0x0) && (desc != (qoi_desc *)0x0)) {
    if ((0x15 < size) && (channels == 3 || (channels & 0xfffffffbU) == 0)) {
      uVar1 = qoi_read_32(data,local_144);
      uVar2 = qoi_read_32(data,local_144);
      desc->width = uVar2;
      uVar3 = qoi_read_32(data,local_144);
      iVar12 = local_144[0];
      desc->height = uVar3;
      bVar7 = *(byte *)((long)data + (long)local_144[0]);
      desc->channels = bVar7;
      bVar10 = *(byte *)((long)data + (long)(local_144[0] + 1));
      desc->colorspace = bVar10;
      if (((uVar2 != 0) && (uVar3 != 0)) && (0xfd < (byte)(bVar7 - 5))) {
        if (1 < bVar10) {
          return (void *)0x0;
        }
        if (uVar1 != 0x716f6966) {
          return (void *)0x0;
        }
        if ((uint)(400000000 / (ulong)uVar2) <= uVar3) {
          return (void *)0x0;
        }
        uVar1 = (uint)bVar7;
        if (channels != 0) {
          uVar1 = channels;
        }
        iVar14 = uVar3 * uVar2 * uVar1;
        pvVar4 = malloc((long)iVar14);
        uVar2 = 0;
        if (pvVar4 != (void *)0x0) {
          iVar12 = iVar12 + 2;
          bVar7 = 0xff;
          auVar15._0_12_ = ZEXT812(0);
          auVar15._12_4_ = 0;
          local_58 = ZEXT1632(auVar15);
          local_78 = ZEXT1632(auVar15);
          local_98 = ZEXT1632(auVar15);
          local_b8 = local_98;
          local_d8 = local_98;
          local_f8 = local_98;
          local_118 = ZEXT1632(auVar15);
          local_138 = ZEXT1632(auVar15);
          uVar3 = 0;
          bVar10 = 0;
          bVar11 = 0;
          iVar5 = 0;
          do {
            if (iVar14 <= iVar5) {
              return pvVar4;
            }
            if ((int)uVar2 < 1) {
              uVar2 = 0;
              if (iVar12 < size + -8) {
                    /* Unresolved local var: int b1@[???] */
                lVar6 = (long)iVar12;
                bVar8 = *(byte *)((long)data + lVar6);
                uVar9 = (ulong)bVar8;
                local_158 = lVar6 + 1;
                if (bVar8 == 0xff) {
                  bVar13 = *(byte *)((long)data + local_158);
                  bVar10 = *(byte *)((long)data + lVar6 + 2);
                  bVar11 = *(byte *)((long)data + lVar6 + 3);
                  bVar7 = *(byte *)((long)data + lVar6 + 4);
                  uVar2 = iVar12 + 5;
LAB_00102690:
                  uVar3 = (uint)bVar13;
                  local_158 = (ulong)uVar2;
                  uVar2 = 0;
                }
                else {
                  switch(bVar8) {
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  case 4:
                  case 5:
                  case 6:
                  case 7:
                  case 8:
                  case 9:
                  case 10:
                  case 0xb:
                  case 0xc:
                  case 0xd:
                  case 0xe:
                  case 0xf:
                  case 0x10:
                  case 0x11:
                  case 0x12:
                  case 0x13:
                  case 0x14:
                  case 0x15:
                  case 0x16:
                  case 0x17:
                  case 0x18:
                  case 0x19:
                  case 0x1a:
                  case 0x1b:
                  case 0x1c:
                  case 0x1d:
                  case 0x1e:
                  case 0x1f:
                  case 0x20:
                  case 0x21:
                  case 0x22:
                  case 0x23:
                  case 0x24:
                  case 0x25:
                  case 0x26:
                  case 0x27:
                  case 0x28:
                  case 0x29:
                  case 0x2a:
                  case 0x2b:
                  case 0x2c:
                  case 0x2d:
                  case 0x2e:
                  case 0x2f:
                  case 0x30:
                  case 0x31:
                  case 0x32:
                  case 0x33:
                  case 0x34:
                  case 0x35:
                  case 0x36:
                  case 0x37:
                  case 0x38:
                  case 0x39:
                  case 0x3a:
                  case 0x3b:
                  case 0x3c:
                  case 0x3d:
                  case 0x3e:
                  case 0x3f:
                    uVar3 = (uint)(byte)local_138[uVar9 * 4];
                    bVar10 = local_138[uVar9 * 4 + 1];
                    bVar11 = local_138[uVar9 * 4 + 2];
                    bVar7 = local_138[uVar9 * 4 + 3];
                    uVar2 = 0;
                    break;
                  case 0x40:
                  case 0x41:
                  case 0x42:
                  case 0x43:
                  case 0x44:
                  case 0x45:
                  case 0x46:
                  case 0x47:
                  case 0x48:
                  case 0x49:
                  case 0x4a:
                  case 0x4b:
                  case 0x4c:
                  case 0x4d:
                  case 0x4e:
                  case 0x4f:
                  case 0x50:
                  case 0x51:
                  case 0x52:
                  case 0x53:
                  case 0x54:
                  case 0x55:
                  case 0x56:
                  case 0x57:
                  case 0x58:
                  case 0x59:
                  case 0x5a:
                  case 0x5b:
                  case 0x5c:
                  case 0x5d:
                  case 0x5e:
                  case 0x5f:
                  case 0x60:
                  case 0x61:
                  case 0x62:
                  case 99:
                  case 100:
                  case 0x65:
                  case 0x66:
                  case 0x67:
                  case 0x68:
                  case 0x69:
                  case 0x6a:
                  case 0x6b:
                  case 0x6c:
                  case 0x6d:
                  case 0x6e:
                  case 0x6f:
                  case 0x70:
                  case 0x71:
                  case 0x72:
                  case 0x73:
                  case 0x74:
                  case 0x75:
                  case 0x76:
                  case 0x77:
                  case 0x78:
                  case 0x79:
                  case 0x7a:
                  case 0x7b:
                  case 0x7c:
                  case 0x7d:
                  case 0x7e:
                  case 0x7f:
                    uVar2 = 0;
                    bVar11 = (bVar11 + (bVar8 & 3)) - 2;
                    uVar3 = (uint)(byte)(((char)uVar3 + (bVar8 >> 4 & 3)) - 2);
                    bVar10 = (bVar10 + (bVar8 >> 2 & 3)) - 2;
                    break;
                  case 0x80:
                  case 0x81:
                  case 0x82:
                  case 0x83:
                  case 0x84:
                  case 0x85:
                  case 0x86:
                  case 0x87:
                  case 0x88:
                  case 0x89:
                  case 0x8a:
                  case 0x8b:
                  case 0x8c:
                  case 0x8d:
                  case 0x8e:
                  case 0x8f:
                  case 0x90:
                  case 0x91:
                  case 0x92:
                  case 0x93:
                  case 0x94:
                  case 0x95:
                  case 0x96:
                  case 0x97:
                  case 0x98:
                  case 0x99:
                  case 0x9a:
                  case 0x9b:
                  case 0x9c:
                  case 0x9d:
                  case 0x9e:
                  case 0x9f:
                  case 0xa0:
                  case 0xa1:
                  case 0xa2:
                  case 0xa3:
                  case 0xa4:
                  case 0xa5:
                  case 0xa6:
                  case 0xa7:
                  case 0xa8:
                  case 0xa9:
                  case 0xaa:
                  case 0xab:
                  case 0xac:
                  case 0xad:
                  case 0xae:
                  case 0xaf:
                  case 0xb0:
                  case 0xb1:
                  case 0xb2:
                  case 0xb3:
                  case 0xb4:
                  case 0xb5:
                  case 0xb6:
                  case 0xb7:
                  case 0xb8:
                  case 0xb9:
                  case 0xba:
                  case 0xbb:
                  case 0xbc:
                  case 0xbd:
                  case 0xbe:
                  case 0xbf:
                    /* Unresolved local var: int b2@[???]
                       Unresolved local var: int vg@[???] */
                    bVar8 = bVar8 & 0x3f;
                    uVar2 = iVar12 + 2;
                    bVar10 = (bVar10 + bVar8) - 0x20;
                    bVar13 = (char)uVar3 + ((*(byte *)((long)data + local_158) >> 4) - 0x28) + bVar8
                    ;
                    bVar11 = bVar11 + ((*(byte *)((long)data + local_158) & 0xf) - 0x28) + bVar8;
                    goto LAB_00102690;
                  case 0xc0:
                  case 0xc1:
                  case 0xc2:
                  case 0xc3:
                  case 0xc4:
                  case 0xc5:
                  case 0xc6:
                  case 199:
                  case 200:
                  case 0xc9:
                  case 0xca:
                  case 0xcb:
                  case 0xcc:
                  case 0xcd:
                  case 0xce:
                  case 0xcf:
                  case 0xd0:
                  case 0xd1:
                  case 0xd2:
                  case 0xd3:
                  case 0xd4:
                  case 0xd5:
                  case 0xd6:
                  case 0xd7:
                  case 0xd8:
                  case 0xd9:
                  case 0xda:
                  case 0xdb:
                  case 0xdc:
                  case 0xdd:
                  case 0xde:
                  case 0xdf:
                  case 0xe0:
                  case 0xe1:
                  case 0xe2:
                  case 0xe3:
                  case 0xe4:
                  case 0xe5:
                  case 0xe6:
                  case 0xe7:
                  case 0xe8:
                  case 0xe9:
                  case 0xea:
                  case 0xeb:
                  case 0xec:
                  case 0xed:
                  case 0xee:
                  case 0xef:
                  case 0xf0:
                  case 0xf1:
                  case 0xf2:
                  case 0xf3:
                  case 0xf4:
                  case 0xf5:
                  case 0xf6:
                  case 0xf7:
                  case 0xf8:
                  case 0xf9:
                  case 0xfa:
                  case 0xfb:
                  case 0xfc:
                  case 0xfd:
                    uVar2 = bVar8 & 0x3f;
                    break;
                  default:
                    uVar3 = (uint)*(byte *)((long)data + local_158);
                    bVar10 = *(byte *)((long)data + lVar6 + 2);
                    bVar11 = *(byte *)((long)data + lVar6 + 3);
                    uVar2 = 0;
                    local_158 = (ulong)(iVar12 + 4);
                  }
                }
                uVar9 = (ulong)((uint)bVar7 * 0xb + (uint)bVar11 * 7 +
                                (uint)bVar10 + (uint)bVar10 * 4 + uVar3 * 3 & 0x3f);
                local_138[uVar9 * 4] = (char)uVar3;
                local_138[uVar9 * 4 + 1] = bVar10;
                local_138[uVar9 * 4 + 2] = bVar11;
                local_138[uVar9 * 4 + 3] = bVar7;
                iVar12 = (int)local_158;
              }
            }
            else {
              uVar2 = uVar2 - 1;
            }
            *(char *)((long)pvVar4 + (long)iVar5) = (char)uVar3;
            *(byte *)((long)pvVar4 + (long)iVar5 + 1) = bVar10;
            *(byte *)((long)pvVar4 + (long)(iVar5 + 2)) = bVar11;
            if (uVar1 == 4) {
              *(byte *)((long)pvVar4 + (long)(iVar5 + 3)) = bVar7;
            }
            iVar5 = iVar5 + uVar1;
          } while( true );
        }
      }
    }
  }
  return (void *)0x0;
}




uint qoi_read_32(uchar *bytes,int *p)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  
                    /* Unresolved local var: uint a@[???]
                       Unresolved local var: uint b@[???]
                       Unresolved local var: uint c@[???]
                       Unresolved local var: uint d@[???] */
  iVar4 = *p;
  *p = iVar4 + 1;
  bVar1 = bytes[iVar4];
  *p = iVar4 + 2;
  bVar2 = bytes[iVar4 + 1];
  *p = iVar4 + 3;
  bVar3 = bytes[iVar4 + 2];
  *p = iVar4 + 4;
  return (uint)bVar3 << 8 | (uint)bVar2 << 0x10 | (uint)bVar1 << 0x18 | (uint)bytes[iVar4 + 3];
}



