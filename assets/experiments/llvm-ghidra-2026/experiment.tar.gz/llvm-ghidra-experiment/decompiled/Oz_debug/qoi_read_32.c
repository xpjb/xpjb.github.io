
uint qoi_read_32(uchar *bytes,int *p)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  
                    /* Unresolved local var: uint a@[???]
                       Unresolved local var: uint b@[???]
                       Unresolved local var: uint c@[???]
                       Unresolved local var: uint d@[???] */
  iVar4 = *p;
  *p = iVar4 + 1;
  bVar1 = bytes[iVar4];
  *p = iVar4 + 2;
  bVar2 = bytes[iVar4 + 1];
  *p = iVar4 + 3;
  bVar3 = bytes[iVar4 + 2];
  *p = iVar4 + 4;
  return (uint)bVar3 << 8 | (uint)bVar2 << 0x10 | (uint)bVar1 << 0x18 | (uint)bytes[iVar4 + 3];
}

