
void * qoi_encode(void *data,qoi_desc *desc,int *out_len)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  uint v;
  byte bVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  uchar *bytes;
  int iVar10;
  long lVar11;
  byte bVar12;
  char cVar13;
  int iVar14;
  int iVar15;
  byte bVar16;
  byte bVar17;
  byte bVar18;
  byte bVar19;
  char cVar20;
  ulong uVar21;
  undefined1 auVar22 [16];
  int local_144;
  int *local_140;
  undefined1 local_138 [32];
  undefined1 local_118 [32];
  undefined1 local_f8 [32];
  undefined1 local_d8 [32];
  undefined1 local_b8 [32];
  undefined1 local_98 [32];
  undefined1 local_78 [32];
  undefined1 local_58 [32];
  
                    /* Unresolved local var: qoi_rgba_t[64] index@[???]
                       Unresolved local var: int max_size@[???]
                       Unresolved local var: int p@[???]
                       Unresolved local var: uchar * bytes@[???]
                       Unresolved local var: uchar * pixels@[???]
                       Unresolved local var: int px_len@[???]
                       Unresolved local var: int px_end@[???]
                       Unresolved local var: int channels@[???]
                       Unresolved local var: int px_pos@[???]
                       Unresolved local var: int run@[???]
                       Unresolved local var: qoi_rgba_t px_prev@[???]
                       Unresolved local var: qoi_rgba_t px@[???]
                       Unresolved local var: int i@[???] */
  if (desc == (qoi_desc *)0x0) {
    return (void *)0x0;
  }
  if (data == (void *)0x0) {
    return (void *)0x0;
  }
  if (out_len == (int *)0x0) {
    return (void *)0x0;
  }
  uVar7 = desc->width;
  if ((((uVar7 != 0) && (v = desc->height, v != 0)) &&
      (bVar1 = desc->channels, 0xfd < (byte)(bVar1 - 5))) && (bVar17 = desc->colorspace, bVar17 < 2)
     ) {
    if ((uint)(400000000 / (ulong)uVar7) <= v) {
      return (void *)0x0;
    }
    local_140 = out_len;
    bytes = malloc((long)(int)((bVar1 + 1) * v * uVar7 + 0x16));
    if (bytes != (uchar *)0x0) {
      iVar8 = 0;
      builtin_memcpy(bytes,"qoif",4);
      local_144 = 4;
      qoi_write_32(bytes,&local_144,uVar7);
      qoi_write_32(bytes,&local_144,v);
      auVar22._0_12_ = ZEXT812(0);
      auVar22._12_4_ = 0;
      local_58 = ZEXT1632(auVar22);
      local_78 = ZEXT1632(auVar22);
      local_98 = ZEXT1632(auVar22);
      local_b8 = local_98;
      local_d8 = local_98;
      local_f8 = local_98;
      local_118 = ZEXT1632(auVar22);
      local_138 = ZEXT1632(auVar22);
      iVar14 = v * uVar7 * (uint)bVar1;
      bytes[local_144] = bVar1;
      iVar6 = local_144 + 2;
      iVar10 = 0;
      bytes[local_144 + 1] = bVar17;
      bVar12 = 0xff;
      bVar16 = 0;
      bVar17 = 0;
      bVar5 = 0;
      do {
        if (iVar14 <= iVar10) {
          for (lVar11 = 0; iVar8 = iVar6 + (int)lVar11, lVar11 != 8; lVar11 = lVar11 + 1) {
            bytes[iVar8] = ""[lVar11];
          }
          *local_140 = iVar8;
          return bytes;
        }
        bVar18 = bVar12;
        if (bVar1 == 4) {
          bVar18 = *(byte *)((long)data + (long)(iVar10 + 3));
        }
        bVar2 = *(byte *)((long)data + (long)iVar10);
        bVar3 = *(byte *)((long)data + (long)iVar10 + 1);
        bVar4 = *(byte *)((long)data + (long)(iVar10 + 2));
        uVar7 = (uint)bVar3 << 8 | (uint)bVar4 << 0x10 | (uint)bVar18 << 0x18 | (uint)bVar2;
        bVar19 = (byte)iVar8;
        if (uVar7 == ((uint)bVar16 | (uint)bVar17 << 8 | (uint)bVar5 << 0x10 | (uint)bVar12 << 0x18)
           ) {
          if ((iVar14 - (uint)bVar1 == iVar10) || (iVar8 = iVar8 + 1, iVar8 == 0x3e)) {
            uVar21 = (ulong)(bVar19 | 0xc0);
            iVar8 = 0;
LAB_001022b6:
            iVar9 = iVar6 + 1;
            iVar15 = iVar6;
            bVar17 = (byte)uVar21;
            goto LAB_0010238c;
          }
        }
        else {
                    /* Unresolved local var: int index_pos@[???] */
          if (0 < iVar8) {
            iVar8 = 0;
            lVar11 = (long)iVar6;
            iVar6 = iVar6 + 1;
            bytes[lVar11] = bVar19 - 1 | 0xc0;
          }
          uVar21 = (ulong)((uint)bVar18 * 0xb +
                           (uint)bVar3 + (uint)bVar3 * 4 + (uint)bVar2 + (uint)bVar2 * 2 +
                           (uint)bVar4 * 7 & 0x3f);
          if (*(uint *)(local_138 + uVar21 * 4) == uVar7) goto LAB_001022b6;
          local_138[uVar21 * 4] = bVar2;
          local_138[uVar21 * 4 + 1] = bVar3;
          local_138[uVar21 * 4 + 2] = bVar4;
          local_138[uVar21 * 4 + 3] = bVar18;
          if (bVar18 == bVar12) {
                    /* Unresolved local var: char vr@[???]
                       Unresolved local var: char vg@[???]
                       Unresolved local var: char vb@[???]
                       Unresolved local var: char vg_b@[???]
                       Unresolved local var: char vg_r@[???] */
            cVar20 = bVar3 - bVar17;
            cVar13 = bVar2 - bVar16;
            if ((((byte)(cVar13 + 2U) < 4) && ((byte)(cVar20 + 2U) < 4)) &&
               (bVar17 = (bVar4 - bVar5) + 2, bVar17 < 4)) {
              iVar9 = iVar6 + 1;
              iVar15 = iVar6;
              bVar17 = cVar20 * '\x04' + 8U | cVar13 * '\x10' + 0x20U | bVar17 | 0x40;
            }
            else if ((((byte)((cVar13 - cVar20) + 8U) < 0x10) && ((byte)(cVar20 + 0x20U) < 0x40)) &&
                    (bVar17 = ((bVar4 - bVar5) - cVar20) + 8, bVar17 < 0x10)) {
              bytes[iVar6] = cVar20 + 0x20U | 0x80;
              iVar9 = iVar6 + 2;
              iVar15 = iVar6 + 1;
              bVar17 = (bVar17 | (cVar13 - cVar20) * '\x10') + 0x80;
            }
            else {
              bytes[iVar6] = 0xfe;
              iVar9 = iVar6 + 4;
              bytes[iVar6 + 1] = bVar2;
              bytes[iVar6 + 2] = bVar3;
              iVar15 = iVar6 + 3;
              bVar17 = bVar4;
            }
          }
          else {
            bytes[iVar6] = 0xff;
            bytes[iVar6 + 1] = bVar2;
            bytes[iVar6 + 2] = bVar3;
            iVar15 = iVar6 + 4;
            iVar9 = iVar6 + 5;
            bytes[iVar6 + 3] = bVar4;
            bVar17 = bVar18;
          }
LAB_0010238c:
          bytes[iVar15] = bVar17;
          iVar6 = iVar9;
        }
        iVar10 = iVar10 + (uint)bVar1;
        bVar12 = bVar18;
        bVar16 = bVar2;
        bVar17 = bVar3;
        bVar5 = bVar4;
      } while( true );
    }
  }
  return (void *)0x0;
}

