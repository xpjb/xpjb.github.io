
void sha256_update(SHA256_CTX *ctx,BYTE *data,size_t len)

{
  WORD WVar1;
  uint uVar2;
  
                    /* Unresolved local var: WORD i@[???] */
  for (uVar2 = 0; uVar2 < len; uVar2 = uVar2 + 1) {
    ctx->data[ctx->datalen] = data[uVar2];
    WVar1 = ctx->datalen + 1;
    ctx->datalen = WVar1;
    if (WVar1 == 0x40) {
      sha256_transform(ctx,ctx->data);
      ctx->bitlen = ctx->bitlen + 0x200;
      ctx->datalen = 0;
    }
  }
  return;
}

