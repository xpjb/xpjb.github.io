
void sha256_final(SHA256_CTX *ctx,BYTE *hash)

{
  uint uVar1;
  uint uVar2;
  ulong uVar3;
  unsigned_long_long uVar4;
  long lVar5;
  
                    /* Unresolved local var: WORD i@[???] */
  uVar2 = ctx->datalen;
  uVar3 = (ulong)uVar2;
  ctx->data[uVar3] = 0x80;
  if (uVar3 < 0x38) {
    for (; uVar3 != 0x37; uVar3 = uVar3 + 1) {
      ctx->data[uVar3 + 1] = '\0';
    }
  }
  else {
    for (uVar3 = (ulong)(uVar2 + 1); (uint)uVar3 < 0x40; uVar3 = uVar3 + 1) {
      ctx->data[uVar3] = '\0';
    }
    sha256_transform(ctx,ctx->data);
    *(undefined1 (*) [32])(ctx->data + 0x18) = ZEXT1232(ZEXT812(0));
    *(undefined1 (*) [32])ctx->data = ZEXT1232(ZEXT812(0));
  }
  uVar4 = (ulong)(ctx->datalen << 3) + ctx->bitlen;
  ctx->bitlen = uVar4;
  ctx->data[0x3f] = (BYTE)uVar4;
  ctx->data[0x3e] = (BYTE)(uVar4 >> 8);
  ctx->data[0x3d] = (BYTE)(uVar4 >> 0x10);
  ctx->data[0x3c] = (BYTE)(uVar4 >> 0x18);
  ctx->data[0x3b] = (BYTE)(uVar4 >> 0x20);
  ctx->data[0x3a] = (BYTE)(uVar4 >> 0x28);
  ctx->data[0x39] = (BYTE)(uVar4 >> 0x30);
  ctx->data[0x38] = (BYTE)(uVar4 >> 0x38);
  sha256_transform(ctx,ctx->data);
  uVar2 = 0x18;
  for (lVar5 = -4; lVar5 != 0; lVar5 = lVar5 + 1) {
    hash[lVar5 + 4] = (BYTE)(ctx->state[0] >> (uVar2 & 0x1f));
    hash[lVar5 + 8] = (BYTE)(ctx->state[1] >> (uVar2 & 0x1f));
    hash[lVar5 + 0xc] = (BYTE)(ctx->state[2] >> (uVar2 & 0x1f));
    hash[lVar5 + 0x10] = (BYTE)(ctx->state[3] >> (uVar2 & 0x1f));
    hash[lVar5 + 0x14] = (BYTE)(ctx->state[4] >> (uVar2 & 0x1f));
    hash[lVar5 + 0x18] = (BYTE)(ctx->state[5] >> (uVar2 & 0x1f));
    hash[lVar5 + 0x1c] = (BYTE)(ctx->state[6] >> (uVar2 & 0x1f));
    uVar1 = uVar2 & 0x1f;
    uVar2 = uVar2 - 8;
    hash[lVar5 + 0x20] = (BYTE)(ctx->state[7] >> uVar1);
  }
  return;
}

