
void sha256_transform(SHA256_CTX *ctx,BYTE *data)

{
  undefined1 auVar1 [32];
  undefined4 uVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [32];
  undefined1 auVar5 [32];
  undefined1 auVar6 [16];
  long lVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint auStack_148 [9];
  int aiStack_124 [5];
  uint auStack_110 [68];
  
                    /* Unresolved local var: WORD[64] m@[???]
                       Unresolved local var: WORD i@[???]
                       Unresolved local var: WORD j@[???]
                       Unresolved local var: WORD a@[???]
                       Unresolved local var: WORD t1@[???]
                       Unresolved local var: WORD t2@[???]
                       Unresolved local var: WORD b@[???]
                       Unresolved local var: WORD c@[???]
                       Unresolved local var: WORD d@[???]
                       Unresolved local var: WORD e@[???]
                       Unresolved local var: WORD f@[???]
                       Unresolved local var: WORD g@[???]
                       Unresolved local var: WORD h@[???] */
  for (lVar7 = 0; lVar7 != 0x10; lVar7 = lVar7 + 1) {
    uVar2 = *(undefined4 *)(data + lVar7 * 4);
    auStack_110[lVar7 + 2] =
         CONCAT13((char)uVar2,
                  CONCAT12((char)((uint)uVar2 >> 8),
                           CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18))));
  }
  for (lVar7 = 0x10; lVar7 != 0x40; lVar7 = lVar7 + 1) {
    uVar9 = auStack_110[lVar7];
    uVar10 = auStack_148[lVar7 + 1];
    auStack_110[lVar7 + 2] =
         (uVar9 >> 10 ^ (uVar9 >> 0x13 | uVar9 << 0xd) ^ (uVar9 >> 0x11 | uVar9 << 0xf)) +
         aiStack_124[lVar7] + auStack_148[lVar7] +
         (uVar10 >> 3 ^ (uVar10 >> 0x12 | uVar10 << 0xe) ^ (uVar10 >> 7 | uVar10 << 0x19));
  }
  auVar1 = *(undefined1 (*) [32])ctx->state;
  lVar7 = 0;
  auVar5 = auVar1;
  while( true ) {
    uVar9 = auVar5._0_4_;
    uVar10 = auVar5._4_4_;
    uVar11 = auVar5._8_4_;
    uVar12 = auVar5._16_4_;
    if (lVar7 == 0x100) break;
    auVar3 = vpshufd_avx(auVar5._0_16_,0xff);
    iVar8 = (~uVar12 & auVar5._24_4_ | auVar5._20_4_ & uVar12) + auVar5._28_4_ +
            ((uVar12 >> 0x19 | uVar12 << 7) ^
            (uVar12 >> 0xb | uVar12 << 0x15) ^ (uVar12 >> 6 | uVar12 << 0x1a)) +
            *(int *)((long)k + lVar7) + *(int *)((long)auStack_110 + lVar7 + 8);
    lVar7 = lVar7 + 4;
    auVar4 = vpshufd_avx2(auVar5,0x90);
    auVar6 = ZEXT116(0) * auVar3 |
             ZEXT116(1) *
             ZEXT416((uVar10 & uVar11 ^ (uVar10 ^ uVar11) & uVar9) +
                     ((uVar9 >> 0x16 | uVar9 << 10) ^
                     (uVar9 >> 0xd | uVar9 << 0x13) ^ (uVar9 >> 2 | uVar9 << 0x1e)));
    auVar3 = ZEXT116(1) * auVar3;
    auVar5._0_4_ = iVar8 + auVar6._0_4_;
    auVar5._4_4_ = iVar8 + auVar6._4_4_;
    auVar5._8_4_ = iVar8 + auVar6._8_4_;
    auVar5._12_4_ = iVar8 + auVar6._12_4_;
    auVar5._16_4_ = iVar8 + auVar3._0_4_;
    auVar5._20_4_ = iVar8 + auVar3._4_4_;
    auVar5._24_4_ = iVar8 + auVar3._8_4_;
    auVar5._28_4_ = iVar8 + auVar3._12_4_;
    auVar5 = vpblendd_avx2(auVar4,auVar5,0x11);
  }
  ctx->state[0] = uVar9 + auVar1._0_4_;
  ctx->state[1] = uVar10 + auVar1._4_4_;
  ctx->state[2] = uVar11 + auVar1._8_4_;
  ctx->state[3] = auVar5._12_4_ + auVar1._12_4_;
  ctx->state[4] = uVar12 + auVar1._16_4_;
  ctx->state[5] = auVar5._20_4_ + auVar1._20_4_;
  ctx->state[6] = auVar5._24_4_ + auVar1._24_4_;
  ctx->state[7] = auVar5._28_4_ + auVar1._28_4_;
  return;
}




void sha256_init(SHA256_CTX *ctx)

{
  ctx->datalen = 0;
  ctx->bitlen = 0;
  ctx->state[0] = 0x6a09e667;
  ctx->state[1] = 0xbb67ae85;
  ctx->state[2] = 0x3c6ef372;
  ctx->state[3] = 0xa54ff53a;
  ctx->state[4] = 0x510e527f;
  ctx->state[5] = 0x9b05688c;
  ctx->state[6] = 0x1f83d9ab;
  ctx->state[7] = 0x5be0cd19;
  return;
}




void sha256_update(SHA256_CTX *ctx,BYTE *data,size_t len)

{
  WORD WVar1;
  uint uVar2;
  
                    /* Unresolved local var: WORD i@[???] */
  for (uVar2 = 0; uVar2 < len; uVar2 = uVar2 + 1) {
    ctx->data[ctx->datalen] = data[uVar2];
    WVar1 = ctx->datalen + 1;
    ctx->datalen = WVar1;
    if (WVar1 == 0x40) {
      sha256_transform(ctx,ctx->data);
      ctx->bitlen = ctx->bitlen + 0x200;
      ctx->datalen = 0;
    }
  }
  return;
}




void sha256_final(SHA256_CTX *ctx,BYTE *hash)

{
  uint uVar1;
  uint uVar2;
  ulong uVar3;
  unsigned_long_long uVar4;
  long lVar5;
  
                    /* Unresolved local var: WORD i@[???] */
  uVar2 = ctx->datalen;
  uVar3 = (ulong)uVar2;
  ctx->data[uVar3] = 0x80;
  if (uVar3 < 0x38) {
    for (; uVar3 != 0x37; uVar3 = uVar3 + 1) {
      ctx->data[uVar3 + 1] = '\0';
    }
  }
  else {
    for (uVar3 = (ulong)(uVar2 + 1); (uint)uVar3 < 0x40; uVar3 = uVar3 + 1) {
      ctx->data[uVar3] = '\0';
    }
    sha256_transform(ctx,ctx->data);
    *(undefined1 (*) [32])(ctx->data + 0x18) = ZEXT1232(ZEXT812(0));
    *(undefined1 (*) [32])ctx->data = ZEXT1232(ZEXT812(0));
  }
  uVar4 = (ulong)(ctx->datalen << 3) + ctx->bitlen;
  ctx->bitlen = uVar4;
  ctx->data[0x3f] = (BYTE)uVar4;
  ctx->data[0x3e] = (BYTE)(uVar4 >> 8);
  ctx->data[0x3d] = (BYTE)(uVar4 >> 0x10);
  ctx->data[0x3c] = (BYTE)(uVar4 >> 0x18);
  ctx->data[0x3b] = (BYTE)(uVar4 >> 0x20);
  ctx->data[0x3a] = (BYTE)(uVar4 >> 0x28);
  ctx->data[0x39] = (BYTE)(uVar4 >> 0x30);
  ctx->data[0x38] = (BYTE)(uVar4 >> 0x38);
  sha256_transform(ctx,ctx->data);
  uVar2 = 0x18;
  for (lVar5 = -4; lVar5 != 0; lVar5 = lVar5 + 1) {
    hash[lVar5 + 4] = (BYTE)(ctx->state[0] >> (uVar2 & 0x1f));
    hash[lVar5 + 8] = (BYTE)(ctx->state[1] >> (uVar2 & 0x1f));
    hash[lVar5 + 0xc] = (BYTE)(ctx->state[2] >> (uVar2 & 0x1f));
    hash[lVar5 + 0x10] = (BYTE)(ctx->state[3] >> (uVar2 & 0x1f));
    hash[lVar5 + 0x14] = (BYTE)(ctx->state[4] >> (uVar2 & 0x1f));
    hash[lVar5 + 0x18] = (BYTE)(ctx->state[5] >> (uVar2 & 0x1f));
    hash[lVar5 + 0x1c] = (BYTE)(ctx->state[6] >> (uVar2 & 0x1f));
    uVar1 = uVar2 & 0x1f;
    uVar2 = uVar2 - 8;
    hash[lVar5 + 0x20] = (BYTE)(ctx->state[7] >> uVar1);
  }
  return;
}



