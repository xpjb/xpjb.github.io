
int jsmn_parse(jsmn_parser *parser,char *js,size_t len,jsmntok_t *tokens,uint num_tokens)

{
  byte bVar1;
  char cVar2;
  undefined1 auVar3 [16];
  jsmntok_t jVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  ulong uVar11;
  jsmntok_t *pjVar12;
  long lVar13;
  uint uVar14;
  bool bVar15;
  
                    /* Unresolved local var: int count@[???]
                       Unresolved local var: int i@[???]
                       Unresolved local var: jsmntok_t * token@[???]
                       Unresolved local var: int r@[???] */
  uVar14 = parser->pos;
  uVar7 = parser->toknext;
  iVar5 = -2;
LAB_00101b4e:
  if (len <= uVar14) {
LAB_00101fad:
    uVar10 = uVar7;
    if (tokens != (jsmntok_t *)0x0) {
      uVar14 = parser->toknext;
      do {
        uVar14 = uVar14 - 1;
        if ((int)uVar14 < 0) {
          return uVar7;
        }
      } while ((tokens[uVar14 & 0x7fffffff].start == -1) ||
              (uVar10 = 0xfffffffd, tokens[uVar14 & 0x7fffffff].end != -1));
    }
switchD_00101b78_caseD_21:
    return uVar10;
  }
  bVar1 = js[uVar14];
  uVar10 = 0xfffffffe;
  switch(bVar1) {
  case 0x20:
    break;
  case 0x21:
  case 0x23:
  case 0x24:
  case 0x25:
  case 0x26:
  case 0x27:
  case 0x28:
  case 0x29:
  case 0x2a:
  case 0x2b:
  case 0x2e:
  case 0x2f:
    goto switchD_00101b78_caseD_21;
  case 0x22:
                    /* Unresolved local var: jsmntype_t type@[???]
                       Unresolved local var: char c@[???]
                       Unresolved local var: int start@[???]
                       Unresolved local var: jsmntok_t * token@[???] */
    uVar10 = uVar14 + 1;
    do {
      parser->pos = uVar10;
      if (len <= uVar10) goto LAB_00101f91;
      cVar2 = js[uVar10];
      uVar8 = uVar10;
      if (cVar2 == '\\') {
        uVar9 = uVar10 + 1;
        if (uVar9 < len) {
                    /* Unresolved local var: int i@[???] */
          parser->pos = uVar9;
          bVar1 = js[uVar9];
          uVar8 = uVar9;
          if ((0x37 < bVar1 - 0x2f) ||
             ((0x88200000000001U >> ((ulong)(bVar1 - 0x2f) & 0x3f) & 1) == 0)) {
            switch(bVar1) {
            case 0x6e:
            case 0x72:
            case 0x74:
              break;
            case 0x6f:
            case 0x70:
            case 0x71:
            case 0x73:
              goto switchD_00101bf1_caseD_6f;
            case 0x75:
              uVar10 = uVar10 + 2;
              iVar6 = 4;
              parser->pos = uVar10;
              while (((bVar15 = iVar6 != 0, iVar6 = iVar6 + -1, bVar15 && (uVar10 < len)) &&
                     (bVar1 = js[uVar10], bVar1 != 0))) {
                if ((9 < (byte)(bVar1 - 0x30)) &&
                   ((0x25 < bVar1 - 0x41 ||
                    ((0x3f0000003fU >> ((ulong)(bVar1 - 0x41) & 0x3f) & 1) == 0))))
                goto switchD_00101bf1_caseD_6f;
                uVar10 = uVar10 + 1;
                parser->pos = uVar10;
              }
              parser->pos = uVar10 - 1;
              uVar8 = uVar10 - 1;
              break;
            default:
              if (bVar1 != 0x22) goto switchD_00101bf1_caseD_6f;
            }
          }
        }
      }
      else {
        if (cVar2 == '\0') goto LAB_00101f91;
        if (cVar2 == '\"') goto LAB_00101f43;
      }
      uVar10 = uVar8 + 1;
    } while( true );
  case 0x2c:
    if (((tokens != (jsmntok_t *)0x0) && ((long)parser->toksuper != -1)) &&
       (1 < tokens[parser->toksuper].type - JSMN_OBJECT)) {
      uVar8 = parser->toknext;
      do {
        uVar8 = uVar8 - 1;
        if ((int)uVar8 < 0) goto switchD_00101b78_caseD_20;
        uVar14 = uVar8 & 0x7fffffff;
      } while (((1 < tokens[uVar14].type - JSMN_OBJECT) || (tokens[uVar14].start == -1)) ||
              (tokens[uVar14].end != -1));
LAB_00101ef5:
      parser->toksuper = uVar8;
    }
    break;
  case 0x2d:
  case 0x30:
  case 0x31:
  case 0x32:
  case 0x33:
  case 0x34:
  case 0x35:
  case 0x36:
  case 0x37:
  case 0x38:
  case 0x39:
switchD_00101b78_caseD_2d:
    uVar10 = uVar14;
    if ((tokens != (jsmntok_t *)0x0) && (lVar13 = (long)parser->toksuper, lVar13 != -1)) {
                    /* Unresolved local var: jsmntok_t * t@[???] */
      if (tokens[lVar13].type == JSMN_STRING) {
        if (tokens[lVar13].size != 0) {
          return -2;
        }
      }
      else if (tokens[lVar13].type == JSMN_OBJECT) {
        return -2;
      }
    }
    do {
                    /* Unresolved local var: jsmntok_t * token@[???] */
      if (len <= uVar10) goto LAB_00101f91;
      bVar1 = js[uVar10];
      uVar11 = (ulong)bVar1;
      if (uVar11 < 0x2d) {
        if ((0x100100002600U >> (uVar11 & 0x3f) & 1) != 0) goto LAB_00101db3;
        if (uVar11 == 0) goto LAB_00101f91;
      }
      if ((bVar1 == 0x5d) || (bVar1 == 0x7d)) goto LAB_00101db3;
      if ((byte)(bVar1 + 0x81) < 0xa1) goto switchD_00101bf1_caseD_6f;
      parser->pos = uVar10 + 1;
      uVar10 = uVar10 + 1;
    } while( true );
  case 0x3a:
switchD_00101b78_caseD_3a:
    parser->toksuper = parser->toknext - 1;
    break;
  default:
    uVar11 = (ulong)(bVar1 - 0x5b);
    if (bVar1 - 0x5b < 0x23) {
      if ((0x2080800UL >> (uVar11 & 0x3f) & 1) != 0) goto switchD_00101b78_caseD_2d;
      if ((0x100000001U >> (uVar11 & 0x3f) & 1) == 0) {
        if ((0x400000004U >> (uVar11 & 0x3f) & 1) == 0) goto LAB_00101d3d;
        if (tokens != (jsmntok_t *)0x0) {
          uVar10 = parser->toknext;
          do {
            uVar8 = uVar10;
            uVar10 = uVar8 - 1;
            if ((int)uVar10 < 0) goto LAB_00101f15;
          } while ((tokens[uVar10 & 0x7fffffff].start == -1) ||
                  (pjVar12 = tokens + (uVar10 & 0x7fffffff), pjVar12->end != -1));
          if (pjVar12->type != (bVar1 != 0x7d) + JSMN_OBJECT) {
            return -2;
          }
          parser->toksuper = -1;
          pjVar12->end = uVar14 + 1;
LAB_00101f15:
          if (uVar8 == 0) {
            return -2;
          }
          do {
            uVar8 = uVar8 - 1;
            if ((int)uVar8 < 0) goto switchD_00101b78_caseD_20;
          } while ((tokens[uVar8].start == -1) || (tokens[uVar8].end != -1));
          goto LAB_00101ef5;
        }
      }
      else {
        uVar7 = uVar7 + 1;
        if (tokens != (jsmntok_t *)0x0) {
          uVar14 = parser->toknext;
          if (num_tokens <= uVar14) {
            return -1;
          }
          parser->toknext = uVar14 + 1;
          tokens[uVar14].start = -1;
          tokens[uVar14].end = -1;
          tokens[uVar14].size = 0;
          lVar13 = (long)parser->toksuper;
          if (lVar13 != -1) {
                    /* Unresolved local var: jsmntok_t * t@[???] */
            if (tokens[lVar13].type == JSMN_OBJECT) {
              return -2;
            }
            tokens[lVar13].size = tokens[lVar13].size + 1;
          }
          tokens[uVar14].type = (bVar1 != 0x7b) + JSMN_OBJECT;
          tokens[uVar14].start = parser->pos;
          goto switchD_00101b78_caseD_3a;
        }
      }
    }
    else {
LAB_00101d3d:
      if ((1 < bVar1 - 9) && (bVar1 != 0xd)) {
        if (bVar1 != 0) {
          return -2;
        }
        goto LAB_00101fad;
      }
    }
  }
  goto switchD_00101b78_caseD_20;
LAB_00101db3:
  if (tokens != (jsmntok_t *)0x0) {
                    /* Unresolved local var: jsmntok_t * tok@[???] */
    uVar10 = parser->toknext;
    if (num_tokens <= uVar10) goto LAB_00101fa4;
    parser->toknext = uVar10 + 1;
    tokens[uVar10].start = -1;
    tokens[uVar10].end = -1;
    tokens[uVar10].size = 0;
    auVar3 = vpunpckldq_avx(ZEXT416(8),ZEXT416(uVar14));
    jVar4 = (jsmntok_t)vpunpcklqdq_avx(auVar3,ZEXT416(parser->pos));
    tokens[uVar10] = jVar4;
    uVar10 = parser->pos;
  }
  parser->pos = uVar10 - 1;
  goto LAB_00101e04;
LAB_00101f91:
  iVar5 = -3;
  goto switchD_00101bf1_caseD_6f;
LAB_00101f43:
  if (tokens != (jsmntok_t *)0x0) {
                    /* Unresolved local var: jsmntok_t * tok@[???] */
    uVar10 = parser->toknext;
    if (num_tokens <= uVar10) {
LAB_00101fa4:
      iVar5 = -1;
switchD_00101bf1_caseD_6f:
      parser->pos = uVar14;
      return iVar5;
    }
    parser->toknext = uVar10 + 1;
    tokens[uVar10].start = -1;
    tokens[uVar10].end = -1;
    tokens[uVar10].size = 0;
    auVar3 = vpunpckldq_avx(ZEXT416(4),ZEXT416(uVar14 + 1));
    jVar4 = (jsmntok_t)vpunpcklqdq_avx(auVar3,ZEXT416(parser->pos));
    tokens[uVar10] = jVar4;
  }
LAB_00101e04:
  uVar7 = uVar7 + 1;
  if ((long)parser->toksuper != -1 && tokens != (jsmntok_t *)0x0) {
    tokens[parser->toksuper].size = tokens[parser->toksuper].size + 1;
  }
switchD_00101b78_caseD_20:
  uVar14 = parser->pos + 1;
  parser->pos = uVar14;
  goto LAB_00101b4e;
}




void jsmn_init(jsmn_parser *parser)

{
  parser->pos = 0;
  parser->toknext = 0;
  parser->toksuper = -1;
  return;
}



