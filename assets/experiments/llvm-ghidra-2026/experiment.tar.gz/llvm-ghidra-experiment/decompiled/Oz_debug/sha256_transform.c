
void sha256_transform(SHA256_CTX *ctx,BYTE *data)

{
  undefined1 auVar1 [32];
  undefined4 uVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [32];
  undefined1 auVar5 [32];
  undefined1 auVar6 [16];
  long lVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint auStack_148 [9];
  int aiStack_124 [5];
  uint auStack_110 [68];
  
                    /* Unresolved local var: WORD[64] m@[???]
                       Unresolved local var: WORD i@[???]
                       Unresolved local var: WORD j@[???]
                       Unresolved local var: WORD a@[???]
                       Unresolved local var: WORD t1@[???]
                       Unresolved local var: WORD t2@[???]
                       Unresolved local var: WORD b@[???]
                       Unresolved local var: WORD c@[???]
                       Unresolved local var: WORD d@[???]
                       Unresolved local var: WORD e@[???]
                       Unresolved local var: WORD f@[???]
                       Unresolved local var: WORD g@[???]
                       Unresolved local var: WORD h@[???] */
  for (lVar7 = 0; lVar7 != 0x10; lVar7 = lVar7 + 1) {
    uVar2 = *(undefined4 *)(data + lVar7 * 4);
    auStack_110[lVar7 + 2] =
         CONCAT13((char)uVar2,
                  CONCAT12((char)((uint)uVar2 >> 8),
                           CONCAT11((char)((uint)uVar2 >> 0x10),(char)((uint)uVar2 >> 0x18))));
  }
  for (lVar7 = 0x10; lVar7 != 0x40; lVar7 = lVar7 + 1) {
    uVar9 = auStack_110[lVar7];
    uVar10 = auStack_148[lVar7 + 1];
    auStack_110[lVar7 + 2] =
         (uVar9 >> 10 ^ (uVar9 >> 0x13 | uVar9 << 0xd) ^ (uVar9 >> 0x11 | uVar9 << 0xf)) +
         aiStack_124[lVar7] + auStack_148[lVar7] +
         (uVar10 >> 3 ^ (uVar10 >> 0x12 | uVar10 << 0xe) ^ (uVar10 >> 7 | uVar10 << 0x19));
  }
  auVar1 = *(undefined1 (*) [32])ctx->state;
  lVar7 = 0;
  auVar5 = auVar1;
  while( true ) {
    uVar9 = auVar5._0_4_;
    uVar10 = auVar5._4_4_;
    uVar11 = auVar5._8_4_;
    uVar12 = auVar5._16_4_;
    if (lVar7 == 0x100) break;
    auVar3 = vpshufd_avx(auVar5._0_16_,0xff);
    iVar8 = (~uVar12 & auVar5._24_4_ | auVar5._20_4_ & uVar12) + auVar5._28_4_ +
            ((uVar12 >> 0x19 | uVar12 << 7) ^
            (uVar12 >> 0xb | uVar12 << 0x15) ^ (uVar12 >> 6 | uVar12 << 0x1a)) +
            *(int *)((long)k + lVar7) + *(int *)((long)auStack_110 + lVar7 + 8);
    lVar7 = lVar7 + 4;
    auVar4 = vpshufd_avx2(auVar5,0x90);
    auVar6 = ZEXT116(0) * auVar3 |
             ZEXT116(1) *
             ZEXT416((uVar10 & uVar11 ^ (uVar10 ^ uVar11) & uVar9) +
                     ((uVar9 >> 0x16 | uVar9 << 10) ^
                     (uVar9 >> 0xd | uVar9 << 0x13) ^ (uVar9 >> 2 | uVar9 << 0x1e)));
    auVar3 = ZEXT116(1) * auVar3;
    auVar5._0_4_ = iVar8 + auVar6._0_4_;
    auVar5._4_4_ = iVar8 + auVar6._4_4_;
    auVar5._8_4_ = iVar8 + auVar6._8_4_;
    auVar5._12_4_ = iVar8 + auVar6._12_4_;
    auVar5._16_4_ = iVar8 + auVar3._0_4_;
    auVar5._20_4_ = iVar8 + auVar3._4_4_;
    auVar5._24_4_ = iVar8 + auVar3._8_4_;
    auVar5._28_4_ = iVar8 + auVar3._12_4_;
    auVar5 = vpblendd_avx2(auVar4,auVar5,0x11);
  }
  ctx->state[0] = uVar9 + auVar1._0_4_;
  ctx->state[1] = uVar10 + auVar1._4_4_;
  ctx->state[2] = uVar11 + auVar1._8_4_;
  ctx->state[3] = auVar5._12_4_ + auVar1._12_4_;
  ctx->state[4] = uVar12 + auVar1._16_4_;
  ctx->state[5] = auVar5._20_4_ + auVar1._20_4_;
  ctx->state[6] = auVar5._24_4_ + auVar1._24_4_;
  ctx->state[7] = auVar5._28_4_ + auVar1._28_4_;
  return;
}

